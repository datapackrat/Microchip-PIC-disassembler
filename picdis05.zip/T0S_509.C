/*
 *  Hi Tech PIC C compiler, V7.86PL4
 */
#include <pic.h>

__CONFIG(FOSC1);   /* the only configuration I want is oscillator = internalRC */

unsigned char lastt0;

#define STRING_SIZE 16
bank1 char buf[STRING_SIZE];
char ch;
char index;
int bitcount;

/*
 *      Serial port driver for 16Cxx chips
 *      using software delays.
 *
 *      Copyright (C)1996 HI-TECH Software.
 *      Freely distributable.
 */
/*
 * Trivial changes made to INIT_PORT, TxData, RxData.
 * Reformatted to make it look nice.
 * 3/20/02
 */

/*
 *      Tunable parameters
 */
/* Transmit and Receive port bits */
#define TxData GP0
#define RxData GP1
#define INIT_PORT() GP0 = 1; TRIS = 0x1e   /* set GP0 as HIGH output for RS232 */
                                           /* set GP5 as output for oscope */

/* Xtal frequency */
#define XTAL  4000000

/* Baud rate */
#define BRATE 9600

/* Don't change anything else */
#define DLY       3  /* cycles per null loop */
#define TX_OHEAD 13  /* overhead cycles per loop */
#define RX_OHEAD 12  /* receiver overhead per loop */

#define DELAY(ohead) (((XTAL/4/BRATE)-(ohead))/DLY)

void putch(char c)
   {
   unsigned char dly, bitno;

   bitno = 11;
   TxData = 0;         /* start bit */
   bitno = 12;
   do
      {
      dly = DELAY(TX_OHEAD);   /* wait one bit time */
      do
         /* nix */ ;
      while (--dly);
      if (c & 1)
         TxData = 1;
      if (!(c & 1))
         TxData = 0;
      c = (c >> 1) | 0x80;
      } while (--bitno);
   }

char getch(void)
   {
   unsigned char c, bitno, dly;

   for ( ; ; )
      {
      while (RxData)
         continue;   /* wait for start bit */
      dly = DELAY(3)/2;
      do
         /* nix */;
      while (--dly);
      if (RxData)
         continue;   /* twas just noise */
      bitno = 8;
      c = 0;
      do
         {
         dly = DELAY(RX_OHEAD);
         do
            /* nix */;
         while (--dly);
         c = (c >> 1) | (RxData << 7);
         } while(--bitno);
      return c;
      }
   }

char ascii_hex(char ch)
   {
   ch &= 0x0f;  /* isolate low nibble */
   if (ch > 9)
      return(ch + 0x37);
   return(ch + 0x30);
   }

void puthex(char c)
   {
   putch(ascii_hex(c >> 4));
   putch(ascii_hex(c));
   }

/* On the 509A, this code can't handle a non-constant string being passed
 * to it, so putstr() is also defined.
 */
void puts(const char *s)
   {
   while (*s)
      putch(*(s++));
   }

void putstr(char *s)
   {
   while (*s)
      putch(*(s++));
   }

main()
   {
   INIT_PORT();  /* setup for SoftUart */
   puts("\nSoftUart/keyboard sim of IO pins/OSCope.\n"
        "F1 is tied to GP2/T0CKI to update TMR0, which will be shown.\n");
   puts("Type a string, it will be echoed back.\n"
        "Press RightShift and ESC to stop the emulator.\n");
   TMR0 = 0;
   lastt0 = TMR0;
   for ( ; ; )
      {
      if (TMR0 != lastt0)
         {
         puts("\nNew TMR0: ");
         puthex(TMR0);
         putch('\n');
         lastt0 = TMR0;
         }
      if (!RxData)  /* if we see a start bit */
         {
         ch = getch();
         putch(ch);
         if (index < STRING_SIZE-1)
            buf[index++] = ch;
         if (ch == '\015')
            {
            buf[index] = '\0';
            puts("You Typed: ");
            putstr(buf);
            putch('\n');
            index = 0;
            }
         }  /* if (!RxData) */
      if (++bitcount == 0)
         GP5 = !GP5;  /* toggle GP4 periodically */
      }  /* for ( ; ; ) */
   }  /* main() */
