/*
 *  Hi Tech PIC C LITE compiler, V8.02
 */
#include <pic.h>

__CONFIG(INTIO & WDTDIS & MCLRDIS);

unsigned char lastt0;

#define STRING_SIZE 16
char buf[STRING_SIZE];
char ch;
char index;
int bitcount;
bit gp1_state;

/*
 *      Serial port driver for 16Cxx chips
 *      using software delays.
 *
 *      Copyright (C)1996 HI-TECH Software.
 *      Freely distributable.
 */
/*
 * Trivial changes made to INIT_PORT stuff.
 * Reformatted to make it look nice.
 * 3/20/02
 */

/*
 *      Tunable parameters
 */
/* Transmit and Receive port bits */
#define TxData GPIO4
#define RxData GPIO5
#define INIT_PORT() TxData = 1; TRIS4 = 0; TRIS5 = 1  /* set up I/O direction */

/* Xtal frequency */
#define XTAL  4000000L

/* Baud rate */
#define BRATE 9600

/* Don't change anything else */
#define DLY       3  /* cycles per null loop */
#define TX_OHEAD 13  /* overhead cycles per loop */
#define RX_OHEAD 12  /* receiver overhead per loop */

#define DELAY(ohead) (((XTAL/4/BRATE)-(ohead))/DLY)

void putch(char c)
   {
   unsigned char dly, bitno;

   bitno = 11;
   TxData = 0;         /* start bit */
   bitno = 12;
   do
      {
      dly = DELAY(TX_OHEAD);   /* wait one bit time */
      do
         /* nix */ ;
      while (--dly);
      if (c & 1)
         TxData = 1;
      if (!(c & 1))
         TxData = 0;
      c = (c >> 1) | 0x80;
      } while (--bitno);
   }

char getch(void)
   {
   unsigned char c, bitno, dly;

   for ( ; ; )
      {
      while (RxData)
         continue;   /* wait for start bit */
      dly = DELAY(3)/2;
      do
         /* nix */;
      while (--dly);
      if (RxData)
         continue;   /* twas just noise */
      bitno = 8;
      c = 0;
      do
         {
         dly = DELAY(RX_OHEAD);
         do
            /* nix */;
         while (--dly);
         c = (c >> 1) | (RxData << 7);
         } while(--bitno);
      return c;
      }
   }

char ascii_hex(char ch)
   {
   ch &= 0x0f;  /* isolate low nibble */
   if (ch > 9)
      return(ch + 0x37);
   return(ch + 0x30);
   }

void puthex(char c)
   {
   putch(ascii_hex(c >> 4));
   putch(ascii_hex(c));
   }

void puts(const char *s)
   {
   while (*s)
      putch(*(s++));
   }

main()
   {
       /* Load Factory Calibration Value Into OSCCAL */
   OSCCAL = _READ_OSCCAL_DATA();
   ANSEL = 0;  /* no analog ports */
   CMCON = 7;  /* comparitor off */
   INIT_PORT();  /* setup for SoftUart */
   puts("\nThis program demonstrates a SoftUart (TX on pin GP4, RX on GP5),\n");
   puts("keyboard simulation of I/O pins, and PICEMU's oscilloscope function.\n");
   puts("The accompanying file, T0_SUART.675 is used to setup P12F675.EXE via the\n");
   puts("commandline\n");
   puts("   P12F675 -T0_SUART.675\n");
   puts("to use a Software UART and functionkey F1 to simulate changes on pin\n");
   puts("GP2/T0CKI to update TMR0.  When TMR0 changes, the new value will be displayed.\n");
   puts("Also, you can type a string and the program will echo it back to you.\n");
   puts("Pressing Right-Shift and ESC will stop the emulation.\n");
   puts("Have fun!\n");
   TMR0 = 0;
   lastt0 = TMR0;
   TRIS1 = 0;   /* set as an output */
   for ( ; ; )
      {
      if (TMR0 != lastt0)
         {
         puts("\nNew TMR0: ");
         puthex(TMR0);
         putch('\n');
         lastt0 = TMR0;
         }
      if (!RxData)  /* if we see a start bit */
         {
         ch = getch();
         putch(ch);
         if (index < STRING_SIZE-1)
            buf[index++] = ch;
         if (ch == '\015')
            {
            buf[index] = '\0';
            puts("   You Typed ---> ");
            puts(buf);
            putch('\n');
            index = 0;
            }
         }  /* if (!RxData) */
      if (++bitcount == 0)
         GPIO1 = (gp1_state = !gp1_state);  /* toggle GP1 periodically */
      }  /* for ( ; ; ) */
   }  /* main() */
