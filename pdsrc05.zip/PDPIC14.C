/*
 *  PIC disassembler.
 *
 *  Based on code from PICEMU (P12==12C509A, P84==16F84A, and P14==16f877)
 *  and CODEGEN.
 *
 *  This is the 14-bit PICOPS stuff.  All common routines between PDPIC12.C
 *  and PDPIC14.C will be put in PDPIC12.C
 *
 *  Note the use of STATIC on function definitions to keep them local to
 *  this sourcefile (i.e. not in the link map).  This allows common routine
 *  names between PDPIC12.C and PDPIC14.C.
 *
 *  Copyright (c) 2002
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICDIS
 *
 *  PICDIS is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICDIS is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  Date      Comments
 *  --------  -------------------------------------------
 *  6/12/02   Start programming
 *  8/11/03   Update to add 12F675
 */
#include <picdis.h>

#define PIC_DECODE_BITS 6

#define PCLATH_MASK  0x1f
#define PCLATH_GOTOCALL_MASK 0x18  /* bits 3..4 are bits 11..12 of address for GOTO/CALL */
#define PCLATH_BITSHIFT 8    /* must be moved 8 bits */

#define FSR_MASK 0xff               /* maximum index into memory */
#define STATUS_IRP 0x80 /* register bank for indirect addressing (14-bit) */

#define STATUS_MEMORYPAGE_BITMASK 0x60  /* (STATUS_RP0|STATUS_RP1) */  /* 0110 0000 : bits 6 .. 5 */
#define STATUS_MEMORYPAGE_BITSHIFT 2    /* to move page bits to high byte of word */

#define BITNUM_MASK 0x0380          /* isolate bitnumber from instr */
#define BITNUM_POSITION 7           /* shift to move bitnum to bottom of word */

#define GOTO_MASK 0x07ff  /* mask 11 bits of GOTO destination from opcode */
#define CALL_MASK 0x07ff  /* mask 11 bits of CALL destination from opcode */

#define STATUS_C     0x01 /* bit mask */
#define STATUS_DC    0x02 /* bit mask */
#define STATUS_Z     0x04 /* bit mask */

extern BYTE w;       /* the W register */
extern BYTE wknown;  /* are contents of W known? */
extern WORD ip;            /* address of this instruction */
extern WORD next_ip;       /* where we're going next */
extern WORD opcode;        /* opcode we're working on */
extern WORD instr_type;    /* instruction bits from opcode */
extern WORD filenum;       /* index into regs */
extern WORD filenum_temp;  /* bank select bits + filenum */
extern WORD filenum_temp2; /* filenum_temp via xlat_regs[] */
extern WORD dest;          /* 1=destination is F (register File) 0=destination is W */

extern WORD statushold;    /* hold for status flags */
extern WORD statusknownhold;  /* hold for status known flags */
extern BYTE temp1;         /* useful to have around */
extern BYTE temp2;         /* useful to have around */

extern WORD skip_find_new_thread;
extern WORD skip_label_regs_unknown;
extern WORD show_address_mask;

extern WORD *xlate_regs;

extern WORD hex_equivalent_of_named_regs;

extern WORD pictype;    /* which PIC is target */
extern BYTE regs[];
extern BYTE regsknown[];
extern WORD memory[];
extern BYTE memoryknown[];
extern WORD memory_size[PIC_MAX+1];
extern WORD ram_size[PIC_MAX+1];
extern WORD regindex_mask[PIC_MAX+1];
extern BYTE has_irp[PIC_MAX+1];
extern struct rnames *regnames[PIC_MAX+1];
extern WORD mapspace;
extern WORD knownstack;   /* segment used to hold the "known values" stack */
extern WORD knownstackptr;  /* stackpointer for "known values" */

extern BYTE instr_str[STRING_SIZE];  /* disassembled instruction */

extern WORD bittable[8];  /* bit mask, indexed by bit number */

extern BYTE getfileknown, fileaddrknown;
extern BYTE regval, regvalknown;

WORD peekw(), peekb();
void pokew(), pokeb();

extern struct rnames names675[256];
extern struct rnames names84a[256];
extern struct rnames names628[512];
extern struct rnames names877[512];

static void w_reg()
   {
   regs[filenum_temp2] = regval;
   regsknown[filenum_temp2] = regvalknown;
   }

static void w_status()
   {
   regs[STATUS] = (regs[STATUS] & 0x18) | (regval & 0xe7);
      /* cannot set !TO, !PD bits */
      /* bit 6 not implemented */
   regsknown[STATUS] = regvalknown & 0xe7;
   }

static void w_pcl()
   {
   WORD new_ip;

   regs[PCL] = regval;
   regsknown[PCL] = regvalknown;
   SETCFLAG(ip,PROG_INDIRECT);  /* indirect reference to program memory */
   if ((regvalknown == ALLBITS_KNOWN) && ((regsknown[PCLATH] & PCLATH_MASK) == PCLATH_MASK))
                    /* if we know where we're going! */
      {
      new_ip = ((WORD)regs[PCLATH] << 8) + (WORD)regs[PCL];
      SETCFLAG(new_ip,PROG_LABEL);
      save_mem_addr(new_ip);
      }
   find_new_thread();
   }

static void w_pclath()
   {
   regs[filenum_temp2] = regval & PCLATH_MASK;
   regsknown[filenum_temp2] = regvalknown & PCLATH_MASK;
   }

static void w_4bits()
   {
   regs[filenum_temp2] = regval & 0x0f;
   regsknown[filenum_temp2] = regvalknown & 0x0f;
   }

static void w_5bits()
   {
   regs[filenum_temp2] = regval & 0x1f;
   regsknown[filenum_temp2] = regvalknown & 0x1f;
   }

static void w_6bits()
   {
   regs[filenum_temp2] = regval & 0x3f;
   regsknown[filenum_temp2] = regvalknown & 0x3f;
   }

static void w_7bits()
   {
   regs[filenum_temp2] = regval & 0x7f;
   regsknown[filenum_temp2] = regvalknown & 0x7f;
   }

static void w_628trisa()
   {
   regs[filenum_temp2] = regval & 0xdf;
   regsknown[filenum_temp2] = regvalknown & 0xdf;
   }

static void w_675pir1()
   {
   regs[filenum_temp2] = regval & 0xc9;
   regsknown[filenum_temp2] = regvalknown & 0xc9;
   }

static void w_675cmcon()
   {
   regs[filenum_temp2] = regval & 0x5f;
   regsknown[filenum_temp2] = regvalknown & 0x5f;
   }

static void w_675adcon0()
   {
   regs[filenum_temp2] = regval & 0xcf;
   regsknown[filenum_temp2] = regvalknown & 0xcf;
   }

static void w_675pcon()
   {
   regs[filenum_temp2] = regval & 0x03;
   regsknown[filenum_temp2] = regvalknown & 0x03;
   }

static void w_675osccal()
   {
   regs[filenum_temp2] = regval & 0xfc;
   regsknown[filenum_temp2] = regvalknown & 0xfc;
   }

static void w_675wpu()
   {
   regs[filenum_temp2] = regval & 0xc7;
   regsknown[filenum_temp2] = regvalknown & 0xc7;
   }

static void w_675vrcon()
   {
   regs[filenum_temp2] = regval & 0xaf;
   regsknown[filenum_temp2] = regvalknown & 0xaf;
   }

static void w_none()
   {
   }

void (*writep877[512])() =
   {
      /* BANK 0 */
   /* 00     01      02     03        04     05       06     07 */
   w_none, w_none, w_pcl, w_status, w_reg, w_none, w_none, w_none,
   /* 08      09       0a        0b     0c      0d      0e      0f */
   w_none, w_none,  w_pclath, w_reg, w_none, w_none, w_none, w_none,
   /* 10      11      12       13     14     15        16        17 */
   w_none,  w_none, w_none,  w_reg, w_reg, w_none,   w_none,   w_none,
   /* 18      19       1a     1b        1c        1d         1e     1f */
   w_none,  w_reg,   w_none,w_none,   w_none,   w_none,    w_none,w_none,
   /* 20     21     22     23     24     25     26     27 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 28     29     2a     2b     2c     2d     2e     2f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 30     31     32     33     34     35     36     37 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 38     39     3a     3b     3c     3d     3e     3f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 40     41     42     43     44     45     46     47 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 48     49     4a     4b     4c     4d     4e     4f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 50     51     52     53     54     55     56     57 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 58     59     5a     5b     5c     5d     5e     5f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 60     61     62     63     64     65     66     67 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 68     69     6a     6b     6c     6d     6e     6f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 70     71     72     73     74     75     76     77 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 78     79     7a     7b     7c     7d     7e     7f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
       /* BANK 1 */
   /* 80     81        82     83        84     85       86       87 */
   w_none, w_reg,    w_pcl, w_status, w_reg, w_6bits, w_reg,   w_reg,
   /* 88      89       8a         8b    8c     8d      8e     8f */
   w_reg,   w_none,  w_pclath, w_reg, w_reg, w_none, w_none, w_none,
   /* 90     91     92     93     94     95      96      97 */
   w_none, w_reg, w_reg, w_reg, w_none,w_none, w_none, w_none,
   /* 98      99       9a      9b      9c      9d      9e      9f */
   w_none,  w_reg,   w_none, w_none, w_none, w_none, w_none,w_none,
   /* a0     a1     a2     a3     a4     a5     a6     a7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* a8     a9     aa     ab     ac     ad     ae     af */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* b0     b1     b2     b3     b4     b5     b6     b7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* b8     b9     ba     bb     bc     bd     be     bf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* c0     c1     c2     c3     c4     c5     c6     c7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* c8     c9     ca     cb     cc     cd     ce     cf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* d0     d1     d2     d3     d4     d5     d6     d7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* d8     d9     da     db     dc     dd     de     df */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* e0     e1     e2     e3     e4     e5     e6     e7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* e8     e9     ea     eb     ec     ed     ee     ef */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* f0     f1     f2     f3     f4     f5     f6     f7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* f8     f9     fa     fb     fc     fd     fe     ff */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,

      /* BANK 2 */
   /* 100    101     102    103       104    105     106      107 */
   w_none, w_none, w_pcl, w_status, w_reg, w_none, w_none,  w_none,
   /* 108    109     10a       10b    10c      10d      10e       10f */
   w_none, w_none, w_pclath, w_reg, w_none,  w_none,  w_none,   w_none,
   /* 110   111    112    113    114    115    116    117 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 118   119    11a    11b    11c    11d    11e    11f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 120   121    122    123    124    125    126    127 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 128   129    12a    12b    12c    12d    12e    12f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 130   131    132    133    134    135    136    137 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 138   139    13a    13b    13c    13d    13e    13f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 140   141    142    143    144    145    146    147 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 148   149    14a    14b    14c    14d    14e    14f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 150   151    152    153    154    155    156    157 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 158   159    15a    15b    15c    15d    15e    15f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 160   161    162    163    164    165    166    167 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 168   169    16a    16b    16c    16d    16e    16f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 170   171    172    173    174    175    176    177 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 178   179    17a    17b    17c    17d    17e    17f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
      /* BANK 3 */
   /* 180    181       182    183       184    185     186      187 */
   w_none, w_reg,    w_pcl, w_status, w_reg, w_none, w_reg,   w_none,
   /* 188    189     18a       18b    18c       18d       18e     18f */
   w_none, w_none, w_pclath, w_none,w_none,   w_none,   w_none, w_none,
   /* 190   191    192    193    194    195    196    197 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 198   199    19a    19b    19c    19d    19e    19f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1a0   1a1    1a2    1a3    1a4    1a5    1a6    1a7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1a8   1a9    1aa    1ab    1ac    1ad    1ae    1af */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1b0   1b1    1b2    1b3    1b4    1b5    1b6    1b7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1b8   1b9    1ba    1bb    1bc    1bd    1be    1bf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1c0   1c1    1c2    1c3    1c4    1c5    1c6    1c7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1c8   1c9    1ca    1cb    1cc    1cd    1ce    1cf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1d0   1d1    1d2    1d3    1d4    1d5    1d6    1d7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1d8   1d9    1da    1db    1dc    1dd    1de    1df */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1e0   1e1    1e2    1e3    1e4    1e5    1e6    1e7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1e8   1e9    1ea    1eb    1ec    1ed    1ee    1ef */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1f0   1f1    1f2    1f3    1f4    1f5    1f6    1f7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1f8   1f9    1fa    1fb    1fc    1fd    1fe    1ff */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg
   };

void (*writep628[512])() =
   {
      /* BANK 0 */
   /* 00     01      02     03        04     05       06     07 */
   w_none, w_none, w_pcl, w_status, w_reg, w_none, w_none, w_none,
   /* 08      09       0a        0b     0c      0d      0e      0f */
   w_none, w_none,  w_pclath, w_reg, w_none, w_none, w_none, w_none,
   /* 10      11      12       13      14     15        16        17 */
   w_none,  w_none, w_none,  w_none w_none, w_none,   w_none,   w_none,
   /* 18      19       1a     1b        1c        1d         1e     1f */
   w_none,  w_reg,   w_none,w_none,   w_none,   w_none,    w_none,w_none,
   /* 20     21     22     23     24     25     26     27 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 28     29     2a     2b     2c     2d     2e     2f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 30     31     32     33     34     35     36     37 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 38     39     3a     3b     3c     3d     3e     3f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 40     41     42     43     44     45     46     47 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 48     49     4a     4b     4c     4d     4e     4f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 50     51     52     53     54     55     56     57 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 58     59     5a     5b     5c     5d     5e     5f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 60     61     62     63     64     65     66     67 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 68     69     6a     6b     6c     6d     6e     6f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 70     71     72     73     74     75     76     77 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 78     79     7a     7b     7c     7d     7e     7f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
       /* BANK 1 */
   /* 80     81        82     83        84     85          86       87 */
   w_none, w_reg,    w_pcl, w_status, w_reg, w_628trisa, w_reg,   w_none,
   /* 88      89       8a         8b    8c      8d      8e     8f */
   w_none,  w_none,  w_pclath, w_reg, w_none, w_none, w_none, w_none,
   /* 90     91      92     93      94     95      96      97 */
   w_none, w_none, w_reg, w_none, w_none,w_none, w_none, w_none,
   /* 98      99       9a      9b      9c      9d      9e      9f */
   w_none,  w_reg,   w_none, w_none, w_none, w_none, w_none,w_none,
   /* a0     a1     a2     a3     a4     a5     a6     a7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* a8     a9     aa     ab     ac     ad     ae     af */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* b0     b1     b2     b3     b4     b5     b6     b7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* b8     b9     ba     bb     bc     bd     be     bf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* c0     c1     c2     c3     c4     c5     c6     c7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* c8     c9     ca     cb     cc     cd     ce     cf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* d0     d1     d2     d3     d4     d5     d6     d7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* d8     d9     da     db     dc     dd     de     df */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* e0     e1     e2     e3     e4     e5     e6     e7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* e8     e9     ea     eb     ec     ed     ee     ef */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* f0     f1     f2     f3     f4     f5     f6     f7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* f8     f9     fa     fb     fc     fd     fe     ff */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,

      /* BANK 2 */
   /* 100    101     102    103       104    105     106      107 */
   w_none, w_none, w_pcl, w_status, w_reg, w_none, w_none,  w_none,
   /* 108    109     10a       10b    10c      10d      10e       10f */
   w_none, w_none, w_pclath, w_reg, w_none,  w_none,  w_none,   w_none,
   /* 110    111     112     113     114     115     116     117 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 118    119     11a     11b     11c     11d     11e     11f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 120   121    122    123    124    125    126    127 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 128   129    12a    12b    12c    12d    12e    12f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 130   131    132    133    134    135    136    137 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 138   139    13a    13b    13c    13d    13e    13f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 140   141    142    143    144    145    146    147 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 148   149    14a    14b    14c    14d    14e    14f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 150    151     152     153     154     155     156     157 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 158    159     15a     15b     15c     15d     15e     15f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 160    161     162     163     164     165     166     167 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 168    169     16a     16b     16c     16d     16e     16f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 170   171    172    173    174    175    176    177 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 178   179    17a    17b    17c    17d    17e    17f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
      /* BANK 3 */
   /* 180    181       182    183       184    185     186      187 */
   w_none, w_reg,    w_pcl, w_status, w_reg, w_none, w_reg,   w_none,
   /* 188    189     18a       18b    18c       18d       18e     18f */
   w_none, w_none, w_pclath, w_none,w_none,   w_none,   w_none, w_none,
   /* 190    191     192     193     194     195     196     197 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 198    199     19a     19b     19c     19d     19e     19f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1a0    1a1     1a2     1a3     1a4     1a5     1a6     1a7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1a8    1a9     1aa     1ab     1ac     1ad     1ae     1af */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1b0    1b1     1b2     1b3     1b4     1b5     1b6     1b7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1b8    1b9     1ba     1bb     1bc     1bd     1be     1bf */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1c0    1c1     1c2     1c3     1c4     1c5     1c6     1c7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1c8    1c9     1ca     1cb     1cc     1cd     1ce     1cf */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1d0    1d1     1d2     1d3     1d4     1d5     1d6     1d7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1d8    1d9     1da     1db     1dc     1dd     1de     1df */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1e0    1e1     1e2     1e3     1e4     1e5     1e6     1e7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1e8    1e9     1ea     1eb     1ec     1ed     1ee     1ef */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 1f0   1f1    1f2    1f3    1f4    1f5    1f6    1f7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 1f8   1f9    1fa    1fb    1fc    1fd    1fe    1ff */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg
   };

void (*writep675[256])() =
   {
      /* BANK 0 */
   /* 00     01      02     03        04     05       06       07 */
   w_none, w_none, w_pcl, w_status, w_reg, w_5bits, w_none,  w_none,
   /* 08       09       0a        0b     0c        0d    0e     0f */
   w_none,  w_none,  w_pclath, w_reg, w_675pir1, w_none,w_reg, w_reg,
   /* 10      11     12     13     14     15     16     17 */
   w_7bits, w_none,w_none,w_none,w_none,w_none,w_none,w_none,
   /* 18     19         1a     1b     1c     1d     1e     1f */
   w_none,w_675cmcon, w_none,w_none,w_none,w_none,w_reg, w_675adcon0,
   /* 20     21     22     23     24     25     26     27 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 28     29     2a     2b     2c     2d     2e     2f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 30     31     32     33     34     35     36     37 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 38     39     3a     3b     3c     3d     3e     3f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 40     41     42     43     44     45     46     47 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 48     49     4a     4b     4c     4d     4e     4f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 50     51      52      53      54      55      56      57 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 58     59      5a      5b      5c      5d      5e      5f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 60     61      62      63      64      65      66      67 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 68     69      6a      6b      6c      6d      6e      6f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 70     71      72      73      74      75      76      77 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 78     79      7a      7b      7c      7d      7e      7f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
       /* BANK 1 -- only SFR's are 'real' */
   /* 80     81        82     83        84     85       86       87 */
   w_none, w_reg,    w_pcl, w_status, w_reg, w_5bits, w_none,  w_none,
   /* 88       89        8a        8b     8c         8d     8e         8f */
   w_none,   w_none,   w_pclath, w_reg, w_675pir1, w_reg, w_675pcon, w_none,
   /* 90          91     92     93     94     95        96       97 */
   w_675osccal, w_none,w_none,w_none,w_none,w_675wpu, w_5bits, w_none,
   /* 98     99         9a     9b       9c       9d     9e     9f */
   w_none,w_675vrcon, w_reg, w_7bits, w_4bits, w_reg, w_reg, w_7bits,
   /* a0     a1     a2     a3     a4     a5     a6     a7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* a8     a9     aa     ab     ac     ad     ae     af */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* b0     b1     b2     b3     b4     b5     b6     b7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* b8     b9     ba     bb     bc     bd     be     bf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* c0     c1     c2     c3     c4     c5     c6     c7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* c8     c9     ca     cb     cc     cd     ce     cf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* d0     d1      d2      d3      d4      d5      d6      d7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* d8     d9      da      db      dc      dd      de      df */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* e0     e1      e2      e3      e4      e5      e6      e7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* e8     e9      ea      eb      ec      ed      ee      ef */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* f0     f1      f2      f3      f4      f5      f6      f7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* f8     f9      fa      fb      fc      fd      fe      ff */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none
   };

void (*writep84[256])() =
   {
      /* BANK 0 */
   /* 00     01      02     03        04     05       06       07 */
   w_none, w_none, w_pcl, w_status, w_reg, w_none,  w_none,  w_none,
   /* 08       09       0a        0b     0c     0d    0e     0f */
   w_none,  w_none,  w_pclath, w_none,w_reg, w_reg, w_reg, w_reg,
   /* 10     11     12     13     14     15     16     17 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 18     19     1a     1b     1c     1d     1e     1f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 20     21     22     23     24     25     26     27 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 28     29     2a     2b     2c     2d     2e     2f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 30     31     32     33     34     35     36     37 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 38     39     3a     3b     3c     3d     3e     3f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 40     41     42     43     44     45     46     47 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 48     49     4a     4b     4c     4d     4e     4f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 50     51      52      53      54      55      56      57 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 58     59      5a      5b      5c      5d      5e      5f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 60     61      62      63      64      65      66      67 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 68     69      6a      6b      6c      6d      6e      6f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 70     71      72      73      74      75      76      77 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* 78     79      7a      7b      7c      7d      7e      7f */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
       /* BANK 1 -- only TRISA, TRISB, EECON1, and EECON2 are 'real' */
   /* 80     81        82     83        84     85       86       87 */
   w_none, w_reg,    w_pcl, w_status, w_reg, w_5bits, w_reg,   w_none,
   /* 88       89        8a        8b     8c     8d     8e     8f */
   w_none,   w_none,   w_pclath, w_none,w_reg, w_reg, w_reg, w_reg,
   /* 90     91     92     93     94     95     96     97 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 98     99     9a     9b     9c     9d     9e     9f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* a0     a1     a2     a3     a4     a5     a6     a7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* a8     a9     aa     ab     ac     ad     ae     af */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* b0     b1     b2     b3     b4     b5     b6     b7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* b8     b9     ba     bb     bc     bd     be     bf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* c0     c1     c2     c3     c4     c5     c6     c7 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* c8     c9     ca     cb     cc     cd     ce     cf */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* d0     d1      d2      d3      d4      d5      d6      d7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* d8     d9      da      db      dc      dd      de      df */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* e0     e1      e2      e3      e4      e5      e6      e7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* e8     e9      ea      eb      ec      ed      ee      ef */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* f0     f1      f2      f3      f4      f5      f6      f7 */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none,
   /* f8     f9      fa      fb      fc      fd      fe      ff */
   w_none, w_none, w_none, w_none, w_none, w_none, w_none, w_none
   };

static void (*writetbl[PIC_MAX+1])() = { writep675,  writep675,  writep84,  writep628,  writep877 };
static void (**writeregs)();

static BYTE read_regs()
   {
   WORD indf_fak_hold;
   WORD indf_fn_t2_hold;
   BYTE result,indf_flag;

   indf_flag = FALSE;
   writeregs = writetbl[pictype];   /* ptr to functions for this PIC core */
   filenum_temp2 = xlate_regs[filenum_temp];  /* lookup actual reg index */
/*
if ((ip == 0) || (ip == 2))
   {
   printf("r_r14(): filenum = %02x  filenum_temp = %02x  filenum_temp2 = %02x\n",
      filenum,filenum_temp,filenum_temp2);
   ci();
   }
*/
   if (filenum_temp2 == INDF)  /* if indirect */
      {
      indf_flag = TRUE;
      indf_fak_hold = fileaddrknown;
      indf_fn_t2_hold = filenum_temp2;
      if (regsknown[FSR] != ALLBITS_KNOWN)
         fileaddrknown = FALSE;
      else
         {
         if (has_irp[pictype])
            {
            if ((regsknown[STATUS] & STATUS_IRP)
                     || (xlate_regs[(WORD)regs[FSR]] == xlate_regs[(WORD)regs[FSR]+0x100]))
                              /* if known, or pagebank doesn't matter */
               filenum_temp2 = xlate_regs[(WORD)regs[FSR] + (((WORD)regs[STATUS] & STATUS_IRP) << 1)];
            else
               fileaddrknown = FALSE;
            }
         else
            filenum_temp2 = xlate_regs[(WORD)regs[FSR]];
         }
      }
   if (!fileaddrknown)
      {
      getfileknown = ALLBITS_UNKNOWN;
      if (indf_flag)
         {
         fileaddrknown = indf_fak_hold;
         filenum_temp2 = indf_fn_t2_hold;
         }
      return(0);
      }
   getfileknown = regsknown[filenum_temp2];
   result = regs[filenum_temp2];
   if (indf_flag)
      {
      fileaddrknown = indf_fak_hold;
      filenum_temp2 = indf_fn_t2_hold;
      }
   return(result);
   }

static void write_regs()
   {
   WORD indf_fak_hold;
   WORD indf_fn_t2_hold;
   BYTE result,indf_flag;

   indf_flag = FALSE;
   writeregs = writetbl[pictype];   /* ptr to functions for this PIC core */
   filenum_temp2 = xlate_regs[filenum_temp];  /* lookup actual reg index */
/*
if ((ip == 0) || (ip == 2))
   {
   printf("w_r14(): filenum = %02x  filenum_temp = %02x  filenum_temp2 = %02x\n",
      filenum,filenum_temp,filenum_temp2);
   ci();
   }
*/
   if (filenum_temp2 == INDF)  /* if indirect */
      {
      indf_flag = TRUE;
      indf_fak_hold = fileaddrknown;
      indf_fn_t2_hold = filenum_temp2;
      if (regsknown[FSR] != ALLBITS_KNOWN)
         fileaddrknown = FALSE;
      else
         {
         if (has_irp[pictype])
            {
            if ((regsknown[STATUS] & STATUS_IRP)
                     || (xlate_regs[(WORD)regs[FSR]] == xlate_regs[(WORD)regs[FSR]+0x100]))
                              /* if known, or pagebank doesn't matter */
               filenum_temp2 = xlate_regs[(WORD)regs[FSR] + (((WORD)regs[STATUS] & STATUS_IRP) << 1)];
            else
               fileaddrknown = FALSE;
            }
         else
            filenum_temp2 = xlate_regs[(WORD)regs[FSR]];
         }
      }
   if (fileaddrknown)
      (*writeregs[filenum_temp2])();
   if (indf_flag)
      {
      fileaddrknown = indf_fak_hold;
      filenum_temp2 = indf_fn_t2_hold;
      }
   }

static BYTE getfile()  /* assumes filenum contains index into register file */
   {
   WORD i, pageflag;

   getfileknown = ALLBITS_UNKNOWN;
   fileaddrknown = FALSE;
   if ((regsknown[STATUS] & STATUS_MEMORYPAGE_BITMASK) == STATUS_MEMORYPAGE_BITMASK)
                 /* if we know what memory page this is */
      {
      filenum_temp = (((WORD)regs[STATUS] & STATUS_MEMORYPAGE_BITMASK) << STATUS_MEMORYPAGE_BITSHIFT) + filenum;
      fileaddrknown = TRUE;
      return(read_regs());  /* getfileknown updated as needed */
      }
   pageflag = TRUE;  /* default: page does not matter */
   for (i = filenum; i < ram_size[pictype]; i += regindex_mask[pictype] + 1)
      if (xlate_regs[filenum] != xlate_regs[i])
         {
         pageflag = FALSE;
         break;
         }
   if (pageflag)  /* if the page doesn't matter */
      {
      filenum_temp = filenum;
      fileaddrknown = TRUE;
      return(read_regs());  /* getfileknown updated as needed */
      }
   return(0);
   }

/*
WORD doing_bcf;
*/
static void setfile(val) /* assumes filenum contains index into register file */
   WORD val;
   {
   WORD i, pageflag;

   fileaddrknown = FALSE;
   regval = val;  /* set global for easy access */
/*
if (doing_bcf)
   printf("rk[STATUS]=%02x (&%02x=%02x)\n",regsknown[STATUS],STATUS_MEMORYPAGE_BITMASK,
         regsknown[STATUS]&STATUS_MEMORYPAGE_BITMASK);
*/
   if ((regsknown[STATUS] & STATUS_MEMORYPAGE_BITMASK) == STATUS_MEMORYPAGE_BITMASK)
                 /* if we know what memory page this is */
      {
      filenum_temp = (((WORD)regs[STATUS] & STATUS_MEMORYPAGE_BITMASK) << STATUS_MEMORYPAGE_BITSHIFT) + filenum;
      fileaddrknown = TRUE;
      write_regs();
      }
   else
     {
/*
if (doing_bcf)
   printf("Checking pages...\n");
*/
      pageflag = TRUE;  /* default: page does not matter */
      for (i = filenum; i < ram_size[pictype]; i += regindex_mask[pictype] + 1)
         if (xlate_regs[filenum] != xlate_regs[i])
            {
/*
if (doing_bcf)
   printf("xlate mismatch:  filenum=%02x  i=%02x  xl_r[f]=%02x  xl_r[i]=%02x\n",
      filenum,i,xlate_regs[filenum],xlate_regs[i]);
*/
            pageflag = FALSE;
            break;
            }
      if (pageflag)  /* if the page doesn't matter */
         {
         fileaddrknown = TRUE;  /* don't confuse write_regs() */
         filenum_temp = filenum;
         write_regs();
         fileaddrknown = FALSE;  /* we really don't know the correct address */
         }
      }
   }

static void controls_14bit()
      /* 14bit:    000000 xxxx xxxx = NOP/RETURN/RETFIE/OPTION/SLEEP/CLRWDT/TRIS/MOVWF
       * filenum = ...... .fff ffff
       * dest    = ...... d... ....
       * NOP     = 000000 0xx0 0000
       * RETURN  = 000000 0000 1000  (0x0008)
       * RETFIE  = 000000 0000 1001  (0x0009)
       * OPTION  = 000000 0110 0010  (0x0062)
       * SLEEP   = 000000 0110 0011  (0x0063)
       * CLRWDT  = 000000 0110 0100  (0x0064)
       * TRIS    = 000000 0110 0fff  <only fff=5, 6, 7 valid> (0x0065, 66, 67)
       * MOVWF   = 000000 1fff ffff
       *   <unused opcodes will default to NOP>
       */
   {
   if (dest)  /* if dest set, this must be MOVWF */
      {
      regvalknown = wknown;
      setfile(w);
      if (fileaddrknown)
         save_f_addr();
      }
   else
      {
      switch (filenum)
         {
         case 0x0008:  /* RETURN */
            find_new_thread();
            break;
         case 0x0009:  /* RETFIE */
            find_new_thread();
            break;
         case 0x0062:  /* OPTION */
            filenum_temp = OPTION;
            regval = w;
            regvalknown = wknown;
            write_regs();
            break;
         case 0x0063:  /* SLEEP */
            /* we can wake up from a sleep without a reset */
            break;
         case 0x0064:  /* CLRWDT */
            break;
         case 0x0065:  /* TRIS A */
            filenum_temp = TRISA;
            regval = w;  /* set global for easy access */
            regvalknown = wknown;
            write_regs();  /* set TRIS A register */
            break;
         case 0x0066:  /* TRIS B */
            filenum_temp = TRISB;
            regval = w;  /* set global for easy access */
            regvalknown = wknown;
            write_regs();  /* set TRIS B register */
            break;
         case 0x0067:  /* TRIS C */
            break;  /* not everyone has a PORT C */
         }
      }  /* if (dest) ... else */
   }

static void clr_14bit()
      /* CLRW / CLRF = 000001 xxxx xxxx = CLRW / CLRF
       * filenum     = ...... .xxx xxxx
       * dest        = ...... x... ....
       * CLRW        = 000001 0000 0000 <actually, 000001 0xxx xxxx>
       * CLRF        = 000001 1fff ffff
       */
   {
/*
if (filenum == 3)
   printf("\nrk[STATUS] = %02x\n",regsknown[STATUS]);
*/
   statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
   statusknownhold = regsknown[STATUS] & STATUS_FLAGBITS;
   if (!dest)  /* if W is destination */
      {
      w = 0;  /* clear w */
      wknown = ALLBITS_KNOWN;
      }
   else
      {
      regvalknown = ALLBITS_KNOWN;
      setfile(0);  /* set "filenum" to 0, set Z */
/*
if ((ip == 0) || (ip == 2))
   {
   printf("\nclr_14bit() ip=%d  filenum=%02x  fileaddrknown=%02x  filenum_temp2=%02x\n",
       ip,filenum,fileaddrknown,filenum_temp2);
   ci();
   }
*/
      if (fileaddrknown)
         save_f_addr();
      }
   regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
/*
if (filenum == 3)
   printf("rk[STATUS] = %02x (&%02x=%02x | %02x | %02x)",
        regsknown[STATUS],STATUS_OTHERBITS,
        regsknown[STATUS]&STATUS_OTHERBITS,
        STATUS_Z,statusknownhold);
*/
   regsknown[STATUS] = (regsknown[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statusknownhold;  /* we know that Z is set */
/*
if (filenum == 3)
   printf(" = %02x\n",regsknown[STATUS]);
*/
   }

static void subwf()            /* 000010 dfff ffff = SUBWF */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   temp2 = temp1 - w;
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      calcflags_sub(temp1,w,temp2);
      regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | statushold;
      regsknown[STATUS] |= STATUS_FLAGBITS;  /* we know the flagbits */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_FLAGBITS;  /* we do not know the flagbits */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void decf()             /* 000011 dfff ffff = DECF */
   {
   temp2 = getfile() - 1;
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void iorwf()            /* 000100 dfff ffff = IORWF */
   {
   temp2 = getfile() | w;
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void andwf()            /* 000101 dfff ffff = ANDWF */
   {
   temp2 = getfile() & w;
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void xorwf()            /* 000110 dfff ffff = XORWF */
   {
   temp2 = getfile() ^ w;
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void addwf()            /* 000111 dfff ffff = ADDWF */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   temp2 = temp1 + w;
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      calcflags_add(temp1,w,temp2);
      regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | statushold;
      regsknown[STATUS] |= STATUS_FLAGBITS;  /* we know the flagbits */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_FLAGBITS;  /* we do not know the flagbits */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void movf()             /* 001000 dfff ffff = MOVF */
   {
   temp2 = getfile();
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void comf()             /* 001001 dfff ffff = COMF */
   {
   temp2 = ~getfile();
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void incf()             /* 001010 dfff ffff = INCF */
   {
   temp2 = getfile() + 1;
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void decfsz()           /* 001011 dfff ffff = DECFSZ */
   {
   temp2 = getfile() - 1;
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      temp1 = ALLBITS_UNKNOWN;
      }
   skip_find_new_thread = SKIP_VAL;  /* setup for SKIP */
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void rrf()              /* 001100 dfff ffff = RRF */
   {
   temp1 = getfile();  /* get value to rotate */
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (regsknown[STATUS] & STATUS_C))
      {
      temp2 = temp1 >> 1;  /* start of rotation */
      if ((statushold=regs[STATUS] & STATUS_FLAGBITS) & STATUS_C)  /* get flag values and check C */
         temp2 |= BIT7;  /* if C, put it in highbit of result */
      if (temp1 & 1)  /* set C out of lowbit */
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_C | statushold;
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_C & statushold);
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_C;  /* don't know C flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void rlf()              /* 001101 dfff ffff = RLF */
   {
   temp1 = getfile();  /* get value to rotate */
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (regsknown[STATUS] & STATUS_C))
      {
      temp2 = temp1 << 1;  /* start of rotation */
      if ((statushold=regs[STATUS] & STATUS_FLAGBITS) & STATUS_C)  /* get flag values and check C */
         temp2 |= BIT0;  /* if C, put it in lowbit of result */
      if (temp1 & BIT7)  /* set C out of highbit */
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_C | statushold;
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_C & statushold);
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_C;  /* don't know C flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void swapf()            /* 001110 dfff ffff = SWAPF */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      temp2 = (temp1 >> 4) + (temp1 << 4);  /* swap nibbles */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void incfsz()           /* 001111 dfff ffff = INCFSZ */
   {
   temp2 = getfile() + 1;
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      temp1 = ALLBITS_UNKNOWN;
      }
   skip_find_new_thread = SKIP_VAL;  /* setup for SKIP */
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void bcf()              /* 0100bb bfff ffff = BCF <00b> */
   {
   WORD bitnum;

   bitnum = (opcode & BITNUM_MASK) >> BITNUM_POSITION;
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   regvalknown = getfileknown | bittable[bitnum];  /* we know what this bit is */
/*
printf("\nBCF() fk=%d  rvknown=%02x  val=%02x  f=%02x  f_temp=%02x  f_temp2=%02x rk[a]=%02x\n",
   fileaddrknown,regvalknown,temp1&~bittable[bitnum],filenum,filenum_temp,filenum_temp2,regsknown[PCLATH]);
doing_bcf = TRUE;
*/
   setfile(temp1 & ~bittable[bitnum]);
/*
doing_bcf = FALSE;
printf("  fk=%d  rvknown=%02x  val=%02x  f=%02x  f_temp=%02x  f_temp2=%02x rk[a]=%02x\n",
   fileaddrknown,regvalknown,temp1&~bittable[bitnum],filenum,filenum_temp,filenum_temp2,regsknown[PCLATH]);
*/
   }

static void bsf()              /* 0101bb bfff ffff = BSF <00b> */
   {
   WORD bitnum;

   bitnum = (opcode & BITNUM_MASK) >> BITNUM_POSITION;
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   regvalknown = getfileknown | bittable[bitnum];  /* we know what this bit is */
/*
printf("\nBSF() bitnum=%d fk=%d  rvknown=%02x  val=%02x  f=%02x  f_temp=%02x  f_temp2=%02x rk[a]=%02x\n",
   bitnum,
   fileaddrknown,regvalknown,temp1&~bittable[bitnum],filenum,filenum_temp,filenum_temp2,regsknown[PCLATH]);
ci();
*/
   setfile(temp1 | bittable[bitnum]);
   }

static void btfsc()            /* 0110bb bfff ffff = BTFSC <00b> */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   skip_find_new_thread = SKIP_VAL;  /* setup for SKIP */
   }

static void btfss()            /* 0111bb bfff ffff = BTFSS <00b> */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   skip_find_new_thread = SKIP_VAL;  /* setup for SKIP */
   }

static void retlw()            /* 1101xx kkkk kkkk = RETLW <kkkk kkkk> */
   {
   find_new_thread();
   }

static void call_14bit()     /* 100kkk kkkk kkkk = CALL <kkk kkkk kkkk> */
   {
   WORD new_ip;

   if (((regsknown[PCLATH] & PCLATH_GOTOCALL_MASK) == PCLATH_GOTOCALL_MASK)
             || ((memory_size[pictype]-1) <= CALL_MASK))
          /* if we know our destination */
      {
      new_ip = ((WORD)(regs[PCLATH] & PCLATH_GOTOCALL_MASK) << PCLATH_BITSHIFT)
                   + (opcode & CALL_MASK);
      SETCFLAG(new_ip,PROG_LABEL);
      save_mem_addr(new_ip);
      if (!(memoryknown[new_ip] & PROG_KNOWN))  /* if not mapped already */
         {
         next_ip = new_ip;  /* start mapping there, WITHOUT FORGETTING REGS! */
         skip_label_regs_unknown = SKIP_VAL;
         ks_push((ip+1)&(memory_size[pictype]-1));
         }
      }
   else
      regs_unknown();  /* anything could happen here */
   }

static void go_to_14bit()    /* 101kkk kkkk kkkk = GOTO <kkk kkkk kkkk> */
   {
   WORD new_ip;
/*
printf("\ngoto:  ip=%04x  regsknown[PCLATH] = %02x & %02x = %02x  skip_find_new_thread=%d\n",
ip,regsknown[PCLATH],PCLATH_GOTOCALL_MASK,regsknown[PCLATH]&PCLATH_GOTOCALL_MASK,
skip_find_new_thread);
ci();
*/

   if (((regsknown[PCLATH] & PCLATH_GOTOCALL_MASK) == PCLATH_GOTOCALL_MASK)
             || ((memory_size[pictype]-1) <= GOTO_MASK))
          /* if we know our destination */
      {
      new_ip = ((WORD)(regs[PCLATH] & PCLATH_GOTOCALL_MASK) << PCLATH_BITSHIFT)
                + (opcode & GOTO_MASK);
      SETCFLAG(new_ip,PROG_LABEL);
      save_mem_addr(new_ip);
      if (!(memoryknown[new_ip] & PROG_KNOWN))  /* if not mapped already */
         {
         next_ip = new_ip;  /* start mapping there, WITHOUT FORGETTING REGS! */
         skip_label_regs_unknown = SKIP_VAL;
         if (skip_find_new_thread)  /* if could be skipped or not */
            ks_push((ip+1)&(memory_size[pictype]-1));
         }
      else
         if (skip_find_new_thread == 0)
            find_new_thread();
      }
   else
      if (skip_find_new_thread == 0)
         find_new_thread();
   }

static void movlw()            /* 1100xx kkkk kkkk = MOVLW <kkkk kkkk> */
   {
   w = opcode;  /* since W is a BYTE, we just get the low 8 bits */
   wknown = ALLBITS_KNOWN;
   }

static void iorlw()            /* 111000 kkkk kkkk = IORLW <kkkk kkkk> */
   {
   w |= opcode;  /* since W is a BYTE, we just use the low 8 bits of opcode */
   if ((opcode & 0xff) == 0xff)  /* if setting ALL bits in w */
      wknown = ALLBITS_KNOWN;
   if (wknown == ALLBITS_KNOWN)
      {
      if (w)
         regs[STATUS] &= ~STATUS_Z;
      else
         regs[STATUS] |= STATUS_Z;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z status */
      }
   else
      regsknown[STATUS] &= ~STATUS_Z;  /* we don't know the Z status */
   }

static void andlw()            /* 111001 kkkk kkkk = ANDLW <kkkk kkkk> */
   {
   w &= opcode;  /* since W is a BYTE, we just use the low 8 bits of opcode */
   if ((opcode & 0xff) == 0x00)  /* if clearing ALL bits in w */
      wknown = ALLBITS_KNOWN;
   if (wknown == ALLBITS_KNOWN)
      {
      if (w)
         regs[STATUS] &= ~STATUS_Z;
      else
         regs[STATUS] |= STATUS_Z;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z status */
      }
   else
      regsknown[STATUS] &= ~STATUS_Z;  /* we don't know the Z status */
   }

static void xorlw()            /* 111010 kkkk kkkk = XORLW <kkkk kkkk> */
   {
   w ^= opcode;  /* since W is a BYTE, we just use the low 8 bits of opcode */
   if (wknown == ALLBITS_KNOWN)
      {
      if (w)
         regs[STATUS] &= ~STATUS_Z;
      else
         regs[STATUS] |= STATUS_Z;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z status */
      }
   else
      regsknown[STATUS] &= ~STATUS_Z;  /* we don't know the Z status */
   }

static void nop()              /* 000000 00 0000 or 000000 0000 0000 or 111011 xxxx xxxx */
   {
   }

static void sublw()            /* 11110x kkkk kkkk = SUBLW <0> */
         /* 14-bit only instruction */
   {
   temp1 = opcode;  /* since temp1 is a BYTE, we just use the low 8 bits of the opcode */
   temp2 = temp1 - w;
   if (wknown == ALLBITS_KNOWN)
      {
      calcflags_sub(temp1,w,temp2);
      regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | statushold;
      regsknown[STATUS] |= STATUS_FLAGBITS;  /* we know the flagbits */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_FLAGBITS;  /* we do not know the flagbits */
      temp1 = ALLBITS_UNKNOWN;
      }
   w = temp2;
   wknown = temp1;
   }

static void addlw()            /* 11111x kkkk kkkk = ADDLW <0> */
         /* 14-bit only instruction */
   {
   temp1 = opcode;  /* since temp1 is a BYTE, we just use the low 8 bits of the opcode */
   temp2 = temp1 + w;
   w = temp2;
   wknown = temp1;
   if (wknown == ALLBITS_KNOWN)
      {
      calcflags_add(temp1,w,temp2);
      regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | statushold;
      regsknown[STATUS] |= STATUS_FLAGBITS;  /* we know the flagbits */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_FLAGBITS;  /* we do not know the flagbits */
      temp1 = ALLBITS_UNKNOWN;
      }
   }
#ifdef NEVERDEF
* static void add_regname()
*    {
*    WORD addr;
* 
*    add_tab();
*    addr = peekw(mapspace,FILEPTR+ip+ip);  /* fileptrs[ip] */
*    if ((memoryknown[ip] & PROG_FADDRKNOWN) && (regnames[pictype][addr].rname))
*                    /* if a name exists */
*       {
*       sprintf(&instr_str[temp1],"%s",regnames[pictype][addr].rname);
*       if (addr > regindex_mask[pictype])
*          sprintf(&instr_str[strlen(instr_str)]," & 0x%02x",regindex_mask[pictype]);
*       tabout(48);
*       sprintf(&instr_str[temp1],";0x%02x",filenum);
*       }
*    else
*       sprintf(&instr_str[temp1],"0x%02x",filenum);
*    if (memoryknown[ip] & PROG_INDIRECT)
*       {
*       tabout(56);
*       if (memoryknown[ip] & PROG_ADDRKNOWN)
*          sprintf(&instr_str[temp1],";H_%04x",peekw(mapspace,ip+ip));  /* memptrs[ip] */
*       else
*          sprintf(&instr_str[temp1],";GOTO xxxx");
*       }
*    }
* 
* static void add_regname_w()
*    {
*    WORD addr;
* 
*    add_tab();
*    addr = peekw(mapspace,FILEPTR+ip+ip);  /* fileptrs[ip] */
*    if ((memoryknown[ip] & PROG_FADDRKNOWN) && (regnames[pictype][addr].rname))
*                    /* if a name exists */
*       {
*       sprintf(&instr_str[temp1],"%s",regnames[pictype][addr].rname);
*       if (addr > regindex_mask[pictype])
*          sprintf(&instr_str[strlen(instr_str)]," & 0x%02x",regindex_mask[pictype]);
*       }
*    else
*       sprintf(&instr_str[temp1],"0x%02x",filenum);
*    sprintf(&instr_str[strlen(instr_str)],",%c",dest ? 'F' : 'W');
*    if ((memoryknown[ip] & PROG_FADDRKNOWN) && (regnames[pictype][addr].rname))
*       {
*       tabout(48);
*       sprintf(&instr_str[temp1],";0x%02x",filenum);
*       }
*    if (memoryknown[ip] & PROG_INDIRECT)
*       {
*       tabout(56);
*       if (memoryknown[ip] & PROG_ADDRKNOWN)
*          sprintf(&instr_str[temp1],";H_%04x",peekw(mapspace,ip+ip));  /* memptrs[ip] */
*       else
*          sprintf(&instr_str[temp1],";GOTO xxxx");
*       }
*    }
#endif

static void add_regname_b()
   {
   WORD addr, bitnum;

   add_tab();
   addr = peekw(mapspace,FILEPTR+ip+ip);  /* fileptrs[ip] */
   if ((memoryknown[ip] & PROG_FADDRKNOWN) && (regnames[pictype][addr].rname))
                   /* if a name exists */
      {
      sprintf(&instr_str[temp1],"%s",regnames[pictype][addr].rname);
      if (addr > regindex_mask[pictype])
         sprintf(&instr_str[strlen(instr_str)]," & 0x%02x",regindex_mask[pictype]);
      }
   else
      sprintf(&instr_str[temp1],"0x%02x",filenum);
   temp1 = strlen(instr_str);  /* get EOS */
   bitnum = (opcode & BITNUM_MASK) >> BITNUM_POSITION;
   if ((memoryknown[ip] & PROG_FADDRKNOWN)
               && (regnames[pictype][addr].bitnames)
               && (regnames[pictype][addr].bitnames[bitnum]))
      sprintf(&instr_str[temp1],",%s",regnames[pictype][addr].bitnames[bitnum]);
   else
      sprintf(&instr_str[temp1],",%d",bitnum);
   if ((memoryknown[ip] & PROG_FADDRKNOWN) && (regnames[pictype][addr].rname)
                  && (hex_equivalent_of_named_regs))
      {
      tabout(48);
      sprintf(&instr_str[temp1],";0x%02x,%d",filenum,bitnum);
      }
   add_indirect_label(ip);
   }

static add_opcode_11bitaddr()  /* add "\t<kkk kkkk kkkk>" */
   {
   WORD addr, flag;

   add_tab();
   if (memoryknown[ip] & PROG_ADDRKNOWN)
      {
      flag = get_label_str(addr = peekw(mapspace,ip+ip));  /* peekw() == memptrs[ip] */
      if ((addr > 0x7ff) || (flag))
         {
         if ((addr > 0x7ff)
              || ((flag) && 
                   ((memory_size[pictype] > 0x800) || (show_address_mask))
                 )
            )
            strcat(instr_str," & 0x7ff");
         tabout(48);
         sprintf(&instr_str[temp1],";0x%03x",opcode & 0x7ff);
         }
      }
   else
      sprintf(&instr_str[temp1],"0x%03x",opcode & 0x7ff);
   }

static void disasm_controls_14bit()
      /* 14bit:    000000 xxxx xxxx = NOP/RETURN/RETFIE/OPTION/SLEEP/CLRWDT/TRIS/MOVWF
       * filenum = ...... .fff ffff
       * dest    = ...... d... ....
       * NOP     = 000000 0xx0 0000
       * RETURN  = 000000 0000 1000  (0x0008)
       * RETFIE  = 000000 0000 1001  (0x0009)
       * OPTION  = 000000 0110 0010  (0x0062)
       * SLEEP   = 000000 0110 0011  (0x0063)
       * CLRWDT  = 000000 0110 0100  (0x0064)
       * TRIS    = 000000 0110 0fff  <only fff=5, 6, 7 valid> (0x0065, 66, 67)
       * MOVWF   = 000000 1fff ffff
       *   <unused opcodes will default to NOP>
       */
   {
   if (dest)  /* if dest set, this must be MOVWF */
      {
      strcat(instr_str,"MOVWF");
      add_regname();  /* add \t<regname>" */
      }
   else
      {
      switch (filenum)
         {
         case 0x0000:  /* NOP */
         case 0x0020:
         case 0x0040:
         case 0x0060:
            strcat(instr_str,"NOP");
            break;
         case 0x0008:  /* RETURN */
            strcat(instr_str,"RETURN");
            break;
         case 0x0009:  /* RETFIE */
            strcat(instr_str,"RETFIE");
            break;
         case 0x0062:  /* OPTION */
            strcat(instr_str,"OPTION");
            break;
         case 0x0063:  /* SLEEP */
            strcat(instr_str,"SLEEP");
            break;
         case 0x0064:  /* CLRWDT */
            strcat(instr_str,"CLRWDT");
            break;
         case 0x0065:  /* TRIS */
         case 0x0066:  /* TRIS */
         case 0x0067:  /* TRIS */
            strcat(instr_str,"TRIS");
            filenum &= 0x0f;  /* only low bits are valid */
            add_regname();  /* add \t<regname>" */
            break;
         default:
            strcat(instr_str,"NOPU");  /* Undefined opcode NOP */
            break;
         }
      }  /* if (dest) ... else */
   }

static void disasm_clr_14bit()
      /* CLRW / CLRF = 000001 xxxx xxxx = CLRW / CLRF
       * filenum     = ...... .xxx xxxx
       * dest        = ...... x... ....
       * CLRW        = 000001 0000 0000 <actually, 000001 0xxx xxxx>
       * CLRF        = 000001 1fff ffff
       */
   {
   if (!dest)  /* if W is destination */
      strcat(instr_str,"CLRW");
   else
      {
      strcat(instr_str,"CLRF");
      add_regname();  /* add \t<regname>" */
      }
   }

static void disasm_subwf()            /* 000010 dfff ffff = SUBWF */
   {
   strcat(instr_str,"SUBWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_decf()             /* 000011 dfff ffff = DECF */
   {
   strcat(instr_str,"DECF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_iorwf()            /* 000100 dfff ffff = IORWF */
   {
   strcat(instr_str,"IORWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_andwf()            /* 000101 dfff ffff = ANDWF */
   {
   strcat(instr_str,"ANDWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_xorwf()            /* 000110 dfff ffff = XORWF */
   {
   strcat(instr_str,"XORWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_addwf()            /* 000111 dfff ffff = ADDWF */
   {
   strcat(instr_str,"ADDWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_movf()             /* 001000 dfff ffff = MOVF */
   {
   strcat(instr_str,"MOVF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_comf()             /* 001001 dfff ffff = COMF */
   {
   strcat(instr_str,"COMF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_incf()             /* 001010 dfff ffff = INCF */
   {
   strcat(instr_str,"INCF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_decfsz()           /* 001011 dfff ffff = DECFSZ */
   {
   strcat(instr_str,"DECFSZ");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_rrf()              /* 001100 dfff ffff = RRF */
   {
   strcat(instr_str,"RRF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_rlf()              /* 001101 dfff ffff = RLF */
   {
   strcat(instr_str,"RLF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_swapf()            /* 001110 dfff ffff = SWAPF */
   {
   strcat(instr_str,"SWAPF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_incfsz()           /* 001111 dfff ffff = INCFSZ */
   {
   strcat(instr_str,"INCFSZ");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_bcf()              /* 0100bb bfff ffff = BCF <00b> */
   {
   strcat(instr_str,"BCF");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

static void disasm_bsf()              /* 0101bb bfff ffff = BSF <00b> */
   {
   strcat(instr_str,"BSF");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

static void disasm_btfsc()            /* 0110bb bfff ffff = BTFSC <00b> */
   {
   strcat(instr_str,"BTFSC");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

static void disasm_btfss()            /* 0111bb bfff ffff = BTFSS <00b> */
   {
   strcat(instr_str,"BTFSS");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

static void disasm_retlw()            /* 1101xx kkkk kkkk = RETLW <kkkk kkkk> */
   {
   strcat(instr_str,"RETLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   if (((opcode & 0xff) > ' ') && ((opcode & 0xff) < 0x80))
      {
      add_tab();
      sprintf(&instr_str[temp1],";%c",opcode & 0xff);
      }
   }

static void disasm_call_14bit()     /* 100kkk kkkk kkkk = CALL <kkk kkkk kkkk> */
   {
   strcat(instr_str,"CALL");
   add_opcode_11bitaddr();  /* add "\t<kkk kkkk kkkk>" */
   }

static void disasm_go_to_14bit()    /* 101kkk kkkk kkkk = GOTO <kkk kkkk kkkk> */
   {
   strcat(instr_str,"GOTO");
   add_opcode_11bitaddr();  /* add "\t<kkk kkkk kkkk>" */
   }

static void disasm_movlw()            /* 1100xx kkkk kkkk = MOVLW <kkkk kkkk> */
   {
   strcat(instr_str,"MOVLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_iorlw()            /* 111000 kkkk kkkk = IORLW <kkkk kkkk> */
   {
   strcat(instr_str,"IORLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_andlw()            /* 111001 kkkk kkkk = ANDLW <kkkk kkkk> */
   {
   strcat(instr_str,"ANDLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_xorlw()            /* 111010 kkkk kkkk = XORLW <kkkk kkkk> */
   {
   strcat(instr_str,"XORLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_sublw()            /* 11110x kkkk kkkk = SUBLW <kkkk kkkk> */
   {
   strcat(instr_str,"SUBLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_addlw()            /* 11111x kkkk kkkk = ADDLW <kkkk kkkk> */
   {
   strcat(instr_str,"ADDLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_nop()
   {
   strcat(instr_str,"NOP");
   }

void (*picops14[1 << PIC_DECODE_BITS])() =
   {
   controls_14bit,   /* 000000 xxxx xxxx = NOP/RETURN/RETFIE/OPTION/SLEEP/CLRWDT/TRIS/MOVWF */
   clr_14bit,        /* 000001 xxxx xxxx = CLRW / CLRF */
   subwf,            /* 000010 dfff ffff = SUBWF */
   decf,             /* 000011 dfff ffff = DECF */
   iorwf,            /* 000100 dfff ffff = IORWF */
   andwf,            /* 000101 dfff ffff = ANDWF */
   xorwf,            /* 000110 dfff ffff = XORWF */
   addwf,            /* 000111 dfff ffff = ADDWF */
   movf,             /* 001000 dfff ffff = MOVF */
   comf,             /* 001001 dfff ffff = COMF */
   incf,             /* 001010 dfff ffff = INCF */
   decfsz,           /* 001011 dfff ffff = DECFSZ */
   rrf,              /* 001100 dfff ffff = RRF */
   rlf,              /* 001101 dfff ffff = RLF */
   swapf,            /* 001110 dfff ffff = SWAPF */
   incfsz,           /* 001111 dfff ffff = INCFSZ */
   bcf,              /* 010000 bfff ffff (0100bb bfff ffff) = BCF <00b> */
   bcf,              /* 010001 bfff ffff (0100bb bfff ffff) = BCF <01b> */
   bcf,              /* 010010 bfff ffff (0100bb bfff ffff) = BCF <10b> */
   bcf,              /* 010011 bfff ffff (0100bb bfff ffff) = BCF <11b> */
   bsf,              /* 010100 bfff ffff (0101bb bfff ffff) = BSF <00b> */
   bsf,              /* 010101 bfff ffff (0101bb bfff ffff) = BSF <01b> */
   bsf,              /* 010110 bfff ffff (0101bb bfff ffff) = BSF <10b> */
   bsf,              /* 010111 bfff ffff (0101bb bfff ffff) = BSF <11b> */
   btfsc,            /* 011000 bfff ffff (0110bb bfff ffff) = BTFSC <00b> */
   btfsc,            /* 011001 bfff ffff (0110bb bfff ffff) = BTFSC <01b> */
   btfsc,            /* 011010 bfff ffff (0110bb bfff ffff) = BTFSC <10b> */
   btfsc,            /* 011011 bfff ffff (0110bb bfff ffff) = BTFSC <11b> */
   btfss,            /* 011100 bfff ffff (0111bb bfff ffff) = BTFSS <00b> */
   btfss,            /* 011101 bfff ffff (0111bb bfff ffff) = BTFSS <01b> */
   btfss,            /* 011110 bfff ffff (0111bb bfff ffff) = BTFSS <10b> */
   btfss,            /* 011111 bfff ffff (0111bb bfff ffff) = BTFSS <11b> */
   call_14bit,       /* 100000 kkkk kkkk (100kkk kkkk kkkk) = CALL <000> */
   call_14bit,       /* 100001 kkkk kkkk (100kkk kkkk kkkk) = CALL <001> */
   call_14bit,       /* 100010 kkkk kkkk (100kkk kkkk kkkk) = CALL <010> */
   call_14bit,       /* 100011 kkkk kkkk (100kkk kkkk kkkk) = CALL <011> */
   call_14bit,       /* 100100 kkkk kkkk (100kkk kkkk kkkk) = CALL <100> */
   call_14bit,       /* 100101 kkkk kkkk (100kkk kkkk kkkk) = CALL <101> */
   call_14bit,       /* 100110 kkkk kkkk (100kkk kkkk kkkk) = CALL <110> */
   call_14bit,       /* 100111 kkkk kkkk (100kkk kkkk kkkk) = CALL <111> */
   go_to_14bit,      /* 101000 kkkk kkkk (101kkk kkkk kkkk) = GOTO <000> */
   go_to_14bit,      /* 101001 kkkk kkkk (101kkk kkkk kkkk) = GOTO <001> */
   go_to_14bit,      /* 101010 kkkk kkkk (101kkk kkkk kkkk) = GOTO <010> */
   go_to_14bit,      /* 101011 kkkk kkkk (101kkk kkkk kkkk) = GOTO <011> */
   go_to_14bit,      /* 101100 kkkk kkkk (101kkk kkkk kkkk) = GOTO <100> */
   go_to_14bit,      /* 101101 kkkk kkkk (101kkk kkkk kkkk) = GOTO <101> */
   go_to_14bit,      /* 101110 kkkk kkkk (101kkk kkkk kkkk) = GOTO <110> */
   go_to_14bit,      /* 101111 kkkk kkkk (101kkk kkkk kkkk) = GOTO <111> */
   movlw,            /* 110000 kkkk kkkk (1100xx kkkk kkkk) = MOVLW <00> */
   movlw,            /* 110001 kkkk kkkk (1100xx kkkk kkkk) = MOVLW <01> */
   movlw,            /* 110010 kkkk kkkk (1100xx kkkk kkkk) = MOVLW <10> */
   movlw,            /* 110011 kkkk kkkk (1100xx kkkk kkkk) = MOVLW <11> */
   retlw,            /* 110100 kkkk kkkk (1101xx kkkk kkkk) = RETLW <00> */
   retlw,            /* 110101 kkkk kkkk (1101xx kkkk kkkk) = RETLW <01> */
   retlw,            /* 110110 kkkk kkkk (1101xx kkkk kkkk) = RETLW <10> */
   retlw,            /* 110111 kkkk kkkk (1101xx kkkk kkkk) = RETLW <11> */
   iorlw,            /* 111000 kkkk kkkk = IORLW */
   andlw,            /* 111001 kkkk kkkk = ANDLW */
   xorlw,            /* 111010 kkkk kkkk = XORLW */
   nop,              /* 111011 xxxx xxxx = <undefined> */
   sublw,            /* 111100 kkkk kkkk (11110x kkkk kkkk) = SUBLW <0> */
   sublw,            /* 111101 kkkk kkkk (11110x kkkk kkkk) = SUBLW <1> */
   addlw,            /* 111110 kkkk kkkk (11111x kkkk kkkk) = ADDLW <0> */
   addlw             /* 111111 kkkk kkkk (11111x kkkk kkkk) = ADDLW <1> */
   };

void (*dispic14[1 << PIC_DECODE_BITS])() =
   {
   disasm_controls_14bit,   /* 000000 xxxx xxxx = NOP/RETURN/RETFIE/OPTION/SLEEP/CLRWDT/TRIS/MOVWF */
   disasm_clr_14bit,        /* 000001 xxxx xxxx = CLRW / CLRF */
   disasm_subwf,            /* 000010 dfff ffff = SUBWF */
   disasm_decf,             /* 000011 dfff ffff = DECF */
   disasm_iorwf,            /* 000100 dfff ffff = IORWF */
   disasm_andwf,            /* 000101 dfff ffff = ANDWF */
   disasm_xorwf,            /* 000110 dfff ffff = XORWF */
   disasm_addwf,            /* 000111 dfff ffff = ADDWF */
   disasm_movf,             /* 001000 dfff ffff = MOVF */
   disasm_comf,             /* 001001 dfff ffff = COMF */
   disasm_incf,             /* 001010 dfff ffff = INCF */
   disasm_decfsz,           /* 001011 dfff ffff = DECFSZ */
   disasm_rrf,              /* 001100 dfff ffff = RRF */
   disasm_rlf,              /* 001101 dfff ffff = RLF */
   disasm_swapf,            /* 001110 dfff ffff = SWAPF */
   disasm_incfsz,           /* 001111 dfff ffff = INCFSZ */
   disasm_bcf,              /* 010000 bfff ffff (0100bb bfff ffff) = BCF <00b> */
   disasm_bcf,              /* 010001 bfff ffff (0100bb bfff ffff) = BCF <01b> */
   disasm_bcf,              /* 010010 bfff ffff (0100bb bfff ffff) = BCF <10b> */
   disasm_bcf,              /* 010011 bfff ffff (0100bb bfff ffff) = BCF <11b> */
   disasm_bsf,              /* 010100 bfff ffff (0101bb bfff ffff) = BSF <00b> */
   disasm_bsf,              /* 010101 bfff ffff (0101bb bfff ffff) = BSF <01b> */
   disasm_bsf,              /* 010110 bfff ffff (0101bb bfff ffff) = BSF <10b> */
   disasm_bsf,              /* 010111 bfff ffff (0101bb bfff ffff) = BSF <11b> */
   disasm_btfsc,            /* 011000 bfff ffff (0110bb bfff ffff) = BTFSC <00b> */
   disasm_btfsc,            /* 011001 bfff ffff (0110bb bfff ffff) = BTFSC <01b> */
   disasm_btfsc,            /* 011010 bfff ffff (0110bb bfff ffff) = BTFSC <10b> */
   disasm_btfsc,            /* 011011 bfff ffff (0110bb bfff ffff) = BTFSC <11b> */
   disasm_btfss,            /* 011100 bfff ffff (0111bb bfff ffff) = BTFSS <00b> */
   disasm_btfss,            /* 011101 bfff ffff (0111bb bfff ffff) = BTFSS <01b> */
   disasm_btfss,            /* 011110 bfff ffff (0111bb bfff ffff) = BTFSS <10b> */
   disasm_btfss,            /* 011111 bfff ffff (0111bb bfff ffff) = BTFSS <11b> */
   disasm_call_14bit,       /* 100000 kkkk kkkk (100kkk kkkk kkkk) = CALL <000> */
   disasm_call_14bit,       /* 100001 kkkk kkkk (100kkk kkkk kkkk) = CALL <001> */
   disasm_call_14bit,       /* 100010 kkkk kkkk (100kkk kkkk kkkk) = CALL <010> */
   disasm_call_14bit,       /* 100011 kkkk kkkk (100kkk kkkk kkkk) = CALL <011> */
   disasm_call_14bit,       /* 100100 kkkk kkkk (100kkk kkkk kkkk) = CALL <100> */
   disasm_call_14bit,       /* 100101 kkkk kkkk (100kkk kkkk kkkk) = CALL <101> */
   disasm_call_14bit,       /* 100110 kkkk kkkk (100kkk kkkk kkkk) = CALL <110> */
   disasm_call_14bit,       /* 100111 kkkk kkkk (100kkk kkkk kkkk) = CALL <111> */
   disasm_go_to_14bit,      /* 101000 kkkk kkkk (101kkk kkkk kkkk) = GOTO <000> */
   disasm_go_to_14bit,      /* 101001 kkkk kkkk (101kkk kkkk kkkk) = GOTO <001> */
   disasm_go_to_14bit,      /* 101010 kkkk kkkk (101kkk kkkk kkkk) = GOTO <010> */
   disasm_go_to_14bit,      /* 101011 kkkk kkkk (101kkk kkkk kkkk) = GOTO <011> */
   disasm_go_to_14bit,      /* 101100 kkkk kkkk (101kkk kkkk kkkk) = GOTO <100> */
   disasm_go_to_14bit,      /* 101101 kkkk kkkk (101kkk kkkk kkkk) = GOTO <101> */
   disasm_go_to_14bit,      /* 101110 kkkk kkkk (101kkk kkkk kkkk) = GOTO <110> */
   disasm_go_to_14bit,      /* 101111 kkkk kkkk (101kkk kkkk kkkk) = GOTO <111> */
   disasm_movlw,            /* 110000 kkkk kkkk (1100xx kkkk kkkk) = MOVLW <00> */
   disasm_movlw,            /* 110001 kkkk kkkk (1100xx kkkk kkkk) = MOVLW <01> */
   disasm_movlw,            /* 110010 kkkk kkkk (1100xx kkkk kkkk) = MOVLW <10> */
   disasm_movlw,            /* 110011 kkkk kkkk (1100xx kkkk kkkk) = MOVLW <11> */
   disasm_retlw,            /* 110100 kkkk kkkk (1101xx kkkk kkkk) = RETLW <00> */
   disasm_retlw,            /* 110101 kkkk kkkk (1101xx kkkk kkkk) = RETLW <01> */
   disasm_retlw,            /* 110110 kkkk kkkk (1101xx kkkk kkkk) = RETLW <10> */
   disasm_retlw,            /* 110111 kkkk kkkk (1101xx kkkk kkkk) = RETLW <11> */
   disasm_iorlw,            /* 111000 kkkk kkkk = IORLW */
   disasm_andlw,            /* 111001 kkkk kkkk = ANDLW */
   disasm_xorlw,            /* 111010 kkkk kkkk = XORLW */
   disasm_nop,              /* 111011 xxxx xxxx = <undefined> */
   disasm_sublw,            /* 111100 kkkk kkkk (11110x kkkk kkkk) = SUBLW <0> */
   disasm_sublw,            /* 111101 kkkk kkkk (11110x kkkk kkkk) = SUBLW <1> */
   disasm_addlw,            /* 111110 kkkk kkkk (11111x kkkk kkkk) = ADDLW <0> */
   disasm_addlw             /* 111111 kkkk kkkk (11111x kkkk kkkk) = ADDLW <1> */
   };

void initr84a()
   {
   regs[PCL] = ip;
   regs[PCLATH] = 0;
   regs[OPTION] = 0xff;
   regs[TRISA] = 0x1f;
   regs[TRISB] = 0xff;
   regsknown[STATUS] = 0xf8;
   regsknown[PCL] = ALLBITS_KNOWN;
   regsknown[PCLATH] = ALLBITS_KNOWN & 0x1f;
   regsknown[OPTION] = ALLBITS_KNOWN;
   regsknown[TRISA] = ALLBITS_KNOWN & 0x1f;
   regsknown[TRISB] = ALLBITS_KNOWN;
   }

void initr628()
   {
   regs[PCL] = ip;
   regs[PCLATH] = 0;
   regs[OPTION] = 0xff;
   regs[TRISA] = 0x1f;
   regs[TRISB] = 0xff;
   regsknown[STATUS] = 0xf8;
   regsknown[PCL] = ALLBITS_KNOWN;
   regsknown[PCLATH] = ALLBITS_KNOWN & 0x1f;
   regsknown[OPTION] = ALLBITS_KNOWN;
   regsknown[TRISA] = ALLBITS_KNOWN & 0x1f;
   regsknown[TRISB] = ALLBITS_KNOWN;
   }

void initr675()
   {
   regs[PCL] = ip;
   regs[PCLATH] = 0;
   regs[OPTION] = 0xff;
   regs[TRIS] = 0x3f;
   regsknown[STATUS] = 0xf8;
   regsknown[PCL] = ALLBITS_KNOWN;
   regsknown[PCLATH] = ALLBITS_KNOWN & 0x1f;
   regsknown[OPTION] = ALLBITS_KNOWN;
   regsknown[TRIS] = ALLBITS_KNOWN & 0x3f;
   }

void initr877()
   {
   regs[PCL] = ip;
   regs[PCLATH] = 0;
   regs[OPTION] = 0xff;
   regs[TRISA] = 0x1f;
   regs[TRISB] = 0xff;
   regsknown[STATUS] = 0xf8;
   regsknown[PCL] = ALLBITS_KNOWN;
   regsknown[PCLATH] = ALLBITS_KNOWN & 0x1f;
   regsknown[OPTION] = ALLBITS_KNOWN;
   regsknown[TRISA] = ALLBITS_KNOWN & 0x1f;
   regsknown[TRISB] = ALLBITS_KNOWN;
   }
