/*
 *  PIC disassembler.
 *
 *  Based on code from PICEMU (P12==12C509A, P84==16F84A, and P14==16f877)
 *  and CODEGEN.
 *
 *  Copyright (c) 2002
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICDIS
 *
 *  PICDIS is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICDIS is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  Revision history
 *
 *  Date      Comments
 *  --------  -------------------------------------------
 *  6/12/02   Start programming
 *  8/11/03   Update to add 12F675
 */
/*  Later note (3/18/2020):  In getting this ready for release on
 *                 www.reddit.com/r/emudev
 *  I've fallen into a big hole.  It needs to be run under DOSBOX since
 *  current Windows (64-bit) don't support 16-bit DOS calls.
 *
 *  However, testing things under DOSBOX found bugs in DOSBOX.  Not supporting
 *  VESA video mode 0x010B (132 x 50 text) is annoying, it's the best
 *  resolution for running PICEMU.  It can fall back to lower resolutions, but
 *  features are missing.
 *
 *  And, there is a bug in DOSBOX's handling of the CON file handle (C's
 *  STDIN) from COMMAND.COM.  The Enter key is supposed to return '\n', but
 *  it returns '\r' instead, which breaks C's gets() function.
 *
 *  Rather than wait for a possible later fix, I've replaced the gets()
 *  calls with mygets(), which is a simple function that is "good enough".
 */
#define GETS(x)       mygets(x)    /* make this easy to remove later 3/18/20 */
#include <picdis.h>

#include <pdregmap.h>  /* register mappings */

extern void (*picops12[])();
extern void (*dispic12[])();
extern void (*picops14[])();
extern void (*dispic14[])();

void initr509a(), initr84a(), initr628(), initr877(), initr675();

extern struct rnames names509a[64];
extern struct rnames names675[256];
extern struct rnames names84a[256];
extern struct rnames names628[512];
extern struct rnames names877[512];

WORD pictype;    /* which PIC is target */
BYTE *pic_name[PIC_MAX+1] =           {  "12C509A",  "12F675",  "16F84A",  "16F628",  "16F877" };
WORD memory_size[PIC_MAX+1] =         {       1024,      1024,      1024,      2048,      8192 };
WORD ram_size[PIC_MAX+1] =            {         64,       256,       256,       512,       512 };
WORD start_ip[PIC_MAX+1] =            {     0x03ff,         0,         0,         0,         0 };
WORD last_instr[PIC_MAX+1] =          {     0x0cf0,    0x34f0,    0x3fff,    0x3fff,    0x3fff };
WORD interrupt_loc[PIC_MAX+1] =       {     0x03ff,         4,         4,         4,         4 };
WORD eeprom_loc[PIC_MAX+1] =          {     0xfff0,    0x2100,    0x2100,    0x2100,    0x2100 };
WORD eeprom_size[PIC_MAX+1] =         {          0,       128,        64,       128,       256 };
WORD config_loc[PIC_MAX+1] =          {     0x0fff,    0x2007,    0x2007,    0x2007,    0x2007 };
WORD config_mask[PIC_MAX+1] =         {     0x001f,    0x31ff,    0x3fff,    0x3dff,    0x3bff };
WORD id_loc[PIC_MAX+1] =              {     0x0400,    0x2000,    0x2000,    0x2000,    0x2000 };
WORD id_end[PIC_MAX+1] =              {     0x0403,    0x2003,    0x2003,    0x2003,    0x2003 };
WORD instruction_bitmask[PIC_MAX+1] = {     0x0fff,    0x3fff,    0x3fff,    0x3fff,    0x3fff };
WORD optypes_shift[PIC_MAX+1] =       {          6,         8,         8,         8,         8 };
WORD regindex_mask[PIC_MAX+1] =       {     0x001f,    0x007f,    0x007f,    0x007f,    0x007f };
BYTE has_irp[PIC_MAX+1] =             {      FALSE,     FALSE,     FALSE,      TRUE,      TRUE };
BYTE pic_core[PIC_MAX+1] =            {    CORE_12,   CORE_14,   CORE_14,   CORE_14,   CORE_14 };
WORD dest_mask[PIC_MAX+1] =           {     0x0020,    0x0080,    0x0080,    0x0080,    0x0080 };
WORD retlw_optype[PIC_MAX+1] =        {       0x08,      0x34,      0x34,      0x34,      0x34 };
WORD *xlatemap[PIC_MAX+1] =           {  xlate509a,  xlate675,  xlate84a,  xlate628,  xlate877 };
void (*opstables[PIC_MAX+1])() =      {   picops12,  picops14,  picops14,  picops14,  picops14 };
void (*distables[PIC_MAX+1])() =      {   dispic12,  dispic14,  dispic14,  dispic14,  dispic14 };
void (*initregs[PIC_MAX+1])() =       {  initr509a,  initr675,  initr84a,  initr628,  initr877 };
struct rnames *regnames[PIC_MAX+1] =  {  names509a,  names675,  names84a,  names628,  names877 };
void (**picops)();
void (**disasmpicops)();
WORD *xlate_regs;

BYTE regs[MAX_REGS];
BYTE regsknown[MAX_REGS];
WORD memory[MAX_MEMORY];
BYTE memoryknown[MAX_MEMORY];

WORD configuration;
WORD have_configuration = FALSE;

BYTE w;       /* the W register */
BYTE wknown;  /* are contents of W known? */
WORD ip;
WORD next_ip;
WORD opcode;        /* opcode we're working on */
WORD instr_type;    /* instruction bits from opcode */
WORD filenum;       /* index into regs */
WORD filenum_temp;  /* bank select bits + filenum */
WORD filenum_temp2; /* filenum_temp via xlat_regs[] */
WORD dest;          /* 1=destination is F (register File) 0=destination is W */
WORD statushold;    /* hold for status flags */
WORD statusknownhold;  /* hold for status known flags */
BYTE temp1;         /* useful to have around */
            BYTE aligntemp1_1;
BYTE temp2;         /* useful to have around */
            BYTE aligntemp2_1;

WORD upperflag;   /* force output to upper case */
WORD use_tabs;    /* output spaces or tabs */
WORD hex_code_comments = TRUE;  /* comments on code */
WORD hex_data_comments;  /* comments on data (DT's) */
WORD generate_dt = TRUE;  /* use DT pseudo-op where possible */
WORD flag_unmapped_code = TRUE;  /* add ;U to code we didn't find */
WORD show_regdefs = FALSE;  /* show register .EQU's */
WORD show_label_ofs = FALSE;  /* show value of code label */
WORD use_interrupt_flag = TRUE;  /* use Interrupt */
WORD disassemble_unknown_code = TRUE;  /* if we haven't found our way here, disassemble it anyway */
WORD comment_unknown_code_with_opcode = TRUE;  /* if generating DW, give opcode as comment */
WORD disassemble_default_code = TRUE;  /* if we haven't programmed this, disassemble it anyway */
WORD hex_equivalent_of_named_regs = TRUE;  /* show equivalent HEX to named regs */
WORD show_address_mask = FALSE;
  /* if address space (14-bit) fits into 11 bits (CALL/GOTO), do not add '& 0x7ff' mask */
BYTE eos_char;  /* default to EOS = '\0' */

WORD string_search;  /* true or false */
WORD string_found;
WORD search_ip;  /* starting IP for this line */
WORD find_str_len;
BYTE find_str[STRING_SIZE];

WORD myfputsok;  /* flag: OK to continue outputting disasembly */
WORD pagepause;  /* for preview to screen */
WORD linecount;  /* for preview to screen */

BYTE instr_str[STRING_SIZE];  /* disassembled instruction */
BYTE tempstr[STRING_SIZE];
BYTE filename[STRING_SIZE];
BYTE outfile[STRING_SIZE];
BYTE lowerstr[STRING_SIZE];
BYTE not_a_codfile[20] = "not a .COD file?\n";
BYTE codfile_badread[28] = "read error on .COD file.\n";
BYTE invalid_memory_map[24] = "invalid memory map.\n";
BYTE ill_addr_msg[] = "Error:  illegal address";
BYTE choice_str[] = "Your choice? ";
BYTE *size_strs[5] =
   {
   "Oops",       /* 0 */
   "BYTE",       /* 1 */
   "WORD",       /* 2 */
   "Oops...",    /* 3 */
   "DWORD"       /* 4 */
   };

BYTE diskbuf[DISKBUF_SIZE];

#define MAJOR_VERSION 0
#define MINOR_VERSION 5
#define MINOR_VERSION_CHAR ''
BYTE version[] = "PICDIS Version 0.5";


DWORD lseek();
int filein, fileout;
WORD fileout_len;  /* len of current output line to fileout, used for add_tab() and tabout() */

WORD peekw();
BYTE peekb();

WORD mapping_done;  /* global value from find_new_thread() */
WORD skip_find_new_thread;
WORD skip_label_regs_unknown;

WORD codesegment;  /* CODEGEN's code segment */
WORD datasegment;  /* CODEGEN's data segment */
WORD highsegment;  /* the value of the higher of the two segments */
WORD mapspace;  /* segment used to hold the byte map of the program */
WORD knownstack;   /* segment used to hold the "known values" stack */
WORD knownstackptr;  /* stackpointer for "known values" */
WORD memtop,memused;  /* used and available data segments */
WORD maxpara;  /* how much memory is available */
WORD sym_seg;  /* segment used to hold symbol table (from .COD file) */
WORD num_syms;  /* number of symbols in table * SYMTAB_ENTRY */
   /* Note:  The symbol table will be stored as a 32-byte structure
    *          BYTE name[28];   //max of 27 chars, plus EOS (0 filled)
    *          BYTE flags;      //bitmapped: .... ...x -> 0=code label, 1=data
    *          BYTE len;        //if data, size of data field, 0 = unknown
    *          WORD value;
    */
BYTE copyright[] =
"Copyright (c) 2002,2003.\nThis program is licensed under the GNU GPL.  www.gnu.org/licenses/gpl.txt\n\n";
BYTE hello[STRING_SIZE];

main(argc,argv)
   WORD argc;
   BYTE *argv[];
   {
   WORD i;

   sprintf(hello,"PICDIS V%d.%d%c\n",MAJOR_VERSION,MINOR_VERSION,MINOR_VERSION_CHAR);
   strcat(hello,"Smart disassember for PIC 12C509A/12F675/16F84A/16F628/16F877 processors.\n");
   puts(hello);
   puts(copyright);
   datasegment = DATASEG;  /* get data and code seg.  Note implied small
                              memory model. */
   codesegment = CODESEG;
   highsegment = datasegment;
   if (codesegment > datasegment)  /* do not assume DS > CS */
      highsegment = codesegment;
   mapspace = highsegment + 0x1000;  /* allow for 64K (small memory model) */
   if (mapspace & 0x0fff)
      mapspace = (mapspace & 0xf000) + 0x1000;
   knownstack = mapspace + 0x1000;
   sym_seg = knownstack + 0x1000;
   memtop = peekw(0,0x413);  /* get system memory */
   memtop = ((memtop >> 6) & 0x000f) + ((memtop & 0x3f) ? 1:0);
                                                  /* get in low nibble */
   memused = (sym_seg >> 12) & 0x000f;
                                      /* get number of 64K blocks used */
   maxpara = (memtop - memused) * 0x1000;  /* number of paragraphs in
                                              virtual memory */
   if (maxpara < 0x1000)
      {
      puts("Error:  Insufficent free memory\n");
      exit(1);
      }
   memfill(mapspace,0,0x8000,0);  /* seg, offset, len, char */
   memfill(mapspace,0x8000,0x8000,0);  /* seg, offset, len, char */
   memfill(knownstack,0,0x8000,0);  /* seg, offset, len, char */
   memfill(knownstack,0x8000,0x8000,0);  /* seg, offset, len, char */
   memfill(sym_seg,0,0x8000,0);  /* seg, offset, len, char */
   memfill(sym_seg,0x8000,0x8000,0);  /* seg, offset, len, char */

   if (get_filename_menu() == 'Q')
      exit(0);
   if ((filein = open(filename,0)) == -1)
      {
      printf("Error:  cannot open file %s\n",filename);
      exit(1);
      }
   if (read(filein,tempstr,1) != 1)
      {
      close(filein);
      printf("Error:  cannot read file %s\n",filename);
      exit(1);
      }
   lseek(filein,0L,0);  /* reset to start of file */
   if (tempstr[0] == ':')  /* if this looks like a .HEX file */
      i = load_hexfile();
   else
      i = load_codfile();  /* it had better be a .COD file! */
   close(filein);
   if (!i)
      {
      printf("Error processing file %s\n",filename);
      exit(1);
      }
   ip = start_ip[pictype];
   SETCFLAG(ip,PROG_LABEL);  /* set start info */
   if (use_interrupt_flag)
      SETCFLAG(interrupt_loc[pictype],PROG_LABEL);  /* flag interrupt code, if any */
   regs_unknown();
/*
printf("\rinit: R_U\n");
*/
   picops = opstables[pictype];   /* ptr to functions for this PIC core */
   disasmpicops = distables[pictype];  /* ptr to disassembly for this PIC core */
   xlate_regs = xlatemap[pictype];

#ifdef NEVERDEF
   regs[PCL] = ip;
   regsknown[PCL] = ALLBITS_KNOWN;
   regsknown[STATUS] = 0xe0;
   if (pictype == P12C509A)
      {
      regs[FSR] = 0xc0;
      regsknown[FSR] = 0xe0;
      }
#endif
   (*initregs[pictype])();  /* initalize registers and regsknown */
   skip_label_regs_unknown = SKIP_VAL;  /* label at entry does not make us
                                         * forget initial regs.
                                         */
   map_it();
   main_menu();
   }

WORD char_in_str(ch,str)
   BYTE ch;
   BYTE *str;
   {
   WORD i;

   i = 0;
   while (str[i])
      {
      if (str[i] == ch)
         return(i);
      i++;
      }
   return(-1);
   }

get_filename_menu()
   {
   BYTE command[128];
   BYTE answers[8];
   BYTE answer, ch;
   WORD i;

   pictype = P12C509A;  /* default processor */
   do
      {
      cls();
      puts(hello);
      puts(copyright);
      puts("\nPlease select an option:\n");
      puts("  P:  Processor  ");
      puts(pic_name[pictype]);
      puts("\n  F:  File to disassemble  ");
      if (filename[0])
         puts(filename);
      else
         puts("<not selected>");
      if (pictype != P12C509A)
         {
         printf("\n  I:  Interrupt code at 0x%04x: %s",
                 interrupt_loc[pictype],use_interrupt_flag ? "YES" : "NO");
         strcpy(answers,"PFIMQ");
         }
      else
         {
         strcpy(answers,"PFMQ");
         }
      puts("\n  M:  Map program, proceede to main menu");
      curpos(18,0);
      puts("  Q:  Quit PICDIS");
      do
         {
         clear_to_bottom(20,0);
         putsat(20,0,choice_str);
         GETS(tempstr);
         answer = toupper(tempstr[0]);
         } while (char_in_str(answer,answers) == -1);
      for (i = 1; (tempstr[i]) && (tempstr[i] == ' '); i++)
         ;  /* the FOR loop does it all */
      strcpy(command,&tempstr[i]);
      switch (answer)
         {
         case 'P':
            clear_to_bottom(14,0);
            putsat(14,0,"Please choose a processor type:\n");
            for (i = P12C509A; i <= PIC_MAX; i++)
               printf("   %d: %s\n",i,pic_name[i]);
            do
               {
               clear_to_bottom(14+i+1,0);
               putsat(14+i+1,0,choice_str);
               GETS(tempstr);
               ch = toupper(tempstr[0]);
               } while ((ch) && ((ch < '0'+P12C509A) || (ch > '0'+PIC_MAX)));
            if (ch)
               pictype = ch - '0' + P12C509A;
            break;
         case 'F':
            if (!command[0])
               {
               clear_to_bottom(15,0);
               putsat(15,0,"Please enter the name of the file to disassemble:");
               putsat(16,5,"? ");
               GETS(command);
               }
            if (!command[0])
               break;  /* no file, do nothing... */
            if ((i = open(command,0)) == -1)
               {
               putsat(19,0,"Error:  File not found.");
               pressany(FALSE);
               break;
               }
            strcpy(filename,command);
            break;
         case 'I':
            use_interrupt_flag = !use_interrupt_flag;
            break;
         case 'M':
            if (!filename[0])
               {
               putsat(22,0,"A file must be loaded before PICDIS can disassemble it!");
               pressany(FALSE);
               answer = 'A';  /* something besides a 'Q' or 'M' */
               }
            break;
         }  /* switch (answer) */
      } while ((answer != 'Q') && (answer != 'M'));
   return(answer);
   }

onoroff(flag)
   WORD flag;
   {
   if (flag)
      PUTS("ON");
   else
      PUTS("OFF");
   }

main_menu()
   {
   BYTE command[128];
   BYTE answer, ch;
   WORD i;

   do
      {
      cls();
/*      puts(copyright); */
      puts("Work file: ");
      puts(filename);
      puts("\nPlease select an option:\n");
      puts("\n  W: Write the disassembled code to a file (Esc to quit)");
      puts("\n  P: Preview the disassembled code to the screen (Esc to quit)");
      puts("\n  C: force a CODE area");
      puts("\n  J: Map a JMP table");
      puts("\n  F: Forget about an area");
      puts("\n  O: disassembly Options menu\n");
      puts("     Uppercase output: ");
      onoroff(upperflag);
      puts("             Use spaces instead of Tabs: ");
      onoroff(use_tabs);
      puts("\n     Hex comments on code: ");
      onoroff(hex_code_comments);
      puts("          Show value of code label: ");
      onoroff(show_label_ofs);
      puts("\n     Flag unmapped code: ");
      onoroff(flag_unmapped_code);
      puts("\n     Generate DT pseudo-ops on RETLW sequences: ");
      onoroff(generate_dt);
      puts("\n     Hex comments on DT's: ");
      onoroff(hex_data_comments);
      puts("         Show register EQU's: ");
      onoroff(show_regdefs);
      puts("\n     Disassemble unknown code: ");
      onoroff(disassemble_unknown_code);
      puts("      Comment unknown code with opcode: ");
      onoroff(comment_unknown_code_with_opcode);
      puts("\n     Disassemble mapped default code (unprogrammed codespace): ");
      onoroff(disassemble_default_code);
      puts("\n     Show equivalent hex to named regs: ");
      onoroff(hex_equivalent_of_named_regs);
      if ((pictype != P12C509A) && (pictype != P16F877))
         {
         puts("\n     Show address mask: ");
         onoroff(show_address_mask);
         }
      curpos(18,0);
      puts("  Q: Quit PICDIS");
      do
         {
         clear_to_bottom(20,0);
         putsat(20,0,choice_str);
         GETS(tempstr);
         answer = toupper(tempstr[0]);
         } while (char_in_str(answer,"WPCJFOQ") == -1);
      for (i = 1; (tempstr[i]) && (tempstr[i] == ' '); i++)
         ;  /* the FOR loop does it all */
      strcpy(command,&tempstr[i]);
      switch (answer)
         {
         case 'W':
            while (!outfile[0])  /* until we have a valid name */
               {
               if (command[0])
                  {
                  strcpy(outfile,command);
                  command[0] = '\0';  /* don't use this string again */
                  }
               else
                  {
                  clear_to_bottom(18,0);
                  putsat(18,0,"Please enter the name of the output file:");
                  putsat(20,5,"? ");
                  GETS(outfile);
                  if (!outfile[0])
                     break;  /* blank, do not output */
                  }
               if ((fileout = open(outfile,0)) != -1)  /* if output file exists */
                  {
                  close(fileout);
                  clear_to_bottom(22,0);
                  putsat(22,0,"The output file ");
                  puts(outfile);
                  puts(" already exists.\n");
                  puts("Do you want to overwrite it (Y/N)? ");
                  GETS(command);
                  ch = toupper(command[0]);
                  command[0] = '\0';  /* don't re-use this string */
                  if (ch != 'Y')
                     outfile[0] = '\0';
                  }
               }  /* while (!outfile[0]) */
            if (outfile[0])  /* if we have an output name */
               write_disassembly(FALSE);  /* not preview */
            outfile[0] = '\0';  /* don't re-use this name */
            break;
         case 'P':  /* Preview */
            preview_file();
            break;
         case 'C':  /* Code address */
            add_code_address();
            break;
         case 'J':  /* Jump table */
            map_jump_table();
            break;
         case 'F':  /* Forget an area */
            forget_area();
            break;
         case 'O':  /* Options menu */
            options_menu();
            break;
         }  /* switch (answer) */
      } while (answer != 'Q');
   }

add_code_address()
   {
   WORD start_ofs, temp;

   do
      {
      cls();
      puts("Force a CODE area:\n\nEnter a blank for the starting address to quit.");
      do
         {
         putsat(4,0,"What is the starting address (in hex)? ");
         GETS(tempstr);
         if ((tempstr[0]) && ((!(temp = numval(tempstr,&start_ofs)))
                                || (start_ofs >= memory_size[pictype])))
            {
            clear_to_bottom(4,39);
            putsat(6,0,ill_addr_msg);
            temp = FALSE;  /* make end of while simpler... */
            }
         } while ((tempstr[0]) && (!temp));
      if ((tempstr[0]) && (!(memoryknown[start_ofs] & PROG_KNOWN)))  /* if unknown */
         {
         SETCFLAG(start_ofs,PROG_LABEL);  /* set start info */
         ip = start_ofs;
         map_it();
         }
      } while (tempstr[0]);
   }

forget_area()
   {
   WORD start_ofs, end_ofs, temp;

   do
      {
      cls();
      puts("FORGET everything about an area:");
      puts("\n\nEnter a blank for the starting address to quit.");
      do
         {
         putsat(4,0,"What is the starting address (in hex)? ");
         GETS(tempstr);
         if ((tempstr[0]) && ((!(temp = numval(tempstr,&start_ofs)))
                                || (start_ofs >= memory_size[pictype])))
            {
            clear_to_bottom(4,39);
            putsat(6,0,ill_addr_msg);
            temp = FALSE;  /* make end of while simpler... */
            }
         } while ((tempstr[0]) && (!temp));
      if (tempstr[0])
         {
         do
            {
            putsat(6,0,"What is the ending address (in hex) (blank for starting address)? ");
            GETS(tempstr);
            if (!tempstr[0])
               {
               end_ofs = start_ofs;
               temp = TRUE;
               }
            else
               {
               if ((!(temp = numval(tempstr,&end_ofs)))
                            || (end_ofs > memory_size[pictype]))
                  {
                  clear_to_bottom(6,65);
                  putsat(8,0,ill_addr_msg);
                  temp = FALSE;  /* make end of while simpler... */
                  }
               }
            } while (!temp);
         if (start_ofs <= end_ofs)
            {
            while (start_ofs <= end_ofs)
               memoryknown[start_ofs++] &= PROG_CODE;  /* forget everything except whether we loaded code here */
            tempstr[0] = 'a';  /* something besides a blank! */
            }
         else
            {
            puts("The ending address must be equal to or larger than the starting address.\n");
            pressany(FALSE);
            }
         clear_to_bottom(4,0);
         }  /* if (tempstr[0])  (if we have a starting address, forget this area) */
      } while (tempstr[0]);
   }

map_jump_table()
   {
   WORD best_guess, start_ofs, end_ofs, skipbytes;
   WORD temp;

   temp = FALSE;  /* need to initalize this */
   do
      {
      best_guess = FALSE;
      cls();
      puts("Map a JUMP table:\n");
      puts("Enter a blank for the starting address to quit.");
      do
         {
         putsat(5,0,"What is the starting address (in hex)? ");
         GETS(tempstr);
         if ((tempstr[0]) &&
               ((!(temp = numval(tempstr,&start_ofs)))
                                || (start_ofs >= memory_size[pictype])))
            {
            clear_to_bottom(5,39);
            putsat(7,0,ill_addr_msg);
            }
         } while ((tempstr[0]) && (!temp));
      if (tempstr[0])
         {
         do
            {
            putsat(7,0,"What is the ending offset (in hex), or blank to have PICDIS make a\n");
            puts("\'best guess\'? ");
            GETS(tempstr);
            if (!tempstr[0])
               {
               end_ofs = memory_size[pictype];
               best_guess = TRUE;
               }
            else
               if ((!(temp = numval(tempstr,&end_ofs)))
                                || (end_ofs >= memory_size[pictype]))
                  {
                  clear_to_bottom(8,15);
                  putsat(10,0,ill_addr_msg);
                  }
            } while ((!best_guess) && (!temp));
         do
            {
            skipbytes = 0;
            putsat(10,0,"Enter the number of instructions to skip between table entries,\n");
            puts("or Return for none? ");
            GETS(tempstr);
            if ((tempstr[0]) && (!(temp = numval(tempstr,&skipbytes))))
               {
               clear_to_bottom(11,20);
               putsat(13,0,"Illegal value");
               }
            else
               skipbytes++;
            } while ((tempstr[0]) && (!temp));
         tempstr[0] = TRUE;  /* so that we do not fall out of loop */
         clear_to_bottom(13,0);
         skip_find_new_thread = 0;
         skip_label_regs_unknown = 0;
         if (start_ofs <= end_ofs)
            {
            while (TRUE)  /* until I'm satisified */
               {
               if (best_guess)
                  {
                  if ((memoryknown[start_ofs] & PROG_KNOWN)
                               || (!(memoryknown[start_ofs] & PROG_CODE)))
                     break;  /* that's all! */
                  }
               if (!(memoryknown[start_ofs] & PROG_KNOWN))  /* if unknown */
                  {
                  SETCFLAG(start_ofs,PROG_LABEL);  /* set start info */
                  ip = start_ofs;
                  map_it();
                  }
               start_ofs += skipbytes;
               if (start_ofs >= end_ofs)
                  break;
               }
            }
         else
            {
            puts("The ending address must be equal to or larger than the starting address,\n");
            puts("and both must be within in limits of the program.\n");
            pressany(FALSE);
            clear_to_bottom(5,0);
            }
         }  /* if (tempstr[0]) */
      } while (tempstr[0]);
   }

options_menu()
   {
   BYTE answer;
   BYTE answerstr[32];

   if ((pictype != P12C509A) && (pictype != P16F877))
      strcpy(answerstr,"UTCVFHGEDOMSRA");
   else
      strcpy(answerstr,"UTCVFHGEDOMSR");
   do
      {
      cls();
      puts("Disassembly Options:\n\nDo you want:\n\n");

      puts("  U: Uppercase output (currently ");
      onoroff(upperflag);
      puts(")\n  T: use Spaces instead of Tabs (currently ");
      onoroff(use_tabs);
      puts(")\n  C: hex comments on disassembled Code (currently ");
      onoroff(hex_code_comments);
      puts(")\n  V: show Value of code label (currently ");
      onoroff(show_label_ofs);
      puts(")\n  F: Flag unmapped code (currently ");
      onoroff(flag_unmapped_code);
      puts(")\n  G: generate DT pseudo-ops on RETLW sequences (currently ");
      onoroff(generate_dt);
      puts(")\n  H: Hex comments on DT's (currenlty ");
      onoroff(hex_data_comments);
      puts(")\n  E: Show register EQU's (currently ");
      onoroff(show_regdefs);
      puts(")\n  D: Disassemble unknown code (currently ");
      onoroff(disassemble_unknown_code);
      puts(")\n  O: comment unknown code with Opcode (currently ");
      onoroff(comment_unknown_code_with_opcode);
      puts(")\n  M: disassemble Mapped default code (unprogrammed codespace) (currently ");
      onoroff(disassemble_default_code);
      puts(")\n  S: Show equivalent hex to named registers (currently ");
      onoroff(hex_equivalent_of_named_regs);
      if ((pictype != P12C509A) && (pictype != P16F877))
         {
         puts(")\n  A: show Address mask (currently ");
         onoroff(show_address_mask);
         }

      puts(")\n\n  R: Return to the main menu (Default if Return is pressed)\n");
      do
         {
         curpos(22,0);
         puts("Option? ");
         clear_to_bottom(22,8);
         GETS(tempstr);
         answer = toupper(tempstr[0]);
         if (answer == '\0')
            answer = 'R';
         } while (char_in_str(answer,answerstr) == -1);
      switch (answer)
         {
         case 'U':
            upperflag = !upperflag;
            break;
         case 'T':
            use_tabs = !use_tabs;
            break;
         case 'C':
            hex_code_comments = !hex_code_comments;
            break;
         case 'V':
            show_label_ofs = !show_label_ofs;
            break;
         case 'F':
            flag_unmapped_code = !flag_unmapped_code;
            break;
         case 'H':
            hex_data_comments = !hex_data_comments;
            break;
         case 'G':
            generate_dt = !generate_dt;
            break;
         case 'E':
            show_regdefs = !show_regdefs;
            break;
         case 'D':
            disassemble_unknown_code = !disassemble_unknown_code;
            break;
         case 'O':
            comment_unknown_code_with_opcode = !comment_unknown_code_with_opcode;
            break;
         case 'M':
            disassemble_default_code = !disassemble_default_code;
            break;
         case 'S':
            hex_equivalent_of_named_regs = !hex_equivalent_of_named_regs;
            break;
         case 'A':
            show_address_mask = !show_address_mask;
            break;
         }
      } while (answer != 'R');
   }

regs_unknown()
   {
   _setmem(regsknown,MAX_REGS,0);
   wknown = 0;
   }

#ifdef NEVERDEF
map_code(addr)
   WORD addr;
   {
   SETCFLAG(addr,PROG_KNOWN);
/* printf("\n  Setting PROG_KNOWN at %04x",addr); */
   }
#endif

map_it()
   {
   BYTE knownflag, byte2;

   cls();
   PUTS("\nMapping program space");
   mapping_done = FALSE;
   do
      {
/*
printf("\nip=%04x",ip);
*/
      if (skip_find_new_thread)
         skip_find_new_thread--;
      if (skip_label_regs_unknown)
         skip_label_regs_unknown--;
      if ((knownflag = memoryknown[ip]) & PROG_KNOWN)  /* if we've already been here */
         {
         skip_find_new_thread = 0;
/*
printf("\n1: find_new_thread()\n");
*/
         find_new_thread();
         }
      else
         {
         if ((knownflag & PROG_LABEL) && (skip_label_regs_unknown == 0)
                    && (skip_find_new_thread == 0))
            {
/*
printf("\n2: knownflag=%02x (&%02x=%02x) at ip=%03x\n",
  knownflag,PROG_LABEL,knownflag&PROG_LABEL,ip);
*/
            regs_unknown();
            }
         opcode = memory[ip];
         SETCFLAG(ip,PROG_KNOWN);
         next_ip = (ip + 1) & (memory_size[pictype]-1);
         regs[PCL] = next_ip;  /* update PCL */
         regsknown[PCL] = ALLBITS_KNOWN;
         filenum = opcode & regindex_mask[pictype];  /* isolate register file */
         dest = opcode & dest_mask[pictype];  /* isolate F/!W bit */
         instr_type = opcode >> optypes_shift[pictype];
/*         map_code(ip); */
/*
printf("\n ip=%04x  regsknown[PCLATH] = %02x & %02x = %02x  skip_find_new_thread=%d",
ip,regsknown[PCLATH],0x18,regsknown[PCLATH]&0x18,
skip_find_new_thread);
*/
         (*picops[instr_type])();  /* do register tracking */
         }
      ip = next_ip;
      } while (!mapping_done);
   }

putslowerstr(str)
   BYTE *str;
   {
   WORD inquote;
   BYTE onebyte[2];

   inquote = 0;
   onebyte[1] = '\0';
   while (*str)
      {
      if ((*str == '\'') || (*str == '\"'))
         {
         if (inquote)
            {
            if (*str == inquote)
               inquote = 0;
            }
         else
            inquote = *str;
         }
      onebyte[0] = *str;
      if ((!inquote) && (!upperflag))
         onebyte[0] = tolower(*str);
      PUTS(onebyte);
      str++;
      }
   }

WORD is_stringchar(c)
   BYTE c;
   {
   if (((c >= ' ') && (c <= 0x7f))
            || (c == CR)
            || (c == LF)
            || (c == eos_char))
      return(TRUE);
   return(FALSE);
   }

BYTE *strlwr(str)
   BYTE *str;
   {
   WORD i;

   i = -1;
   while (str[++i])
      str[i] = tolower(str[i]);
   return(str);
   }

WORD is_dt_data(dt_len,stringflag,eosflag)  /* TRUE if this can be expressed as a DT string */
   WORD *dt_len,*stringflag,*eosflag;
   {
   WORD addr, len, i;
   WORD isstring, quoteflag, commaflag;
   BYTE ch, ch2;
   BYTE onechar[2];

   for (addr = ip, len = 0; (addr != memory_size[pictype]-1) && (len < 32); len++, addr++)
      {
      if (((memory[addr] >> 8) != retlw_optype[pictype])
                   || (memoryknown[addr] & PROG_KNOWN)
                   || (memoryknown[addr] & PROG_LABEL))
         break;
      }
   if (len < 2)  /* if not big enough for a DT */
      return(FALSE);
   *eosflag = FALSE;
   isstring = TRUE;  /* default to ASCII string data */
   for (addr = ip, i = 0; i < len; i++, addr++)
      {
      if (!is_stringchar(memory[addr] & 0xff))
         {
         isstring = FALSE;
         break;
         }
      else
         if ((memory[addr] & 0xff) == eos_char)
            {
            i++;  /* count EOS in string length */
            *eosflag = TRUE;
            break;
            }
      }
   strcpy(instr_str,"        DT      ");
   if (!upperflag)
      strlwr(instr_str);
   if (isstring)
      {
      len = i;  /* how big this string is */
      quoteflag = FALSE;
      commaflag = FALSE;
      onechar[1] = '\0';
      for (addr = ip, i = 0;
                            (strlen(instr_str) < MAX_DT_STRLEN) && (i < len);
                                                                  i++, addr++)
         {
         if (((ch = memory[addr] & 0xff) != CR) && (ch != LF) && (ch != eos_char))
            {
            if (!quoteflag)
               {
               if (i)  /* if not 1st char */
                  strcat(instr_str,",");
               strcat(instr_str,"\"");
               quoteflag = TRUE;
               }
            onechar[0] = ch;
            strcat(instr_str,onechar);
            commaflag = FALSE;
            }
         else
            {
            if (quoteflag)
               {
               strcat(instr_str,"\"");
               if (i)  /* if not 1st char */
                  strcat(instr_str,",");
               quoteflag = FALSE;
               }
            if (commaflag)
               {
               strcat(instr_str,",");
               commaflag = FALSE;
               }
            sprintf(&instr_str[strlen(instr_str)],"0x%02x",ch);
            commaflag = TRUE;
            }
         }
      if (quoteflag)
         strcat(instr_str,"\"");
      *dt_len = i;
      *stringflag = TRUE;
      return(TRUE);
      }  /* if (isstring) */
   for (addr = ip, i = 0; (strlen(instr_str) < MAX_DT_STRLEN) && (i < len);
                                                                  i++, addr++)
      {
      if (i)  /* if not 1st char */
         strcat(instr_str,",");
      sprintf(&instr_str[strlen(instr_str)],"0x%02x",ch);
      }
   *dt_len = i;
   *stringflag = FALSE;
   return(TRUE);
   }

show_label(ip,must_have_label,label_shown)
   WORD ip,must_have_label;
   WORD *label_shown;
   {
   WORD i, j, flag;

   *label_shown = FALSE;
   flag = FALSE;  /* haven't found any symbols with this value yet */
   for (i = 0; i < num_syms; i += SYMTAB_ENTRY)
      if ((peekb(sym_seg,i+SYMTAB_FLAGBYTE_OFS) == CODE_SYMBOL)
                && (peekw(sym_seg,i+SYMTAB_VALUE_OFS) == ip))
         {
         flag = TRUE;
         for (j = 0; j < SYMTAB_NAMESIZE; j++)
            tempstr[j] = peekb(sym_seg,i+j);
         strcat(tempstr,":");
         if (show_label_ofs)
            {
            for (j = strlen(tempstr); j < 32; j++)
               tempstr[j] = ' ';
            sprintf(&tempstr[j],";%04x",ip);
            }
         myfputs(tempstr);
         myfputs("\n");
         *label_shown = TRUE;
         }
   if ((!flag) && (must_have_label))
      {
      sprintf(tempstr,"H_%04x:\n",ip);
      myfputs(tempstr);
      *label_shown = TRUE;
      }
   }

WORD myfputc(ch,fileout)
   BYTE ch;
   int fileout;
   {
#ifdef NEVERDEF
   if (string_search)
      {
      find_str[find_str_len++] = ch;
      if (ch == '\n')
         {
         find_str[find_str_len] = '\0';  /* string wasn't terminated before */
         strlwr(find_str);
         if (check_str())
            {
            string_found = TRUE;
            puts(hexword(&search_ip,globalstr));
            puts(":");
            puts(nl_str);
            puts(find_str);
            }
         find_str_len = 0;
         }
      return(TRUE);
      }
   else
#endif
   if (myfputsok == -1)  /* Ooops! */
      return(-1);
    else
      return(fputc(ch,fileout));
   }

myfputs(str)
   BYTE *str;
   {
   WORD temp;
   BYTE ch,ch2;  /* 2 to keep stack even */

   if (myfputsok == -1)
      return;
   if (!upperflag)
      {
      strcpy(lowerstr,str);  /* do not lowercase constant strings! */
      str = strlwr(lowerstr);
      }
   while (ch = *(str++))
      {
      fileout_len++;
      if (ch == '\t')
         {
         temp = fileout_len;
         fileout_len += 7 - ((fileout_len-1) % 8);
                                            /* -1 because of inc above */
         if (!use_tabs)
            {
            for (; temp < fileout_len; temp++)
               myfputc(' ',fileout);
            ch = ' ';
            }
         }
      if (ch == '\n')
         {
         fileout_len = 0;
         if ((pagepause) && (++linecount > 23))
            {
            if (pressany(TRUE) == '\033')
               {
               myfputsok = -1;  /* if Esc, quit! */
               break;
               }
            linecount = 0;
            }
         myfputc('\r',fileout);
         }
      myfputsok = myfputc(ch,fileout);
      }
   }

myfputs2(str)
   BYTE *str;
   {
   WORD temp;
   BYTE ch,ch2;  /* 2 to keep stack even */

   if (myfputsok == -1)
      return;
   while (ch = *(str++))
      {
      fileout_len++;
      if (ch == '\t')
         {
         temp = fileout_len;
         fileout_len += 7 - ((fileout_len-1) % 8);
                                            /* -1 because of inc above */
         if (!use_tabs)
            {
            for (; temp < fileout_len; temp++)
               myfputc(' ',fileout);
            ch = ' ';
            }
         }
      if (ch == '\n')
         {
         fileout_len = 0;
         if ((pagepause) && (++linecount > 23))
            {
            if (pressany(TRUE) == '\033')
               {
               myfputsok = -1;  /* if Esc, quit! */
               break;
               }
            linecount = 0;
            }
         myfputc('\r',fileout);
         }
      myfputsok = myfputc(ch,fileout);
      }
   }

preview_file()
   {
   cls();
   puts("Preview Disassembled file:");
   putsat(5,0,"Do you want to pause on page boundaries? (Y/N, Return = No) ");
   GETS(tempstr);
   pagepause = FALSE;
   fileout = 0;
   if (toupper(tempstr[0]) == 'Y')
      pagepause = TRUE;
   write_disassembly(TRUE);  /* do preview */
   pagepause = FALSE;
   if (myfputsok != -1)
      {
      puts("\n\nPress any key to return to the menu...");
      ci();
      }
   }

write_disassembly(do_preview)
   WORD do_preview;
   {
   WORD i, j, r ,p, flag;
   WORD ip_increment;
   WORD stringflag;
   WORD need_dt_label;
   WORD just_labeled;
   WORD unknown_ok;

   stringflag = FALSE;
   need_dt_label = TRUE;
   myfputsok = TRUE;  /* anything but -1 */
   fileout_len = 0;  /* start off clean */
   linecount = 0;
   cls();
   if (!do_preview)
      {
      if ((fileout = creat(outfile)) == -1)
         {
         sprintf(tempstr,"Unable to create output file %s.\nDisassembly aborted.\n",outfile);
         PUTS(tempstr);
         return;
         }
      PUTS("\nDisassembling program\n\n");
      }
   sprintf(tempstr,";\n;  Disassembly by PICDIS V%d.%d%c\n;\n;  %s\n;\n",
            MAJOR_VERSION,MINOR_VERSION,MINOR_VERSION_CHAR,filename);
   myfputs(tempstr);
   sprintf(tempstr,"        LIST   P=%s\n",pic_name[pictype]);
   myfputs(tempstr);
   if (show_regdefs)
      {
      for (p = 0, i = 0;
             p < ram_size[pictype] / (regindex_mask[pictype]+1);
                       p++, i += regindex_mask[pictype] + 1)
         {
         flag = TRUE;  /* need to display page header */
         for (r = 0; r <= regindex_mask[pictype]; r++)
            {
            if (regnames[pictype][r+i].rname)  /* if not NULL */
               {
               if (flag)
                  {
                  sprintf(tempstr,";\n; Ram page %d registers\n;\n",p);
                  myfputs(tempstr);
                  flag = FALSE;
                  }
               sprintf(instr_str,"%s",regnames[pictype][r+i].rname);
                    /* use instr_str so we can use the add_tab() fn */
               add_tab();
               sprintf(&instr_str[temp1],"EQU");
               add_tab();
               sprintf(&instr_str[temp1],"0x%03x\n",r+i);
               myfputs(instr_str);
               if (regnames[pictype][r+i].bitnames)  /* if not NULL */
                  {
                  sprintf(tempstr,";  %s bits\n",regnames[pictype][r+i].rname);
                  myfputs(tempstr);
                  for (j = 0; j < 8; j++)
                     {
                     if (regnames[pictype][r+i].bitnames[j])  /* if not NULL */
                        {
                        sprintf(instr_str,"        %s",regnames[pictype][r+i].bitnames[j]);
                        add_tab();
                        sprintf(&instr_str[temp1],"EQU");
                        add_tab();
                        sprintf(&instr_str[temp1],"%d\n",j);
                        myfputs(instr_str);
                        }
                     }  /* for (j... ) */
                  myfputs(";\n");
                  }  /* if (bitnames) */
               }  /* if (rname) */
            }  /* for (r...) */
         }  /* for (p...) */
      }  /* if (show_regdefs) */
   else
      {
      sprintf(tempstr,"        INCLUDE \"P%s.REG\"\n",pic_name[pictype]);
      myfputs(tempstr);
      }
   if (have_configuration)
      {
      sprintf(tempstr,"        __CONFIG 0X%04x\n",configuration);
      myfputs(tempstr);
      }
   flag = TRUE;  /* need display user symbol message */
   for (i = 0; i < num_syms; i += SYMTAB_ENTRY)
      {
      if (peekb(sym_seg,i+SYMTAB_FLAGBYTE_OFS) == DATA_SYMBOL)
         {
         if (flag)
            {
            myfputs(";\n;   User data symbols\n;\n");
            flag = FALSE;
            }
         for (j = 0; j < SYMTAB_NAMESIZE; j++)
            tempstr[j] = peekb(sym_seg,i+j);
         myfputs(tempstr);
         for (j = strlen(tempstr); j < 32; j++)
            myfputs(" ");
         sprintf(tempstr,"EQU     0x%04x",peekw(sym_seg,i+SYMTAB_VALUE_OFS));
         if (peekb(sym_seg,i+SYMTAB_LENBYTE_OFS))  /* if we have a size */
            sprintf(&tempstr[strlen(tempstr)],"  ;%s",size_strs[peekb(sym_seg,i+SYMTAB_LENBYTE_OFS)]);
         myfputs(tempstr);
         myfputs("\n");
         }
      }
   sprintf(tempstr,";\n        ORG     0x%04x\n;\n",start_ip[pictype]);
   myfputs(tempstr);
   for (next_ip = ip = start_ip[pictype], i = 0;
                 i < memory_size[pictype];
                 ip = (ip + ip_increment) & (memory_size[pictype]-1), i += ip_increment)
      {
      ip_increment = 1;
      if ((!(memoryknown[ip] & PROG_CODE)) && (!disassemble_default_code))
         continue;  /* try next... */
      if ((ip != next_ip) && (memoryknown[ip] & (PROG_CODE | PROG_KNOWN)))
         {
         sprintf(tempstr,";\n        ORG     0x%04x\n;\n",ip);
         myfputs(tempstr);
         }
      show_label(ip,memoryknown[ip] & PROG_LABEL,&just_labeled);  /* a label references this addr, make sure we display a label */
      if (memoryknown[ip] & (PROG_CODE | PROG_KNOWN))  /* if actual code... */
         {
         instr_str[0] = '\0';  /* clear string */
         add_tab();
         opcode = memory[ip];
         filenum = opcode & regindex_mask[pictype];  /* isolate register file */
         dest = opcode & dest_mask[pictype];  /* isolate F/!W bit */
         instr_type = opcode >> optypes_shift[pictype];
         if ((generate_dt)
                   && ((opcode >> 8) == retlw_optype[pictype])
                   && (is_dt_data(&ip_increment,&stringflag,&flag)))
            {
            if ((need_dt_label) && (!just_labeled))
               {
               sprintf(tempstr,"H_%04x:\n",ip);
               myfputs(tempstr);
               }
            need_dt_label = flag;  /* setup for next pass */
            }
         else
            {
            need_dt_label = TRUE;
            unknown_ok = FALSE;
            if ((disassemble_unknown_code) || (memoryknown[ip] & PROG_KNOWN))
               unknown_ok = TRUE;
            if ((unknown_ok)
                  && ((disassemble_default_code) || (memoryknown[ip] & PROG_CODE)))
               {
               (*disasmpicops[instr_type])();  /* get opcode string */
               if (hex_code_comments)
                  {
                  tabout(56);
                  sprintf(&instr_str[temp1],";%04x %04x",ip,memory[ip]);
                  }
               if (!(memoryknown[ip] & PROG_CODE))  /* if chip default */
                  {
                  tabout(64);
                  strcpy(&instr_str[temp1],";DEF. OPCODE");
                  }
               if ((flag_unmapped_code)
                       && (!(memoryknown[ip] & PROG_KNOWN)))  /* if we didn't get here */
                  {
                  tabout(64);
                  strcpy(&instr_str[temp1],";U");
                  }
               }
            else
               {
               if (memoryknown[ip] & PROG_CODE)
                  {
                  sprintf(&instr_str[temp1],"DW");
                  add_tab();
                  sprintf(&instr_str[temp1],"0x%04x",memory[ip]);
                  if (comment_unknown_code_with_opcode)
                     {
                     tabout(32);
                     sprintf(&instr_str[temp1],";%04x ",ip);
                     (*disasmpicops[instr_type])();  /* get opcode string */
                     }
                  }
               }  /* if ((unknown_ok) ... */
            }  /* is not DT data */
         next_ip = (ip + ip_increment) & (memory_size[pictype]-1);
         if (stringflag)  /* if a string, do not change it's case! */
            myfputs2(instr_str);
         else
            myfputs(instr_str);
         myfputs("\n");
         if ((stringflag) && (hex_data_comments))
            {
            strcpy(instr_str,";  ");
            for (j = 0; j < ip_increment; j++)
               {
               stringflag = TRUE;
               sprintf(&instr_str[strlen(instr_str)],"0x%02x",memory[ip+j]&0xff);
               if ((j) && ((j & 7) == 0))
                  {
                  myfputs(instr_str);
                  myfputs("\n");
                  stringflag = FALSE;
                  strcpy(instr_str,";  ");
                  }
               else
                  if (j != ip_increment-1)
                     sprintf(&instr_str[strlen(instr_str)],",");
               }
            if (stringflag)
               {
               myfputs(instr_str);
               myfputs("\n");
               }
            }  /* if ((stringflag) && (hex_data_comments)) */
         stringflag = FALSE;
         if (csts())
            if (ci() == '\033')
               return;
         }  /* if actual code */
/*      if ((ip == memory_size[pictype] - 1) && (!(memoryknown[next_ip] & PROG_LABEL))) */
      if ((ip == memory_size[pictype] - 1) && (i != ip))
         myfputs(";\n        ORG     0x0000\n;\n");
      }
   myfputs(";\n        END\n");
   if (!do_preview)
      close(fileout);
   }

find_new_thread()
   {
   WORD count;

   next_ip = (ip + 1) & (memory_size[pictype]-1);  /* if skip... */
   if (skip_find_new_thread)
      return;
         /* if set, we're in the "maybe skipped" instr of an DECFSZ, INCFSZ,
          * BTFSC, or BTFSS sequence, and can safely continue to the next
          * instruction instead of forgetting registers and finding a new
          * thread.
          */
   PUTS(".");
   if (knownstackptr)  /* if we've left something undone */
      {
      knownstackptr -= KS_ENTRY;
      w = POP_KS_BYTE(KS_W);
      wknown = POP_KS_BYTE(KS_WKNOWN);
      regs[STATUS] = POP_KS_BYTE(KS_STATUS);
      regsknown[STATUS] = POP_KS_BYTE(KS_STATKNOWN);
      regs[FSR] = POP_KS_BYTE(KS_FSR);
      regsknown[FSR] = POP_KS_BYTE(KS_FSRKNOWN);
      if (pic_core[pictype] == CORE_14)
         {
         regs[PCLATH] = POP_KS_BYTE(KS_PCLATH);
         regsknown[PCLATH] = POP_KS_BYTE(KS_PCLATHKNOWN);
         }
      next_ip = POP_KS_WORD(KS_ADDR);
      return;
      }
   mapping_done = TRUE;
   for (count = 0; count < memory_size[pictype]; count++)
      {
      if ((memoryknown[count] & PROG_LABEL) && (!(memoryknown[count] & PROG_KNOWN)))
         {
         mapping_done = FALSE;
         next_ip = count;
         regs_unknown();
         break;
         }
      }
   }

WORD strcmpi(str1,str2)  /* write what should be a library function */
   BYTE *str1, *str2;
   {
   while ((*str1) && (*str2))
      {
      if (toupper(*str1) != toupper(*str2))
         return(1);
      str1++;
      str2++;
      }
   if (*str1 == *str2)  /* make sure both are at EOS */
      return(0);
   return(1);
   }

WORD strncmpi(s1,s2,n)  /* write what should be a library function */
   BYTE *s1, *s2;
   WORD n;
   {
   while ((n--) && (*s1) && (*s2))
      {
      if (toupper(*s1) != toupper(*s2))
         return(1);  /* not the same */
      s1++;
      s2++;
      }
   if (n == -1)  /* if end of number of bytes */
      return(0);  /* a match! */
   if ((*s1) || (*s2))  /* if not both at EOS */
      return(1);  /* no match */
   return(0);  /* a match */
   }

WORD ishexdigit(ch)  /* for load_hexfile() */
   BYTE ch;
   {
   if ((ch >= '0') && (ch <= '9'))
      return(TRUE);
   if ((toupper(ch) >= 'A') && (toupper(ch) <= 'F'))
      return(TRUE);
   return(FALSE);
   }

WORD check_hex_string(str)  /* for load_hexfile() */
   BYTE *str;
   {
   while ((*str) && (*str != '\015') && (*str != '\012'))
      {
      if (!ishexdigit(*str))
         return(FALSE);
      str++;
      }
   return(TRUE);
   }

WORD hexbytevalue(str)  /* for load_hexfile() */
   BYTE *str;
   {
   WORD val;
   BYTE hold;

   hold = str[2];
   str[2] = '\0';
   sscanf(str,"%x",&val);
   str[2] = hold;
   return(val);
   }

WORD hexwordvalue(str)  /* for load_hexfile() */
   BYTE *str;
   {
   WORD val;
   BYTE hold;

   hold = str[4];
   str[4] = '\0';
   sscanf(str,"%x",&val);
   str[4] = hold;
   return(val);
   }

WORD valid_checksum(str)  /* for load_hexfile() */
   BYTE *str;
   {
   WORD checksum;

   checksum = 0;
   while ((*str) && (*str != '\015') && (*str != '\012')
            && (*(str+1)) && (*(str+1) != '\015') && (*(str+1) != '\012'))
      {
      checksum += hexbytevalue(str);
      str += 2;
      }
   if (checksum & 0xff)
      return(FALSE);
   return(TRUE);
   }

load_hexfile()
   {
   WORD start, addr, bytecount, i;
   WORD linecount, is_hex_string, len_bad, chksum_valid;

   linecount = 0;
   for (addr = 0 ; addr < memory_size[pictype]; addr++)
      memory[addr] = instruction_bitmask[pictype];  /* fill with 0xff bits */
   memory[memory_size[pictype]-1] = last_instr[pictype];
   while (fgets(tempstr,126,filein))
         /*
          *  WARNING: I'm taking advantage of a DeSmet C "quirk" here.  I've
          *           used open() instead of fopen() on the file, but I'm
          *           calling fgets().  DeSmet does not distinguish between
          *           the types of file handles, and so this works.  This
          *           makes porting harder, however.
          */
      {
      linecount++;
      len_bad = 0;
      is_hex_string =
      chksum_valid = TRUE;
      if ((strlen(tempstr) < 12) || (tempstr[0] != ':')
             || (tempstr[7] != '0')
             || ((tempstr[8] != '0') && ((tempstr[8] < '1') || (tempstr[8] > '5')))
             || (!(is_hex_string = check_hex_string(&tempstr[1])))
             || ((len_bad = strlen(tempstr) & 1))
             || (!(chksum_valid = valid_checksum(&tempstr[1]))))
         {
/*
printf("strlen=%d  ts[0]=%c  ts[7]=%c  ts[8]=%c  (i_h_s=%d  l_b=%d  cs_v=%d]\n",
   strlen(tempstr),tempstr[0],tempstr[7],tempstr[8],is_hex_string,len_bad,chksum_valid);
*/
         printf("Error: corrupt/invalid hex file at line %d%s.\n",
           linecount,
           (is_hex_string ? ((len_bad == 0) ? (chksum_valid ? "" : " (bad checksum)") : " (bad len)") : " (not hex)"));
/*
         PUTS(tempstr);
*/
         return(FALSE);
         }
      if (tempstr[8] == '4')  /* if extended linear address record */
         {
         if (hexwordvalue(&tempstr[9]) != 0)
            {
            PUTS("Error: extended linear address out of range.\n");
            return(FALSE);
            }
         continue;
         }
      if ((tempstr[8] == '2') || (tempstr[8] == '3'))
               /* if segment address */
         {
         PUTS("Error: segment address records not supported.\n");
         return(FALSE);
         }
      if (tempstr[8] == '5')  /* if linear address */
         {
         PUTS("Error: linear address records not supported.\n");
         return(FALSE);
         }
      bytecount = hexbytevalue(&tempstr[1]);
      start = hexwordvalue(&tempstr[3]);
      if ((bytecount & 1) || (start & 1)) /* if not an even number of BYTES */
         {
         PUTS("Error:  Hex file does not contain WORD data.\n");
         return(FALSE);
         }
      addr = start >> 1;  /* get WORD address */
      if (addr >= memory_size[pictype])
              /* check for ID bits / configuaration / EEPROM, else error */
         {
         if ((addr >= eeprom_loc[pictype])
                         && (addr < eeprom_loc[pictype]+eeprom_size[pictype]))
                       /* if EEPROM data */
            {
            for (i = 9, addr -= eeprom_loc[pictype]; i < bytecount+bytecount+9; i += 4, addr++)
               {
               if (addr >= eeprom_size[pictype])
                  {
                  PUTS("Error: EEPROM data out of range!\n");
                  return(FALSE);
                  }
/*               eeprom[addr] = hexbytevalue(&tempstr[i]); */
               }
            }
         else
            if ((addr == config_loc[pictype]) && (bytecount == 2))
               {
               configuration = (hexbytevalue(&tempstr[9])
                                  + (hexbytevalue(&tempstr[11]) << 8))
                               & config_mask[pictype];
               have_configuration = TRUE;
               }
            else
               if ((addr < id_loc[pictype]) || (addr > id_end[pictype]))
                  {
                  PUTS("Error:  Hex file too big for memory!\n");
                  return(FALSE);
                  }
         }
      else
         {
         for (i = 9; i < bytecount+bytecount+9; i += 4, addr++)
            {
            if (addr >= memory_size[pictype])
               {
               PUTS("Error:  Hex file too big for memory!\n");
               return(FALSE);
               }
            memory[addr] = (hexbytevalue(&tempstr[i])
                                  + (hexbytevalue(&tempstr[i+2]) << 8))
                              & instruction_bitmask[pictype];
            SETCFLAG(addr,PROG_CODE);
            }  /* for (i = 9; ...) */
         }  /* if (start >= ...) else */
      }  /* while (fgets()) */
   return(TRUE);
   }

load_codfile()
   {
   BYTE picname[128];
   BYTE code_map[MAP_SIZE];  /* get MAP (for .COD file) */ 
   BYTE sector_map[SECTMAP_SIZE];  /* sector map (for .COD file) */
   WORD temp;
   WORD startaddr, startaddr2, endaddr, size;
   WORD first_mapsector, last_mapsector;
   WORD first_longsym_sector, last_longsym_sector;
   WORD mapindex;
   WORD len;
   WORD count;
   WORD need_pause;
   DWORD filesector;

   picname[0] = '\0';  /* null name so far */
   need_pause = FALSE;
   if (read(filein,sector_map,SECTMAP_SIZE) == 0)
      {
      PUTS(not_a_codfile);
      return(FALSE);
      }
   first_mapsector = *(WORD *)&sector_map[CODFILE_FIRST_MAPSECTOR];
   last_mapsector = *(WORD *)&sector_map[CODFILE_LAST_MAPSECTOR];
   first_longsym_sector = *(WORD *)&sector_map[CODFILE_LONGSYM_START];
   last_longsym_sector = *(WORD *)&sector_map[CODFILE_LONGSYM_END];
   if (sector_map[CODFILE_PROCESSOR_NAMELEN])  /* if name exists */
      {
      for (len = 0; len < sector_map[CODFILE_PROCESSOR_NAMELEN]; len++)
         picname[len] = sector_map[CODFILE_PROCESSOR_NAME+len];
      picname[len] = '\0';
      for (temp = P12C509A; temp <= PIC_MAX; temp++)
         if (strncmpi(&sector_map[CODFILE_PROCESSOR_NAME],pic_name[temp],len-1) == 0)
            break;
      if (temp == PIC_MAX + 1)
         {
         printf("The target processor for this .COD file (%s)\nis not supported by PICDIS\n",
                           picname);
         return(FALSE);
         }
      if (temp != pictype)
         {
         printf("This .COD file is for a %s.  Changing processor type.\n",
                     picname);
         pictype = temp;
         need_pause = TRUE;
         }
      }
   lseek(filein,(DWORD)CODFILE_SECTOR_SIZE * (DWORD)first_longsym_sector,0);  /* goto 1st symbol */
   while (TRUE)  /* use BREAK to get out */
      {
      len = 0;  /* clear high byte */
      if (read(filein,&len,1) != 1)
         {
         PUTS(not_a_codfile);
         return(FALSE);
         }
      if (!len)  /* if end of table */
         break;
      if (read(filein,diskbuf,len+CODFILE_LONGSYM_DATASIZE) != len+CODFILE_LONGSYM_DATASIZE)
         {
         PUTS(not_a_codfile);
         return(FALSE);
         }
      for (count = 0; (count < len) && (count < SYMTAB_NAMESIZE-1); count++)
         pokeb(sym_seg,num_syms+count,diskbuf[count]);
      for ( ; count < SYMTAB_NAMESIZE; count++)
         pokeb(sym_seg,num_syms+count,0);  /* 0-fill string */
      temp = (WORD)diskbuf[len+5] + ((WORD)diskbuf[len+4] << 8);
      pokew(sym_seg,num_syms+SYMTAB_VALUE_OFS,temp);
      if ((diskbuf[len] >= CODFILE_FLAGBYTE_FIRSTLABEL)
               && (diskbuf[len] <= CODFILE_FLAGBYTE_LASTLABEL))
         {
         pokeb(sym_seg,num_syms+SYMTAB_FLAGBYTE_OFS,CODE_SYMBOL);
/*         SETCFLAG(temp,PROG_LABEL); */  /* note that we have a label here */
         }
      else
         pokeb(sym_seg,num_syms+SYMTAB_FLAGBYTE_OFS,DATA_SYMBOL);
      if ((diskbuf[len] == SYM_SIGNED_ONEBYTE) || (diskbuf[len] == SYM_UNSIGNED_ONEBYTE))
         pokeb(sym_seg,num_syms+SYMTAB_LENBYTE_OFS,1);
      else
         if ((diskbuf[len] == SYM_SIGNED_TWOBYTE) || (diskbuf[len] == SYM_UNSIGNED_TWOBYTE))
            pokeb(sym_seg,num_syms+SYMTAB_LENBYTE_OFS,2);
         else
            if ((diskbuf[len] == SYM_SIGNED_FOURBYTE) || (diskbuf[len] == SYM_UNSIGNED_FOURBYTE))
               pokeb(sym_seg,num_syms+SYMTAB_LENBYTE_OFS,4);
      num_syms += SYMTAB_ENTRY;
      if (num_syms == MAX_SYMS)
         break;  /* symtable full, quit */
      }
   lseek(filein,(DWORD)CODFILE_SECTOR_SIZE * (DWORD)first_mapsector,0);  /* goto code map table */
   if (read(filein,code_map,MAP_SIZE) != MAP_SIZE)
      {
      PUTS(not_a_codfile);
      return(FALSE);
      }
   for (temp = 0; temp < memory_size[pictype]; temp++)
      memory[temp] = instruction_bitmask[pictype];
   memory[memory_size[pictype]-1] = last_instr[pictype];
   mapindex = 0;
   while (first_mapsector <= last_mapsector)
      {
      startaddr = *(WORD *)&code_map[mapindex];
      endaddr = *(WORD *)&code_map[mapindex+2];
              /* NOTE:
               *    I think the following code is more complex than it needs
               *    to be, but I'm going to allow for the possibility that
               *    code sections are neither contiguous nor in order.
               */
      while (startaddr < endaddr)  /* do entire section */
         {
         if ((filesector = (DWORD)(*(WORD *)&sector_map[(startaddr >> 8) & 0xfe])) == 0)
            {
            PUTS("  invalid sector map.");
            PUTS(not_a_codfile);
            return(FALSE);
            }
         lseek(filein,filesector * (DWORD)CODFILE_SECTOR_SIZE + (startaddr % CODFILE_SECTOR_SIZE),0);
         size = MIN(endaddr-startaddr+1,CODFILE_SECTOR_SIZE - (startaddr % CODFILE_SECTOR_SIZE));
         if ((startaddr2 = startaddr/2) >= memory_size[pictype])  /* not legal, special memory location? */
            {
            if ((startaddr2 == config_loc[pictype]) && (size == 2))  /* if CONFIG data */
               {
               if (read(filein,&temp,2) != 2)
                  {
                  PUTS(codfile_badread);
                  return(FALSE);
                  }
               configuration = temp & config_mask[pictype];
               have_configuration = TRUE;
               }
            else
               {
               if ((startaddr2 >= eeprom_loc[pictype])
                    && ((startaddr2+(size/2)) <= eeprom_loc[pictype]+eeprom_size[pictype]))
                               /* if EEPROM (allow EEPROM to come in pieces) */
                  {
                  lseek(filein,(DWORD)size,1);  /* skip eeprom */
                  }
               else
                  {
                  if ((startaddr2 < id_loc[pictype])
                                 || (startaddr2+(size/2) > id_end[pictype]+1))
                     {
                     PUTS(invalid_memory_map);
                     return(FALSE);
                     }
                  }
               }
            }
         else
            {
            if ((startaddr2 + size/2) > memory_size[pictype])
               {
               PUTS(invalid_memory_map);
               return(FALSE);
               }
            if (read(filein,&memory[startaddr2],size) != size)
               {
               PUTS(codfile_badread);
               return(FALSE);
               }
            for (temp = 0; temp < size; temp += 2)
               {
               memory[startaddr2+temp/2] &= instruction_bitmask[pictype];
               SETCFLAG(startaddr2+temp/2,PROG_CODE);
               }
            }
         startaddr += size;
         }  /* while (startaddr != endaddr) */
      mapindex += 4;
      if (mapindex == CODFILE_SECTOR_SIZE)  /* time for next map sector */
         {
         if (++first_mapsector <= last_mapsector)
            {
            lseek(filein,(DWORD)CODFILE_SECTOR_SIZE * (DWORD)first_mapsector,0);  /* goto code map table */
            if (read(filein,code_map,MAP_SIZE) != MAP_SIZE)
               {
               PUTS(not_a_codfile);
               return(FALSE);
               }
            mapindex = 0;
            }
         }  /* if (mapindex == CODFILE_SECTOR_SIZE) */
      }  /* while (first_mapsector <= last_mapsector) */
   if (need_pause)
      pressany(FALSE);
   return(TRUE);
   }

void itoa(number,str)    /* write what should be a library routine */
   int number;
   char *str;
   {
   char buffer[7], *ptr;

   buffer[6] = '\0';
   ptr = &buffer[5];
   do
      {
      *(ptr--) = number  % 10 + '0';
      } while ((number /= 10) > 0);
   ptr++;
   strcpy(str, ptr);
   }

BYTE *itox(val,str)
   unsigned int val;
   unsigned char *str;
   {
   int i;

   str += 4;
   for (i = 0; i < 4; i++)
      {
      *(--str) = (val & 0x0f) + (((val & 0x0f) > 9) ? 'A'-10 : '0');
      val >>= 4;
      }
   str[4] = '\0';
   return(str);
   }

int  numval(str,val)  /* change hex value in str to a number */
                      /* return FALSE if invalid hex number, else TRUE */
   BYTE *str;
   WORD *val;  /* Beware of passing an INT pointer to this routine
                *  if the machine does not use low-byte first!
                */
   {
   WORD i, valid;
   BYTE ch;

   i = 0;
   *val = 0;
   valid = FALSE;
   ch = toupper(str[i++]);
   while (ch)
      {
      valid = TRUE;
      if (isdigit(ch))
         *val = (*val << 4) + ch - '0';  /* a number */
      else
         if ((ch >= 'A') && (ch <= 'F'))  /* a letter */
            *val = (*val << 4) + ch - 'A' + 10;
         else
            return(FALSE);
      ch = toupper(str[i++]);
      }
   return(valid);
   }

void cls()
   {
#asm
   mov cx,0     ;row,col of upper left corner
   mov dx,184fh ;row,col of lower right corner
   mov bh,7     ;fill attribute
   mov ax,600h  ;scroll up entire window
   push bp      ;save bp
   int 10h      ;call BIOS
   pop bp       ;restore bp
   mov dx,0     ;row 0, col 0
   mov bh,0     ;page 0
   mov ah,2     ;set cursor position
   push bp      ;save bp
   int 10h      ;call BIOS
   pop bp       ;restore bp
#endasm
   }

clear_to_bottom(r,c)
   {
#asm
   mov ch,byte [bp+4]   ;upper left row
   mov cl,byte [bp+6]   ;upper left col
   mov dh,ch            ;lower right row
   mov dl,79            ;lower right col
   mov bh,7             ;fill attribute
   mov ax,600h          ;scroll up and erase
   push cx              ;save upper left corner
   push bp              ;save bp
   int 10h              ;call BIOS
   pop bp               ;restore bp
   pop cx               ;restore upper left corner
   cmp ch,18h           ;already at end?
   je end_of_clear_to_bottom  ;yes, we're done
   inc ch               ;next row
   xor cl,cl            ;start at col 0
   mov dx,184fh         ;lower right is row 24, col 79
   mov bh,7             ;fill attribute
   mov ax,600h          ;scroll up entire region
   push bp              ;save BP
   int 10h              ;call BIOS
   pop bp               ;restore BP
end_of_clear_to_bottom:
#endasm
   }

void curpos(row,col)
   int row,col;
   {
#asm
   mov dh,byte [bp+4]  ;row
   mov dl,byte [bp+6]  ;col
   mov bh,0            ;page
   mov ah,2            ;set cursor position
   push bp             ;save bp
   int 10h             ;call BIOS
   pop bp              ;restore bp
#endasm
   }

putsat(r,c,str)
   WORD r,c;
   BYTE *str;
   {
   curpos(r,c);
   puts(str);
   }

int pressany(flag)
   int flag;
   {
   puts("\nPress any key to continue");
   if (flag)
      puts(", or Esc to quit");
   return(check_key());
   }

int check_key()
   {
   int retval;

   if ((retval = ci()) == '\0')  /* if 1st key of extended keypress */
      retval = ci();
   return(retval);
   }

BYTE peekb(seg,ofs)  /* peek a BYTE address */
   WORD seg,ofs;
   {
#asm
   push   es
   mov    es,word [bp+4]
   mov    bx,word [bp+6]
   xor    ax,ax               ;ah = 0
   mov    al,byte es:[bx]
   pop    es
#endasm
   }

WORD peekw(seg,ofs)  /* peek a WORD address */
   WORD seg,ofs;
   {
#asm
   push   es
   mov    es,word [bp+4]
   mov    bx,word [bp+6]
   mov    ax,word es:[bx]
   pop    es
#endasm
   }

void pokeb(seg,ofs,val)  /* poke a BYTE address */
   WORD seg,ofs,val;
   {
#asm
   push   es
   mov    es,word [bp+4]
   mov    bx,word [bp+6]
   mov    ax,word [bp+8]
   mov    byte es:[bx],al
   pop    es
#endasm
   }

void pokew(seg,ofs,val)  /* poke a WORD address */
   WORD seg,ofs,val;
   {
#asm
   push   es
   mov    es,word [bp+4]
   mov    bx,word [bp+6]
   mov    ax,word [bp+8]
   mov    word es:[bx],ax
   pop    es
#endasm
   }

memfill(seg,offset,len,byte)
     /* +4  +6     +8  +10 */
   {
#asm
   mov es,word [bp+4]
   mov di,word [bp+6]
   mov cx,word [bp+8]
   mov al,byte [bp+10]
   cld                 ;up!
   db 0f3h             ;REP
   stosb               ;fill with byte
#endasm
   }

/* Following code borrowed from my DEBUG8 program, a CHIP-8 emulator
 * and debugger.
 */
WORD getkey()
   {
#asm
   mov  ax,1000h     ;fn = get extended keypress
   int  16h          ;call BIOS
   cmp  al,0         ;fnkey, etc?
   jz   getkey_fnkey ;yes, skip this
   mov  ah,0         ;ignore scancode
   jmp  getkey_end   ;and done
getkey_fnkey:
   mov  al,ah        ;set scancode = "key"
   mov  ah,1         ;set extended keypress flag
getkey_end:
#endasm
   }

void mygets(str)
   BYTE *str;
   {
   BYTE buf[STRING_SIZE];
   WORD i = 0;
   WORD ch;

   do
      {
      ch = getkey();
      if (ch == '\t')  /* tabs can be hard */
         ch = ' ';  /* make it easy on ourselves... */
      if (ch == '\033')  /* ESC_KEY erase line */
         {
         while (i)
            {
            puts("\010 \010");
            i--;
            }
         }
      if (ch == '\010')  /* BackSpace */
         {
         if (i)
            {
            puts("\010 \010");
            i--;
            }
         }
      else if ((ch != '\r')
                 && (ch < 0x100)  /* not CR, and not FN key (etc) */
                 && (ch >= ' ')  /* and is regular ASCII */
              )
         {
         if (i < STRING_SIZE - 2)
            {
            *(str+i) = ch;
            *(str+i+1) = 0;  /* EOS */
            puts(str+i);
            i++;
            }
         }
      } while (ch != '\r');
   *(str+i) = 0;  /* EOS */
   }
