/*
 *  PIC disassembler.
 *
 *  Based on code from PICEMU (P12==12C509A, P84==16F84A, and P14==16f877)
 *  and CODEGEN.
 *
 *  This is the 14-bit PICOPS stuff.  All common routines between PDPIC12.C
 *  and PDPIC14.C will be put in PDPIC12.C
 *
 *  Note the use of STATIC on function definitions to keep them local to
 *  this sourcefile (i.e. not in the link map).  This allows common routine
 *  names between PDPIC12.C and PDPIC14.C.
 *
 *  Copyright (c) 2002
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICDIS
 *
 *  PICDIS is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICDIS is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  Date      Comments
 *  --------  -------------------------------------------
 *  6/12/02   Start programming
 *  8/11/03   Update to add 12F675
 */
#include <picdis.h>


extern BYTE indf_n[];
extern BYTE tmr0_n[];
extern BYTE pcl_n[];
extern BYTE status_n[];
extern BYTE fsr_n[];
extern BYTE gpio_n[];
extern BYTE osccal_n[];
extern BYTE *gpiobits[8];

static BYTE *statbits[8] =
   {  "C", "DC", "Z", "PD", "TO", "RP0", "RP1", "IRP" };
static BYTE pir1_n[] = "PIR1";
static BYTE *pir1675[8] =
   { "TMR1IF", NULL, NULL, "CMIF", NULL, NULL, "ADIF", "EEIF" };
static BYTE *intcon675[8] =
   { "GPIF", "INTF", "T0IF", "GPIE", "INTE", "T0IE", "PEIE", "GIE" };
static BYTE tmr1l_n[] = "TMR1L";
static BYTE tmr1h_n[] = "TMR1H";
static BYTE t1con_n[] = "T1CON";
static BYTE *t1con675[8] =
   { "TMR1ON", "TMR1CS", "T1SYNC", "T1OSCEN", "T1CKPS0", "T1CKPS1", "TMR1GE", NULL };
static BYTE cmcon_n[] = "CMCON";
static BYTE *cmcon675[8] =
   { "CM0", "CM1", "CM2", "CIS", "CINV", NULL, "COUT", NULL };
static BYTE adresh_n[] = "ADRESH";
static BYTE adcon0_n[] = "ADCON0";
static BYTE *adcon0675[8] =
   { "ADON", "GODONE", "CHS0", "CHS1", NULL, NULL, "VCFG", "ADFM" };
static BYTE *tris675[8] =
   { "TRIS0", "TRIS1", "TRIS2", "TRIS3", "TRIS4", "TRIS5", NULL, NULL };
static BYTE pie1_n[] = "PIE1";
static BYTE *pie1675[8] =
   { "TMR1IE", NULL, NULL, "CMIE", NULL, NULL, "ADIE", "EEIE" };
static BYTE pcon_n[] = "PCON";
static BYTE *pcon675[8] =
   { "BOD", "POR", NULL, NULL, NULL, NULL, NULL, NULL };
static BYTE wpu_n[] = "WPU";
static BYTE *wpu675[8] =
   { "WPU0", "WPU1", "WPU2", NULL, "WPU4", "WPU5", NULL, NULL };
static BYTE ioc_n[] = "IOC";
static BYTE *ioc675[8] =
   { "IOC0", "IOC1", "IOC2", "IOC3", "IOC4", "IOC5", NULL, NULL };
static BYTE vrcon_n[] = "VRCON";
static BYTE *vrcon675[8] =
   { "VR0", "VR1", "VR2", "VR3", NULL, "VRR", NULL, "VREN" };
static BYTE eedata_n[] = "EEDATA";
static BYTE eeadr_n[] = "EEADR";
static BYTE pclath_n[] = "PCLATH";
static BYTE intcon_n[] = "INTCON";
static BYTE option_n[] = "OPTION";
static BYTE *option675[8] =
   { "PS0", "PS1", "PS2", "PSA", "T0SE", "T0CS", "INTEDG", "GPPU" };
static BYTE eecon1_n[] = "EECON1";
static BYTE *eecon1675[8] =
   { "RD", "WR", "WREN", "WRERR", NULL, NULL, NULL, NULL };
static BYTE eecon2_n[] = "EECON2";
static BYTE adresl_n[] = "ADRESL";
static BYTE *ansel675[8] =
   { "ANS0", "ANS1", "ANS2", "ANS3", "ADCS0", "ADCS1", "ADCS2", NULL };

struct rnames names675[256] =
{
        /* 0x00 -- 0x0f */
   { indf_n, NULL },  { tmr0_n, NULL },  { pcl_n, NULL },   { status_n, statbits },
   { fsr_n, NULL },   { gpio_n, gpiobits },{ NULL, NULL },  { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { pclath_n, NULL },{ intcon_n, intcon675 },
   { pir1_n, pir1675 },{ NULL, NULL },   { tmr1l_n, NULL }, { tmr1h_n, NULL },
        /* 0x10 -- 0x1f */
   { t1con_n, t1con675 },{ NULL, NULL },    { NULL, NULL }, { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { cmcon_n, cmcon675 },{ NULL, NULL }, { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { adresh_n, NULL },{ adcon0_n, adcon0675 },
        /* 0x20 -- 0x2f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x30 -- 0x3f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x40 -- 0x4f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x50 -- 0x5f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x60 -- 0x6f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x70 -- 0x7f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x80 -- 0x8f  XLATE_REGS[] will take care of most name ptrs */
   { NULL, NULL },    { option_n, option675 },{ NULL, NULL },{ NULL, NULL },
   { NULL, NULL },    { "TRIS", tris675 },{ NULL, NULL },     { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { pie1_n, pie1675 },{ NULL, NULL },   { pcon_n, pcon675 },{ NULL, NULL },
        /* 0x90 -- 0x9f  XLATE_REGS[] will take care of most name ptrs */
   { osccal_n, NULL },{ option_n, option675 },{ NULL, NULL },{ NULL, NULL },
   { NULL, NULL },    { wpu_n, wpu675 }, { ioc_n, ioc675, },  { NULL, NULL },
   { NULL, NULL },    { vrcon_n, vrcon675},{ eedata_n, NULL },{ eeadr_n, NULL },
   { eecon1_n, eecon1675 },{ eecon2_n, NULL },{ adresl_n, NULL },{ "ANSEL", ansel675 }
/*   The automatic 0 initalization will take care of the rest of the array */
};

static BYTE porta_n[] = "PORTA";
static BYTE portb_n[] = "PORTB";
static BYTE *pa84a[8] =
   { "RA0", "RA1", "RA2", "RA3", "RA4", NULL, NULL, NULL };
static BYTE *pb_bits[8] =
   { "RB0", "RB1", "RB2", "RB3", "RB4", "RB5", "RB6", "RB7" };
static BYTE *intcon84a[8] =
   { "RBIF", "INTF", "T0IF", "RBIE", "INTE", "T0IE", "EEIE", "GIE" };
static BYTE *optionbits[8] =
   { "PS0", "PS1", "PS2", "PSA", "T0SE", "T0CS", "INTEDG", "RBPU" };
static BYTE trisa_n[] = "TRISA";
static BYTE trisb_n[] = "TRISB";
static BYTE *eecon184a[8] =
   { "RD", "WR", "WREN", "WRERR", "EEIF", NULL, NULL, NULL };

struct rnames names84a[256] =
{
        /* 0x00 -- 0x0f */
   { indf_n, NULL },  { tmr0_n, NULL },  { pcl_n, NULL },   { status_n, statbits },
   { fsr_n, NULL },   { porta_n, pa84a },{ portb_n, pb_bits },{ NULL, NULL },
   { eedata_n, NULL },{ eeadr_n, NULL }, { pclath_n, NULL },{ intcon_n, intcon84a },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x10 -- 0x1f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x20 -- 0x2f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x30 -- 0x3f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x40 -- 0x4f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x50 -- 0x5f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x60 -- 0x6f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x70 -- 0x7f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x80 -- 0x8f  XLATE_REGS[] will take care of most name ptrs */
   { NULL, NULL },    { option_n, optionbits },{ NULL, NULL },{ NULL, NULL },
   { NULL, NULL },    { trisa_n, pa84a },{ trisb_n, pb_bits },{ NULL, NULL },
   { eecon1_n, eecon184a },{ eecon2_n, NULL },{ NULL, NULL }, { NULL, NULL }
/*   The automatic 0 initalization will take care of the rest of the array */
};

static BYTE *pa628[8] =
   { "RA0", "RA1", "RA2", "RA3", "RA4", "RA5", "RA6", "RA7" };
static BYTE *intcon_b[8] =
   { "RBIF", "INTF", "T0IF", "RBIE", "INTE", "T0IE", "PEIE", "GIE" };
static BYTE *pir1628[8] =
   { "TMR1IF", "TMR2IF", "CCP1IF", NULL, "TXIF", "RCIF", "CMIF", "EEIF" };
static BYTE *t1con_b[8] =
   { "TMR1ON", "TMR1CS", "T1SYNC", "T1OSCEN", "T1CKPS0", "T1CKPS1", NULL, NULL };
static BYTE tmr2_n[] = "TMR2";
static BYTE t2con_n[] = "T2CON";
static BYTE *t2con_b[8] =
   { "T2CKPS0", "T2CKPS1", "TMR2ON", "TOUTPS0", "TOUTPS1", "TOUTPS2", "TOUTPS3", NULL };
static BYTE ccpr1l_n[] = "CCPR1L";
static BYTE ccpr1h_n[] = "CCPR1H";
static BYTE ccp1con_n[] = "CCP1CON";
static BYTE *ccp1con_b[8] =
   { "CCP1M0", "CCP1M1", "CCP1M2", "CCP1M3", "CCP1Y", "CCP1X", NULL, NULL };
static BYTE rcsta_n[] = "RCSTA";
static BYTE *rcsta_b[8] =
   { "RX9D", "OERR", "FERR", "ADDEN", "CREN", "SREN", "RX9", "SPEN" };
static BYTE txreg_n[] = "TXREG";
static BYTE rcreg_n[] = "RCREG";
static BYTE *cmcon628[8] =
   { "CM0", "CM1", "CM2", "CIS", "C1INV", "C2INV", "C1OUT", "C2OUT" };
static BYTE *pie1628[8] =
   { "TMR1IE", "TMR2IE", "CCP1IE", NULL, "TXIE", "RCIE", "CMIE", "EEIE" };
static BYTE *pcon628[8] =
   { "BOR", "POR", NULL, "OSCF", NULL, NULL, NULL, NULL };
static BYTE pr2_n[] = "PR2";
static BYTE txsta_n[] = "TXSTA";
static BYTE *txsta_b[8] =
   { "TX9D", "TRMT", "BRGH", NULL, "SYNC", "TXEN", "TX9", "CSRC" };
static BYTE spbrg_n[] = "SPBRG";
static BYTE *eecon1628[8] =
   { "RD", "WR", "WREN", "WRERR", NULL, NULL, NULL, NULL };
static BYTE *vrcon628[8] =
   { "VR0", "VR1", "VR2", "VR3", NULL, "VRR", "VROE", "VREN" };



struct rnames names628[512] =
{
        /* 0x000 -- 0x00f */
   { indf_n, NULL },  { tmr0_n, NULL },  { pcl_n, NULL },   { status_n, statbits },
   { fsr_n, NULL },   { porta_n, pa628 },{ portb_n, pb_bits },{ NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { pclath_n, NULL },{ intcon_n, intcon_b },
   { pir1_n, pir1628 },{ NULL, NULL },   { tmr1l_n, NULL }, { tmr1h_n, NULL },
        /* 0x010 -- 0x01f */
   { t1con_n, t1con_b },{ tmr2_n, NULL },{ t2con_n, t2con_b },{ NULL, NULL },
   { NULL, NULL },    { ccpr1l_n, NULL },{ ccpr1h_n, NULL },{ ccp1con_n, ccp1con_b },
   { rcsta_n, rcsta_b },{ txreg_n, NULL },{ rcreg_n, NULL },{ NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { cmcon_n, cmcon628 },
        /* 0x020 -- 0x02f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x030 -- 0x03f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x040 -- 0x04f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x050 -- 0x05f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x060 -- 0x06f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x070 -- 0x07f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x080 -- 0x08f  XLATE_REGS[] will take care of most name ptrs */
   { NULL, NULL },    { option_n, optionbits },{ NULL, NULL },{ NULL, NULL },
   { NULL, NULL },    { trisa_n, pa628 },{ trisb_n, pb_bits },{ NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },  { NULL, NULL },
   { pie1_n, pie1628 },{ NULL, NULL },   { pcon_n, pcon628 },{ NULL, NULL },
        /* 0x090 -- 0x09f  XLATE_REGS[] will take care of most name ptrs */
   { NULL, NULL },    { NULL, NULL },    { pr2_n, NULL },   { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },  { NULL, NULL },
   { txsta_n, txsta_b },{ spbrg_n, NULL }, { eedata_n, NULL },{ eeadr_n, NULL },
   { eecon1_n, eecon1628 },{ eecon2_n, NULL },{ NULL, NULL },{ vrcon_n, vrcon628 }
/*   The automatic 0 initalization will take care of the rest of the array */
};

static BYTE *pa877[8] =
   { "RA0", "RA1", "RA2", "RA3", "RA4", "RA5", NULL, NULL };
static BYTE *pc877[8] =
   { "RC0", "RC1", "RC2", "RC3", "RC4", "RC5", "RC6", "RC7" };
static BYTE *pd877[8] =
   { "RD0", "RD1", "RD2", "RD3", "RD4", "RD5", "RD6", "RD7" };
static BYTE *pe877[8] =
   { "RE0", "RE1", "RE2", NULL, NULL, NULL, NULL, NULL };
static BYTE *pir1877[8] =
   { "TMR1IF", "TMR2IF", "CCP1IF", "SSPIF", "TXIF", "RCIF", "ADIF", "PSPIF" };
static BYTE *pir2_b[8] =
   { "CCP2IF", NULL, NULL, "BCLIF", "EEIF", NULL, NULL, NULL };
static BYTE *sspcon_b[8] =
   { "SSPM0", "SSPM1", "SSPM2", "SSPM3", "CKP", "SSPEN", "SSPOV", "WCOL" };
static BYTE *ccp2con_b[8] =
   { "CCP2M0", "CCP2M1", "CCP2M2", "CCP2M3", "CCP2Y", "CCP2X", NULL, NULL };
static BYTE *adcon0_b[8] =
   { "ADON", NULL, "GODONE", "CHS0", "CHS1", "CHS2", "ADCS0", "ADCS1" };
static BYTE *trise_b[8] =
   { "RE0", "RE1", "RE2", NULL, "PSPMODE", "IBOV", "OBF", "IBF" };
static BYTE *pie1_b[8] =
   { "TMR1IE", "TMR2IE", "CCP1IE", "SSPIE", "TXIE", "RCIE", "ADIE", "PSPIE" };
static BYTE *pie2_b[8] =
   { "CCP2IE", NULL, NULL, "BCLIE", "EEIE", NULL, NULL, NULL };
static BYTE *pcon_b[8] =
   { "BOR", "POR", NULL, NULL, NULL, NULL, NULL, NULL };
static BYTE *sspcon2_b[8] =
   { "SEN", "RSEN", "PEN", "RCEN", "ACKEN", "ACKDT", "ACKSTAT", "GCEN" };
static BYTE *sspstat_b[8] =
   { "BF", "UA", "RW", "S", "P", "DA", "CKE", "SMP" };
static BYTE *adcon1_b[8] =
   { "PCFG0", "PCFG1", "PCFG2", "PCFG3", NULL, NULL, NULL, "ADFM" };
static BYTE *eecon1877[8] =
   { "RD", "WR", "WREN", "WRERR", "EEIF", NULL, NULL, "EEPGD" };


struct rnames names877[512] =
{
        /* 0x000 -- 0x00f */
   { indf_n, NULL },  { tmr0_n, NULL },  { pcl_n, NULL },   { status_n, statbits },
   { fsr_n, NULL },   { porta_n, pa877 },{ portb_n, pb_bits },{ "PORTC", pc877 },
   { "PORTD", pd877 },{ "PORTE", pe877 },{ pclath_n, NULL },{ intcon_n, intcon_b },
   { pir1_n, pir1877 },{ "PIR2", pir2_b },{ tmr1l_n, NULL }, { tmr1h_n, NULL },
        /* 0x010 -- 0x01f */
   { t1con_n, t1con_b },{ tmr2_n, NULL },{ t2con_n, t2con_b },{ "SSPBUF", NULL },
   { "SSPCON", NULL },{ ccpr1l_n, NULL },{ ccpr1h_n, NULL },{ ccp1con_n, ccp1con_b },
   { rcsta_n, rcsta_b },{ txreg_n, NULL },{ rcreg_n, NULL },{ "CCPR2L", NULL },
   { "CCPR2H", NULL },{ "CCP2CON", ccp2con_b },{ adresh_n, NULL },{ adcon0_n, adcon0_b },
        /* 0x020 -- 0x02f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x030 -- 0x03f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x040 -- 0x04f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x050 -- 0x05f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x060 -- 0x06f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x070 -- 0x07f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x080 -- 0x08f  XLATE_REGS[] will take care of most name ptrs */
   { NULL, NULL },    { option_n, optionbits },{ NULL, NULL },{ NULL, NULL },
   { NULL, NULL },    { trisa_n, pa877 },{ trisb_n, pb_bits },{ "TRISC", pc877 },
   { "TRISD", pd877 },{ "TRISE", trise_b },{ NULL, NULL },  { NULL, NULL },
   { pie1_n, pie1_b },{ "PIE2", pie2_b },{ pcon_n, pcon_b },{ NULL, NULL },
        /* 0x090 -- 0x09f  XLATE_REGS[] will take care of most name ptrs */
   { NULL, NULL },    { "SSPCON2", sspcon2_b }, { pr2_n, NULL },{ "SSPADD", NULL },
   { "SSPSTAT", sspstat_b },{ NULL, NULL },{ NULL, NULL },  { NULL, NULL },
   { txsta_n, txsta_b },{ spbrg_n, NULL }, { NULL, NULL },  { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },      { adresl_n, NULL },{ "ADCON1", adcon1_b },
        /* 0x0a0 -- 0x0af */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x0b0 -- 0x0bf */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x0c0 -- 0x0cf */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x0d0 -- 0x0df */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x0e0 -- 0x0ef */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x0f0 -- 0x0ff */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x100 -- 0x10f  XLATE_REGS[] will take care of most name ptrs */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { eedata_n, NULL },{ eeadr_n, NULL }, { "EEDATH", NULL },{ "EEADRH", NULL },
        /* 0x110 -- 0x11f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x120 -- 0x12f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x130 -- 0x13f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x140 -- 0x14f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x150 -- 0x15f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x160 -- 0x16f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x170 -- 0x17f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x180 -- 0x18f  XLATE_REGS[] will take care of most name ptrs */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { eecon1_n, eecon1877 },{ eecon2_n, NULL },{ NULL, NULL }, { NULL, NULL }
/*   The automatic 0 initalization will take care of the rest of the array */
};
