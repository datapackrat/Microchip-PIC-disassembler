/*
 *  PIC disassembler.
 *
 *  Based on code from PICEMU (P12==12C509A, P84==16F84A, and P14==16f877)
 *  and CODEGEN.
 *
 *  This is the 12-bit PICOPS stuff.  All common routines between PDPIC12.C
 *  and PDPIC14.C will be put in this file.
 *
 *  Note the use of STATIC on function definitions to keep them local to
 *  this sourcefile (i.e. not in the link map).  This allows common routine
 *  names between PDPIC12.C and PDPIC14.C.
 *
 *  Copyright (c) 2002
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICDIS
 *
 *  PICDIS is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICDIS is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *  Date      Comments
 *  --------  -------------------------------------------
 *  6/12/02   Start programming
 *  8/11/03   Update to add 12F675
 */
#include <picdis.h>

#define PIC_DECODE_BITS 6
#define FSR_MEMORYPAGE_BITMASK 0x20  /* 0010 0000 : bit 5 */
#define RESET_FSR 0xc0              /* 1100 0000b */
#define FSR_MASK 0x3f               /* maximum index into memory */

#define STATUS_PA0_SHIFT 4  /* to put this at bit 9 */
#define STATUS_PA0   0x20 /* bit mask: page flag 0 (12-bit) */

#define BITNUM_MASK 0x00e0          /* isolate bitnumber from instr */
#define BITNUM_POSITION 5           /* shift to move bitnum to bottom of word */

#define GOTO_MASK_12BIT 0x01ff  /* mask 9 bits of GOTO destination from opcode */
#define CALL_MASK_12BIT 0x00ff  /* mask 8 bits of CALL destination from opcode */

#define STATUS_C     0x01 /* bit mask */
#define STATUS_DC    0x02 /* bit mask */
#define STATUS_Z     0x04 /* bit mask */

extern BYTE w;       /* the W register */
extern BYTE wknown;  /* are contents of W known? */
extern WORD ip;            /* address of this instruction */
extern WORD next_ip;       /* where we're going next */
extern WORD opcode;        /* opcode we're working on */
extern WORD instr_type;    /* instruction bits from opcode */
extern WORD filenum;       /* index into regs */
extern WORD filenum_temp;  /* bank select bits + filenum */
extern WORD filenum_temp2; /* filenum_temp via xlat_regs[] */
extern WORD dest;          /* 1=destination is F (register File) 0=destination is W */

extern WORD statushold;    /* hold for status flags */
extern WORD statusknownhold;  /* hold for status known flags */
extern BYTE temp1;         /* useful to have around */
extern BYTE temp2;         /* useful to have around */

extern WORD skip_find_new_thread;
extern WORD skip_label_regs_unknown;

extern WORD *xlate_regs;

extern WORD hex_equivalent_of_named_regs;

extern WORD pictype;    /* which PIC is target */
extern BYTE regs[];
extern BYTE regsknown[];
extern WORD memory[];
extern BYTE memoryknown[];
extern WORD memory_size[PIC_MAX+1];
extern WORD ram_size[PIC_MAX+1];
extern WORD regindex_mask[PIC_MAX+1];
extern struct rnames *regnames[PIC_MAX+1];
extern WORD mapspace;
extern WORD knownstack;   /* segment used to hold the "known values" stack */
extern WORD knownstackptr;  /* stackpointer for "known values" */
extern WORD sym_seg;
extern WORD num_syms;

extern BYTE instr_str[STRING_SIZE];  /* disassembled instruction */

WORD bittable[8] =  /* bit mask, indexed by bit number */
   {
   0x0001,
   0x0002,
   0x0004,
   0x0008,
   0x0010,
   0x0020,
   0x0040,
   0x0080
   };

BYTE indf_n[] = "INDF";
BYTE tmr0_n[] = "TMR0";
BYTE pcl_n[]  = "PCL";
BYTE status_n[] = "STATUS";
BYTE fsr_n[] = "FSR";
BYTE gpio_n[] = "GPIO";
BYTE osccal_n[] = "OSCCAL";
BYTE *gpiobits[8] =
   { "GP0", "GP1", "GP2", "GP3", "GP4", "GP5", NULL, NULL };
static BYTE *stat509a[8] =
   { "C", "DC", "Z", "PD", "TO", "PA0", NULL, "GPWUF" };

struct rnames names509a[64] =
{
        /* 0x00 -- 0x0f */
   { indf_n, NULL },  { tmr0_n, NULL },  { pcl_n, NULL },   { status_n, stat509a },
   { fsr_n, NULL },   { osccal_n, NULL },{ gpio_n, gpiobits }, { NULL, NULL }/* , */
#ifdef NEVERDEF
   The automatic 0 initalization will take care of the rest of the array
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x10 -- 0x1f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x20 -- 0x2f  XLATE_REGS[] will take care of name ptrs */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
        /* 0x30 -- 0x3f */
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL },
   { NULL, NULL },    { NULL, NULL },    { NULL, NULL },    { NULL, NULL }
#endif
};



BYTE getfileknown, fileaddrknown;
BYTE regval, regvalknown;

WORD peekw(), peekb();
void pokew(), pokeb();

setcflag(addr,flag)
   {
   memoryknown[addr] |= flag;
   }

save_mem_addr(new_ip)
   WORD new_ip;
   {
   SETCFLAG(ip,PROG_ADDRKNOWN);  /* say we know what the actual address is */
   pokew(mapspace,ip+ip,new_ip);  /* memptrs[ip] = new_ip; */
   }

save_f_addr()
   {
   SETCFLAG(ip,PROG_FADDRKNOWN);  /* say we know what the actual file addr is */
   pokew(mapspace,FILEPTR+ip+ip,filenum_temp2);  /* fileptrs[ip] = filenum_temp2; */
   }

static BYTE read_regs()
   {
   WORD indf_fak_hold;
   WORD indf_fn_t2_hold;
   BYTE result,indf_flag;

   indf_flag = FALSE;
   filenum_temp2 = xlate_regs[filenum_temp];  /* lookup actual reg index */
   if (filenum_temp2 == INDF)  /* if indirect */
      {
      indf_flag = TRUE;
      indf_fak_hold = fileaddrknown;
      indf_fn_t2_hold = filenum_temp2;
      if ((regsknown[FSR] & FSR_MASK) != FSR_MASK)
         fileaddrknown = FALSE;
      else
         filenum_temp2 = xlate_regs[(WORD)regs[FSR] & FSR_MASK];
      }
   if ((!fileaddrknown)
                 || (filenum_temp2 == GPIO)   /* GPIO can't be known */
                 || (filenum_temp2 == TMR0))  /* TMR0 can't be known */
      {
      getfileknown = ALLBITS_UNKNOWN;
      if (indf_flag)
         {
         fileaddrknown = indf_fak_hold;
         filenum_temp2 = indf_fn_t2_hold;
         }
      return(0);
      }
   getfileknown = regsknown[filenum_temp2];
   result = regs[filenum_temp2];
   if (indf_flag)
      {
      fileaddrknown = indf_fak_hold;
      filenum_temp2 = indf_fn_t2_hold;
      }
   return(result);
   }

static void w_reg()
   {
   regs[filenum_temp2] = regval;
   regsknown[filenum_temp2] = regvalknown;
   }

static void w_tmr0()
   {
   regsknown[TMR0] = ALLBITS_UNKNOWN;
      /* don't know if TMR0 is turned on */
   }

static void w_status()
   {
   regs[STATUS] = (regs[STATUS] & 0x18) | (regval & 0xa7);
      /* cannot set !TO, !PD bits */
      /* bit 6 not implemented */
   regsknown[STATUS] = regvalknown & 0xa7;
   }

static void w_pcl()
   {
   WORD new_ip;

   regs[PCL] = regval;
   regsknown[PCL] = regvalknown;
   SETCFLAG(ip,PROG_INDIRECT);  /* indirect reference to program memory */
   if ((regvalknown == ALLBITS_KNOWN) && (regsknown[STATUS] & STATUS_PA0))
                    /* if we know where we're going! */
      {
      new_ip = ((WORD)(regs[STATUS] & STATUS_PA0) << STATUS_PA0_SHIFT) + (WORD)regs[PCL];
         /* note that bit 8 is implicitly cleared */
      SETCFLAG(new_ip,PROG_LABEL);
      save_mem_addr(new_ip);
      }
   find_new_thread();
   }

static void w_osccal()
   {
   regs[OSCCAL] = regval & 0xfc;  /* high 6 bits only */
   regsknown[OSCCAL] = regvalknown & 0xfc;
   }

static void w_gpio()
   {
   regsknown[GPIO] = ALLBITS_UNKNOWN;
   }

static w_fsr()
   {
   regs[FSR] = RESET_FSR | regval;  /* upper bits are always 1 */
   regsknown[FSR] = RESET_FSR | regvalknown;
   }

static void w_none()
   {
   }

/*
 *  Note:  There is no way to reach the functions which are mapped to another
 *         bank via the xlate_regs[] array.  They are there as placeholders.
 */
static void (*writeregs[64])() =
   {
      /* BANK 0 */
   /* 00     01      02     03        04     05        06      07 */
   w_none, w_tmr0, w_pcl, w_status, w_fsr, w_osccal, w_gpio, w_reg,
   /* 08    09     0a     0b     0c     0d     0e     0f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 10    11     12     13     14     15     16     17 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 18    19     1a     1b     1c     1d     1e     1f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
      /* BANK 1 */
   /* 20     21      22     23        24     25        26      27 */
   w_none, w_tmr0, w_pcl, w_status, w_fsr, w_osccal, w_gpio, w_reg,
   /* 28    29     2a     2b     2c     2d     2e     2f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 30     31     32     33     34     35     36     37 */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg,
   /* 38     39     3a     3b     3c     3d     3e     3f */
   w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg, w_reg
   };

static void write_regs()
   {
   WORD indf_fak_hold;
   WORD indf_fn_t2_hold;
   BYTE result,indf_flag;

   indf_flag = FALSE;
   filenum_temp2 = xlate_regs[filenum_temp];  /* lookup actual reg index */
   if (filenum_temp2 == INDF)  /* if indirect */
      {
      indf_flag = TRUE;
      indf_fak_hold = fileaddrknown;
      indf_fn_t2_hold = filenum_temp2;
      if ((regsknown[FSR] & FSR_MASK) != FSR_MASK)
         fileaddrknown = FALSE;
      else
         filenum_temp2 = xlate_regs[(WORD)regs[FSR] & FSR_MASK];
      }
   if (fileaddrknown)
      (*writeregs[filenum_temp2])();
   if (indf_flag)
      {
      fileaddrknown = indf_fak_hold;
      filenum_temp2 = indf_fn_t2_hold;
      }
   }

static BYTE getfile()  /* assumes filenum contains index into register file */
   {
   WORD i, pageflag;

   getfileknown = ALLBITS_UNKNOWN;
   fileaddrknown = FALSE;
   if (regsknown[FSR] & FSR_MEMORYPAGE_BITMASK)  /* if we know what memorypage this is */
      {
      filenum_temp = (regs[FSR] & FSR_MEMORYPAGE_BITMASK) + filenum;
      fileaddrknown = TRUE;
      return(read_regs());  /* getfileknown updated as needed */
      }
   pageflag = TRUE;  /* default: page does not matter */
   for (i = filenum; i < ram_size[pictype]; i += regindex_mask[pictype] + 1)
      if (xlate_regs[filenum] != xlate_regs[i])
         {
         pageflag = FALSE;
         break;
         }
   if (pageflag)  /* if the page doesn't matter */
      {
      filenum_temp = filenum;
      fileaddrknown = TRUE;
      return(read_regs());  /* getfileknown updated as needed */
      }
   return(0);
   }

/*
WORD doing_bcf;
*/
static void setfile(val) /* assumes filenum contains index into register file */
   WORD val;
   {
   WORD i, pageflag;

   fileaddrknown = FALSE;
   regval = val;  /* set global for easy access */
/*
if (doing_bcf)
   printf("rk[FSR]=%02x (&%02x=%02x)\n",regsknown[FSR],FSR_MEMORYPAGE_BITMASK,
         regsknown[FSR]&FSR_MEMORYPAGE_BITMASK);
*/
   if (regsknown[FSR] & FSR_MEMORYPAGE_BITMASK)  /* if we know what memorypage this is */
      {
      filenum_temp = (regs[FSR] & FSR_MEMORYPAGE_BITMASK) + filenum;
      fileaddrknown = TRUE;
      write_regs();
      }
   else
     {
/*
if (doing_bcf)
   printf("Checking pages...\n");
*/
      pageflag = TRUE;  /* default: page does not matter */
      for (i = filenum; i < ram_size[pictype]; i += regindex_mask[pictype] + 1)
         if (xlate_regs[filenum] != xlate_regs[i])
            {
/*
if (doing_bcf)
   printf("xlate mismatch:  filenum=%02x  i=%02x  xl_r[f]=%02x  xl_r[i]=%02x\n",
      filenum,i,xlate_regs[filenum],xlate_regs[i]);
*/
            pageflag = FALSE;
            break;
            }
      if (pageflag)  /* if the page doesn't matter */
         {
         fileaddrknown = TRUE;  /* don't confuse write_regs() */
         filenum_temp = filenum;
         write_regs();
         fileaddrknown = FALSE;  /* we really don't know the correct address */
         }
      }
   }

ks_push(addr)
   WORD addr;
   {
   if (knownstackptr < KS_MAXSTACK)
      {
      PUSH_KS_BYTE(KS_W,w);
      PUSH_KS_BYTE(KS_WKNOWN,wknown);
      PUSH_KS_BYTE(KS_STATUS,regs[STATUS]);
      PUSH_KS_BYTE(KS_STATKNOWN,regsknown[STATUS]);
      PUSH_KS_BYTE(KS_FSR,regs[FSR]);
      PUSH_KS_BYTE(KS_FSRKNOWN,regsknown[FSR]);
      PUSH_KS_BYTE(KS_PCLATH,regs[PCLATH]);
      PUSH_KS_BYTE(KS_PCLATHKNOWN,regsknown[PCLATH]);
             /* doesn't matter if this is a 12-bit PIC core, they will be
              * discarded on a POP
              */
      PUSH_KS_WORD(KS_ADDR,addr);
      knownstackptr += KS_ENTRY;
      }
   }


void calcflags_add(first,second,result)
   WORD first, second, result;
   {
   statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get current STATUS flags */
   if (result)
      statushold &= ~STATUS_Z;
   else
      statushold |= STATUS_Z;
   if (((first & 0x0f) + (second & 0x0f)) & 0xf0)  /* if Aux Carry */
      statushold |= STATUS_DC;
   else
      statushold &= ~STATUS_DC;
   if ((first+second) & 0xff00)  /* if Carry */
      statushold |= STATUS_C;
   else
      statushold &= ~STATUS_C;
   }

void calcflags_sub(first,second,result)
   WORD first, second, result;
   {
   statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get current STATUS flags */
   if (result)
      statushold &= ~STATUS_Z;
   else
      statushold |= STATUS_Z;
   if (((first & 0x0f) - (second & 0x0f)) & 0xf0)  /* if Aux Carry */
      statushold &= ~STATUS_DC;
   else
      statushold |= STATUS_DC;
   if ((first-second) & 0xff00)  /* if Carry */
      statushold &= ~STATUS_C;
   else
      statushold |= STATUS_C;
   }

static void controls_12bit()
      /* 12bit:    000000 xx xxxx = NOP/OPTION/SLEEP/CLRWDT/TRIS/MOVWF
       * filenum = ...... .f ffff
       * dest    = ...... d. ....
       * NOP     = 000000 00 0000
       * OPTION  = 000000 00 0010
       * SLEEP   = 000000 00 0011
       * CLRWDT  = 000000 00 0100
       * TRIS    = 000000 00 0110  <actually, 000000 00 0fff, but only fff=6 valid>
       * MOVWF   = 000000 1f ffff
       *   <unused opcodes will default to NOP>
       */
   {
   BYTE last_option, alignment;

   if (dest)  /* if dest set, this must be MOVWF */
      {
      regvalknown = wknown;
      setfile(w);
      if (fileaddrknown)
         save_f_addr();
      }
   else
      {
      switch (filenum)
         {
         case 2:  /* OPTION */
            break;
         case 3:  /* SLEEP */
            find_new_thread();  /* wakup does a chip reset */
            break;
         case 4:  /* CLRWDT */
            break;
         case 6:  /* TRIS */
            break;
         }
      }  /* if (dest) ... else */
   }

static void clr_12bit()
      /* CLRW / CLRF = 000001 xx xxxx = CLRW / CLRF
       * filenum     = ...... .x xxxx
       * dest        = ...... x. ....
       * CLRW        = 000001 00 0000 <actually, 000001 0x xxxx>
       * CLRF        = 000001 1f ffff
       */
   {
   statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
   statusknownhold = regsknown[STATUS] & STATUS_FLAGBITS;
   if (!dest)  /* if W is destination */
      {
      w = 0;  /* clear w */
      wknown = ALLBITS_KNOWN;
      }
   else
      {
      regvalknown = ALLBITS_KNOWN;
      setfile(0);  /* set "filenum" to 0, set Z */
      if (fileaddrknown)
         save_f_addr();
      }
   regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
   regsknown[STATUS] = (regsknown[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statusknownhold;  /* we know that Z is set */
   }

static void subwf()            /* 000010 df ffff = SUBWF */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   temp2 = temp1 - w;
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      calcflags_sub(temp1,w,temp2);
      regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | statushold;
      regsknown[STATUS] |= STATUS_FLAGBITS;  /* we know the flagbits */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_FLAGBITS;  /* we do not know the flagbits */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void decf()             /* 000011 df ffff = DECF */
   {
   temp2 = getfile() - 1;
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void iorwf()            /* 000100 df ffff = IORWF */
   {
   temp2 = getfile() | w;
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void andwf()            /* 000101 df ffff = ANDWF */
   {
   temp2 = getfile() & w;
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void xorwf()            /* 000110 df ffff = XORWF */
   {
   temp2 = getfile() ^ w;
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void addwf()            /* 000111 df ffff = ADDWF */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   temp2 = temp1 + w;
   if ((getfileknown == ALLBITS_KNOWN) && (wknown == ALLBITS_KNOWN))
      {
      calcflags_add(temp1,w,temp2);
      regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | statushold;
      regsknown[STATUS] |= STATUS_FLAGBITS;  /* we know the flagbits */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_FLAGBITS;  /* we do not know the flagbits */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void movf()             /* 001000 df ffff = MOVF */
   {
   temp2 = getfile();
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void comf()             /* 001001 df ffff = COMF */
   {
   temp2 = ~getfile();
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void incf()             /* 001010 df ffff = INCF */
   {
   temp2 = getfile() + 1;
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (temp2)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z flag */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_Z;  /* don't know Z flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void decfsz()           /* 001011 df ffff = DECFSZ */
   {
   temp2 = getfile() - 1;
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      temp1 = ALLBITS_UNKNOWN;
      }
   skip_find_new_thread = SKIP_VAL;  /* setup for SKIP */
/*
printf("\nDECFSZ: skip_find_new_thread = %d\n",skip_find_new_thread);
*/
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void rrf()              /* 001100 df ffff = RRF */
   {
   temp1 = getfile();  /* get value to rotate */
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (regsknown[STATUS] & STATUS_C))
      {
      temp2 = temp1 >> 1;  /* start of rotation */
      if ((statushold=regs[STATUS] & STATUS_FLAGBITS) & STATUS_C)  /* get flag values and check C */
         temp2 |= BIT7;  /* if C, put it in highbit of result */
      if (temp1 & 1)  /* set C out of lowbit */
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_C | statushold;
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_C & statushold);
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_C;  /* don't know C flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void rlf()              /* 001101 df ffff = RLF */
   {
   temp1 = getfile();  /* get value to rotate */
   if (fileaddrknown)
      save_f_addr();
   if ((getfileknown == ALLBITS_KNOWN) && (regsknown[STATUS] & STATUS_C))
      {
      temp2 = temp1 << 1;  /* start of rotation */
      if ((statushold=regs[STATUS] & STATUS_FLAGBITS) & STATUS_C)  /* get flag values and check C */
         temp2 |= BIT0;  /* if C, put it in lowbit of result */
      if (temp1 & BIT7)  /* set C out of highbit */
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_C | statushold;
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_C & statushold);
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      regsknown[STATUS] &= ~STATUS_C;  /* don't know C flag */
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void swapf()            /* 001110 df ffff = SWAPF */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      temp2 = (temp1 >> 4) + (temp1 << 4);  /* swap nibbles */
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      temp1 = ALLBITS_UNKNOWN;
      }
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void incfsz()           /* 001111 df ffff = INCFSZ */
   {
   temp2 = getfile() + 1;
   if (fileaddrknown)
      save_f_addr();
   if (getfileknown == ALLBITS_KNOWN)
      {
      temp1 = ALLBITS_KNOWN;
      }
   else
      {
      temp1 = ALLBITS_UNKNOWN;
      }
   skip_find_new_thread = SKIP_VAL;  /* setup for SKIP */
/*
printf("\nINCFSZ: skip_find_new_thread = %d\n",skip_find_new_thread);
*/
   if (!dest)  /* if W is destination */
      {
      wknown = temp1;
      w = temp2;
      }
   else
      {
      regvalknown = temp1;
      setfile(temp2);  /* best attempt at setting appropriate regsknown[] */
      }
   }

static void bcf()              /* 0100bb bf ffff = BCF <00b> */
   {
   WORD bitnum;

   bitnum = (opcode & BITNUM_MASK) >> BITNUM_POSITION;
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   regvalknown = getfileknown | bittable[bitnum];  /* we know what this bit is */
/*
printf("\nBCF() fk=%d  rvknown=%02x  val=%02x  f=%02x  f_temp=%02x  f_temp2=%02x rk[3]=%02x\n",
   fileaddrknown,regvalknown,temp1&~bittable[bitnum],filenum,filenum_temp,filenum_temp2,regsknown[STATUS]);
doing_bcf = TRUE;
*/
   setfile(temp1 & ~bittable[bitnum]);
/*
doing_bcf = FALSE;
printf("  fk=%d  rvknown=%02x  val=%02x  f=%02x  f_temp=%02x  f_temp2=%02x rk[3]=%02x\n",
   fileaddrknown,regvalknown,temp1&~bittable[bitnum],filenum,filenum_temp,filenum_temp2,regsknown[STATUS]);
ci();
*/
   }

static void bsf()              /* 0100bb bf ffff = BSF <00b> */
   {
   WORD bitnum;

   bitnum = (opcode & BITNUM_MASK) >> BITNUM_POSITION;
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   regvalknown = getfileknown | bittable[bitnum];  /* we know what this bit is */
   setfile(temp1 | bittable[bitnum]);
   }

static void btfsc()            /* 0110bb bf ffff = BTFSC <00b> */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   skip_find_new_thread = SKIP_VAL;  /* setup for SKIP */
/*
printf("\nBTFSC: skip_find_new_thread = %d\n",skip_find_new_thread);
*/
   }

static void btfss()            /* 0111bb bf ffff = BTFSS <00b> */
   {
   temp1 = getfile();
   if (fileaddrknown)
      save_f_addr();
   skip_find_new_thread = SKIP_VAL;  /* setup for SKIP */
/*
printf("\nBTFSS: skip_find_new_thread = %d\n",skip_find_new_thread);
*/
   }

static void retlw()            /* 1000kk kk kkkk = RETLW <kkkk kkkk> */
   {
   find_new_thread();
   }

static void call_12bit()       /* 1001kk kk kkkk = CALL <kkkk kkkk> */
   {
   WORD new_ip;

/*
printf("\ncall:  regsknown[STATUS] = %02x & %02x = %02x  skip_find_new_thread=%d\n",
regsknown[STATUS],STATUS_PA0,regsknown[STATUS]&STATUS_PA0,skip_find_new_thread);
*/
   if (regsknown[STATUS] & STATUS_PA0)  /* if we know our destination */
      {
      new_ip = ((WORD)(regs[STATUS] & STATUS_PA0) << STATUS_PA0_SHIFT) + (opcode & CALL_MASK_12BIT);
         /* note that bit 8 is implicitly cleared */
      SETCFLAG(new_ip,PROG_LABEL);
      save_mem_addr(new_ip);
/*
printf("new_ip = %04x   flags[new_ip]=%02x  flags[ip]=%02x  memptrs[ip]=%04x\n",
   new_ip,memoryknown[new_ip],memoryknown[ip],peekw(mapspace,ip+ip));
*/
      if (!(memoryknown[new_ip] & PROG_KNOWN))  /* if not mapped already */
         {
         next_ip = new_ip;  /* start mapping there, WITHOUT FORGETTING REGS! */
         skip_label_regs_unknown = SKIP_VAL;
         ks_push((ip+1)&(memory_size[pictype]-1));
         }
      }
   else
      regs_unknown();  /* anything could happen here */
/*
printf("\rcall: R_U\n");
*/
   }

static void go_to_12bit()      /* 101kkk kk kkkk = GOTO <k kkkk kkkk> */
   {
   WORD new_ip;

/*
printf("\ngoto:  regsknown[STATUS] = %02x & %02x = %02x  skip_find_new_thread=%d\n",
regsknown[STATUS],STATUS_PA0,regsknown[STATUS]&STATUS_PA0,skip_find_new_thread);
*/
   if (regsknown[STATUS] & STATUS_PA0)  /* if we know our destination */
      {
      new_ip = ((WORD)(regs[STATUS] & STATUS_PA0) << STATUS_PA0_SHIFT) + (opcode & GOTO_MASK_12BIT);
      SETCFLAG(new_ip,PROG_LABEL);
         /* all IP bits are accounted for */
      save_mem_addr(new_ip);
/*
printf("new_ip = %04x   flags[new_ip]=%02x  flags[ip]=%02x  memptrs[ip]=%04x\n",
   new_ip,memoryknown[new_ip],memoryknown[ip],peekw(mapspace,ip+ip));
*/
      if (!(memoryknown[new_ip] & PROG_KNOWN))  /* if not mapped already */
         {
         next_ip = new_ip;  /* start mapping there, WITHOUT FORGETTING REGS! */
         skip_label_regs_unknown = SKIP_VAL;
         if (skip_find_new_thread)  /* if could be skipped or not */
            ks_push((ip+1)&(memory_size[pictype]-1));
         }
      else
         if (skip_find_new_thread == 0)
            find_new_thread();
      }
   else
      if (skip_find_new_thread == 0)
         find_new_thread();
   }

static void movlw()            /* 1100kk kk kkkk = MOVLW <kkkk kkkk> */
   {
   w = opcode;  /* since W is a BYTE, we just get the low 8 bits */
   wknown = ALLBITS_KNOWN;
   }

static void iorlw()            /* 1101kk kk kkkk = IORLW <kkkk kkkk> */
   {
   w |= opcode;  /* since W is a BYTE, we just use the low 8 bits of opcode */
   if ((opcode & 0xff) == 0xff)  /* if setting ALL bits in w */
      wknown = ALLBITS_KNOWN;
   if (wknown == ALLBITS_KNOWN)
      {
      if (w)
         regs[STATUS] &= ~STATUS_Z;
      else
         regs[STATUS] |= STATUS_Z;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z status */
      }
   else
      regsknown[STATUS] &= ~STATUS_Z;  /* we don't know the Z status */
   }

static void andlw()            /* 1110kk kk kkkk = ANDLW <kkkk kkkk> */
   {
   w &= opcode;  /* since W is a BYTE, we just use the low 8 bits of opcode */
   if ((opcode & 0xff) == 0x00)  /* if clearing ALL bits in w */
      wknown = ALLBITS_KNOWN;
   if (wknown == ALLBITS_KNOWN)
      {
      if (w)
         regs[STATUS] &= ~STATUS_Z;
      else
         regs[STATUS] |= STATUS_Z;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z status */
      }
   else
      regsknown[STATUS] &= ~STATUS_Z;  /* we don't know the Z status */
   }

static void xorlw()            /* 1111kk kk kkkk = XORLW <kkkk kkkk> */
   {
   w ^= opcode;  /* since W is a BYTE, we just use the low 8 bits of opcode */
   if (wknown == ALLBITS_KNOWN)
      {
      if (w)
         regs[STATUS] &= ~STATUS_Z;
      else
         regs[STATUS] |= STATUS_Z;
      regsknown[STATUS] |= STATUS_Z;  /* we know the Z status */
      }
   else
      regsknown[STATUS] &= ~STATUS_Z;  /* we don't know the Z status */
   }

static void nop()              /* 000000 00 0000 or 000000 0000 0000 or 111011 xxxx xxxx */
   {
   }

BYTE ascii_hex(val)
   WORD val;
   {
   val &= 0x0f;
   if (val > 9)
      return(val + 0x37);
   return(val + 0x30);
   }

void add_tab()
    /* NOTE: I'm going to cheat here.  Since temp1 always contains the
     *       string length (ofs to EOS), I'm going to update that rather
     *       than passing a pointer to the length.
     */
   {
   temp1 = strlen(instr_str);  /* get EOS */
   do
      {
      instr_str[temp1++] = ' ';
      } while (temp1 & 7);
   instr_str[temp1] = '\0';  /* properly terminate string */
   }

void tabout(col)
   WORD col;
    /* NOTE: I'm going to cheat here.  Since temp1 always contains the
     *       string length (ofs to EOS), I'm going to update that rather
     *       than passing a pointer to the length.
     */
   {
   temp1 = strlen(instr_str);  /* get EOS */
   do
      {
      instr_str[temp1++] = ' ';
      } while (temp1 < col);
   instr_str[temp1] = '\0';  /* properly terminate string */
   }

static void add_user_regname(addr)
   WORD addr;
   {
   WORD i, j;

   if (memoryknown[ip] & PROG_FADDRKNOWN)
      {
      for (i = 0; i < num_syms; i += SYMTAB_ENTRY)
         {
         if ((peekb(sym_seg,i+SYMTAB_FLAGBYTE_OFS) == DATA_SYMBOL)
                && (peekw(sym_seg,i+SYMTAB_VALUE_OFS) == addr))
            {
            for (j = 0; j < SYMTAB_NAMESIZE; j++)
               instr_str[temp1+j] = peekb(sym_seg,i+j);
            sprintf(&instr_str[strlen(instr_str)]," & 0x%02x",regindex_mask[pictype]);
            if (hex_equivalent_of_named_regs)
               {
               tabout(48);
               sprintf(&instr_str[temp1],";0x%02x",filenum);
               }
            return;
            }
         }
      }
   sprintf(&instr_str[temp1],"0x%02x",filenum);
   }

static WORD add_user_regname_w(addr)
   WORD addr;
   {
   WORD i, j;

   if (memoryknown[ip] & PROG_FADDRKNOWN)
      {
      for (i = 0; i < num_syms; i += SYMTAB_ENTRY)
         {
         if ((peekb(sym_seg,i+SYMTAB_FLAGBYTE_OFS) == DATA_SYMBOL)
                && (peekw(sym_seg,i+SYMTAB_VALUE_OFS) == addr))
            {
            for (j = 0; j < SYMTAB_NAMESIZE; j++)
               instr_str[temp1+j] = peekb(sym_seg,i+j);
            sprintf(&instr_str[strlen(instr_str)]," & 0x%02x",regindex_mask[pictype]);
            return(TRUE);
            }
         }
      }
   sprintf(&instr_str[temp1],"0x%02x",filenum);
   return(FALSE);
   }

void add_regname()
   {
   WORD addr;

   add_tab();
   addr = peekw(mapspace,FILEPTR+ip+ip);  /* fileptrs[ip] */
/*
if ((ip == 0) || (ip == 2))
   {
   printf("filenum=%02x  addr=%04x  mk[%d]=%02x (&%02x=%02x)  rn[%d][%d].rname=%04x\n",
      filenum,addr,ip,memoryknown[ip],PROG_FADDRKNOWN,memoryknown[ip]&PROG_FADDRKNOWN,
      pictype,addr,regnames[pictype][addr].rname);
   ci();
   }
*/
   if ((memoryknown[ip] & PROG_FADDRKNOWN) && (regnames[pictype][addr].rname))
                   /* if a name exists */
      {
      sprintf(&instr_str[temp1],"%s",regnames[pictype][addr].rname);
      if (addr > regindex_mask[pictype])
         sprintf(&instr_str[strlen(instr_str)]," & 0x%02x",regindex_mask[pictype]);
      if (hex_equivalent_of_named_regs)
         {
         tabout(48);
         sprintf(&instr_str[temp1],";0x%02x",filenum);
         }
      }
   else
      add_user_regname(addr);
   add_indirect_label(ip);
   }

void add_regname_w()
   {
   WORD addr, flag;

   flag = FALSE;
   add_tab();
   addr = peekw(mapspace,FILEPTR+ip+ip);  /* fileptrs[ip] */
   if ((memoryknown[ip] & PROG_FADDRKNOWN) && (regnames[pictype][addr].rname))
                   /* if a name exists */
      {
      sprintf(&instr_str[temp1],"%s",regnames[pictype][addr].rname);
      if (addr > regindex_mask[pictype])
         sprintf(&instr_str[strlen(instr_str)]," & 0x%02x",regindex_mask[pictype]);
      }
   else
      flag = add_user_regname_w(addr);
   sprintf(&instr_str[strlen(instr_str)],",%c",dest ? 'F' : 'W');
   if ((memoryknown[ip] & PROG_FADDRKNOWN)
             && ((regnames[pictype][addr].rname) || (flag))
             && (hex_equivalent_of_named_regs))
      {
      tabout(48);
      sprintf(&instr_str[temp1],";0x%02x",filenum);
      }
   add_indirect_label(ip);
   }

static void add_regname_b()
   {
   WORD addr, bitnum, flag;

   flag = FALSE;
   add_tab();
   addr = peekw(mapspace,FILEPTR+ip+ip);  /* fileptrs[ip] */
   if ((memoryknown[ip] & PROG_FADDRKNOWN) && (regnames[pictype][addr].rname))
                   /* if a name exists */
      {
      sprintf(&instr_str[temp1],"%s",regnames[pictype][addr].rname);
      if (addr > regindex_mask[pictype])
         sprintf(&instr_str[strlen(instr_str)]," & 0x%02x",regindex_mask[pictype]);
      }
   else
      flag = add_user_regname_w(addr);
   temp1 = strlen(instr_str);  /* get EOS */
   bitnum = (opcode & BITNUM_MASK) >> BITNUM_POSITION;
   if ((memoryknown[ip] & PROG_FADDRKNOWN)
               && (regnames[pictype][addr].bitnames)
               && (regnames[pictype][addr].bitnames[bitnum]))
      sprintf(&instr_str[temp1],",%s",regnames[pictype][addr].bitnames[bitnum]);
   else
      sprintf(&instr_str[temp1],",%d",bitnum);
   if ((memoryknown[ip] & PROG_FADDRKNOWN)
              && ((regnames[pictype][addr].rname) || (flag))
              && (hex_equivalent_of_named_regs))
      {
      tabout(48);
      sprintf(&instr_str[temp1],";0x%02x,%d",filenum,bitnum);
      }
   add_indirect_label(ip);
   }

add_opcode_8bitconst()  /* add "\t<kkkk kkkk>" */
   {
   add_tab();
   sprintf(&instr_str[temp1],"0x%02x",opcode & 0xff);
   }

WORD get_label_str(ip)  /* instr_str[temp1] is where to place label */
   WORD ip;
   {
   WORD i, j;

   for (i = 0; i < num_syms; i += SYMTAB_ENTRY)
      if ((peekb(sym_seg,i+SYMTAB_FLAGBYTE_OFS) == CODE_SYMBOL)
                && (peekw(sym_seg,i+SYMTAB_VALUE_OFS) == ip))
         {
         for (j = 0; j < SYMTAB_NAMESIZE; j++)
            instr_str[temp1+j] = peekb(sym_seg,i+j);
         temp1 = strlen(instr_str);
         return(TRUE);
         }
   sprintf(&instr_str[temp1],"H_%04x",ip);
   return(FALSE);
   }

add_indirect_label(ip)  /* instr_str[temp1] is where to place label */
   WORD ip;
   {
   WORD i, j, addr;

   if (memoryknown[ip] & PROG_INDIRECT)
      {
      tabout(56);
      instr_str[temp1++] = ';';
      if (memoryknown[ip] & PROG_ADDRKNOWN)
         get_label_str(peekw(mapspace,ip+ip));
      else
         sprintf(&instr_str[temp1],"GOTO xxxx");
      }
   }

static add_opcode_8bitaddr()  /* add "\t<kkkk kkkk>" */
   {
   WORD addr, flag;

   add_tab();
   if (memoryknown[ip] & PROG_ADDRKNOWN)
      {
      flag = get_label_str(addr = peekw(mapspace,ip+ip));  /* peekw() == memptrs[ip] */
      if ((addr > 0xff) || (flag))
         {
         strcat(instr_str," & 0xff");
         tabout(48);
         sprintf(&instr_str[temp1],";0x%02x",opcode & 0xff);
         }
      }
   else
      sprintf(&instr_str[temp1],"%02x",opcode & 0xff);
   }

static add_opcode_9bitaddr()  /* add "\t<k kkkk kkkk>" */
   {
   WORD addr, flag;

   add_tab();
   if (memoryknown[ip] & PROG_ADDRKNOWN)
      {
      flag = get_label_str(addr = peekw(mapspace,ip+ip));  /* peekw() == memptrs[ip] */
      if ((addr > 0x1ff) || (flag))
         {
         strcat(instr_str," & 0x1ff");
         tabout(48);
         sprintf(&instr_str[temp1],";0x%03x",opcode & 0x1ff);
         }
      }
   else
      sprintf(&instr_str[temp1],"%03x",opcode & 0x1ff);
   }

static void disasm_controls_12bit()
      /* 12bit:    000000 xx xxxx = NOP/OPTION/SLEEP/CLRWDT/TRIS/MOVWF
       * filenum = ...... .x xxxx
       * dest    = ...... x. ....
       * NOP     = 000000 00 0000
       * OPTION  = 000000 00 0010
       * SLEEP   = 000000 00 0011
       * CLRWDT  = 000000 00 0100
       * TRIS    = 000000 00 0110  <actually, 000000 00 0fff, but only fff=6 valid>
       * MOVWF   = 000000 1f ffff
       *   <unused opcodes will default to NOP>
       */
   {
   if (dest)  /* if dest set, this must be MOVWF */
      {
      strcat(instr_str,"MOVWF");
      add_regname();  /* add \t<regname>" */
      }
   else
      {
      switch (filenum)
         {
         case 0:  /* NOP */
            strcat(instr_str,"NOP");
            break;
         case 2:  /* OPTION */
            strcat(instr_str,"OPTION");
            break;
         case 3:  /* SLEEP */
            strcat(instr_str,"SLEEP");
            break;
         case 4:  /* CLRWDT */
            strcat(instr_str,"CLRWDT");
            break;
         case 6:  /* TRIS */
            strcat(instr_str,"TRIS");
/*            add_regname(); */  /* add \t<regname>" */
            break;
         default:
            strcat(instr_str,"NOPU");  /* Undefined opcode NOP */
            break;
         }
      }  /* if (dest) ... else */
   }

static void disasm_clr_12bit()
      /* CLRW / CLRF = 000001 xx xxxx = CLRW / CLRF
       * filenum     = ...... .x xxxx
       * dest        = ...... x. ....
       * CLRW        = 000001 00 0000 <actually, 000001 0x xxxx
       * CLRF        = 000001 1f ffff
       */
   {
   if (!dest)  /* if W is destination */
      strcat(instr_str,"CLRW");
   else
      {
      strcat(instr_str,"CLRF");
      add_regname();  /* add \t<regname>" */
      }
   }

static void disasm_subwf()            /* 000010 df ffff = SUBWF */
   {
   strcat(instr_str,"SUBWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_decf()             /* 000011 df ffff = DECF */
   {
   strcat(instr_str,"DECF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_iorwf()            /* 000100 df ffff = IORWF */
   {
   strcat(instr_str,"IORWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_andwf()            /* 000101 df ffff = ANDWF */
   {
   strcat(instr_str,"ANDWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_xorwf()            /* 000110 df ffff = XORWF */
   {
   strcat(instr_str,"XORWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_addwf()            /* 000111 df ffff = ADDWF */
   {
   strcat(instr_str,"ADDWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_movf()             /* 001000 df ffff = MOVF */
   {
   strcat(instr_str,"MOVF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_comf()             /* 001001 df ffff = COMF */
   {
   strcat(instr_str,"COMF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_incf()             /* 001010 df ffff = INCF */
   {
   strcat(instr_str,"INCF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_decfsz()           /* 001011 df ffff = DECFSZ */
   {
   strcat(instr_str,"DECFSZ");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_rrf()              /* 001100 df ffff = RRF */
   {
   strcat(instr_str,"RRF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_rlf()              /* 001101 df ffff = RLF */
   {
   strcat(instr_str,"RLF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_swapf()            /* 001110 df ffff = SWAPF */
   {
   strcat(instr_str,"SWAPF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_incfsz()           /* 001111 df ffff = INCFSZ */
   {
   strcat(instr_str,"INCFSZ");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

static void disasm_bcf()              /* 0100bb bf ffff = BCF <00b> */
   {
   strcat(instr_str,"BCF");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

static void disasm_bsf()              /* 0100bb bf ffff = BSF <00b> */
   {
   strcat(instr_str,"BSF");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

static void disasm_btfsc()            /* 0110bb bf ffff = BTFSC <00b> */
   {
   strcat(instr_str,"BTFSC");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

static void disasm_btfss()            /* 0111bb bf ffff = BTFSS <00b> */
   {
   strcat(instr_str,"BTFSS");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

static void disasm_retlw()            /* 1000kk kk kkkk = RETLW <kkkk kkkk> */
   {
   strcat(instr_str,"RETLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   if (((opcode & 0xff) > ' ') && ((opcode & 0xff) < 0x80))
      {
      add_tab();
      sprintf(&instr_str[temp1],";%c",opcode & 0xff);
      }
   }

static void disasm_call_12bit()       /* 1001kk kk kkkk = CALL <kkkk kkkk> */
   {
   strcat(instr_str,"CALL");
   add_opcode_8bitaddr();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_go_to_12bit()      /* 101kkk kk kkkk = GOTO <k kkkk kkkk> */
   {
   strcat(instr_str,"GOTO");
   add_opcode_9bitaddr();  /* add "\t<k kkkk kkkk>" */
   }

static void disasm_movlw()            /* 1100kk kk kkkk = MOVLW <kkkk kkkk> */
   {
   strcat(instr_str,"MOVLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_iorlw()            /* 1101kk kk kkkk = IORLW <kkkk kkkk> */
   {
   strcat(instr_str,"IORLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_andlw()            /* 1110kk kk kkkk = ANDLW <kkkk kkkk> */
   {
   strcat(instr_str,"ANDLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

static void disasm_xorlw()            /* 1111kk kk kkkk = XORLW <kkkk kkkk> */
   {
   strcat(instr_str,"XORLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

void (*picops12[1 << PIC_DECODE_BITS])() =
   {
   controls_12bit,   /* 000000 xx xxxx = NOP/OPTION/SLEEP/CLRWDT/TRIS/MOVWF */
   clr_12bit,        /* 000001 xx xxxx = CLRW / CLRF */
   subwf,            /* 000010 df ffff = SUBWF */
   decf,             /* 000011 df ffff = DECF */
   iorwf,            /* 000100 df ffff = IORWF */
   andwf,            /* 000101 df ffff = ANDWF */
   xorwf,            /* 000110 df ffff = XORWF */
   addwf,            /* 000111 df ffff = ADDWF */
   movf,             /* 001000 df ffff = MOVF */
   comf,             /* 001001 df ffff = COMF */
   incf,             /* 001010 df ffff = INCF */
   decfsz,           /* 001011 df ffff = DECFSZ */
   rrf,              /* 001100 df ffff = RRF */
   rlf,              /* 001101 df ffff = RLF */
   swapf,            /* 001110 df ffff = SWAPF */
   incfsz,           /* 001111 df ffff = INCFSZ */
   bcf,              /* 010000 bf ffff (0100bb bf ffff) = BCF <00b> */
   bcf,              /* 010001 bf ffff (0100bb bf ffff) = BCF <01b> */
   bcf,              /* 010010 bf ffff (0100bb bf ffff) = BCF <10b> */
   bcf,              /* 010011 bf ffff (0100bb bf ffff) = BCF <11b> */
   bsf,              /* 010100 bf ffff (0101bb bf ffff) = BSF <00b> */
   bsf,              /* 010101 bf ffff (0101bb bf ffff) = BSF <01b> */
   bsf,              /* 010110 bf ffff (0101bb bf ffff) = BSF <10b> */
   bsf,              /* 010111 bf ffff (0101bb bf ffff) = BSF <11b> */
   btfsc,            /* 011000 bf ffff (0110bb bf ffff) = BTFSC <00b> */
   btfsc,            /* 011001 bf ffff (0110bb bf ffff) = BTFSC <01b> */
   btfsc,            /* 011010 bf ffff (0110bb bf ffff) = BTFSC <10b> */
   btfsc,            /* 011011 bf ffff (0110bb bf ffff) = BTFSC <11b> */
   btfss,            /* 011100 bf ffff (0111bb bf ffff) = BTFSS <00b> */
   btfss,            /* 011101 bf ffff (0111bb bf ffff) = BTFSS <01b> */
   btfss,            /* 011110 bf ffff (0111bb bf ffff) = BTFSS <10b> */
   btfss,            /* 011111 bf ffff (0111bb bf ffff) = BTFSS <11b> */
   retlw,            /* 100000 kk kkkk (1000kk kk kkkk) = RETLW <00kk kkkk> */
   retlw,            /* 100001 kk kkkk (1000kk kk kkkk) = RETLW <01kk kkkk> */
   retlw,            /* 100010 kk kkkk (1000kk kk kkkk) = RETLW <10kk kkkk> */
   retlw,            /* 100011 kk kkkk (1000kk kk kkkk) = RETLW <11kk kkkk> */
   call_12bit,       /* 100100 kk kkkk (1001kk kk kkkk) = CALL <00kk kkkk> */
   call_12bit,       /* 100101 kk kkkk (1001kk kk kkkk) = CALL <01kk kkkk> */
   call_12bit,       /* 100110 kk kkkk (1001kk kk kkkk) = CALL <10kk kkkk> */
   call_12bit        /* 100111 kk kkkk (1001kk kk kkkk) = CALL <11kk kkkk> */
   go_to_12bit,      /* 101000 kk kkkk (101kkk kk kkkk) = GOTO <0 00kk kkkk> */
   go_to_12bit,      /* 101001 kk kkkk (101kkk kk kkkk) = GOTO <0 01kk kkkk> */
   go_to_12bit,      /* 101010 kk kkkk (101kkk kk kkkk) = GOTO <0 10kk kkkk> */
   go_to_12bit,      /* 101011 kk kkkk (101kkk kk kkkk) = GOTO <0 11kk kkkk> */
   go_to_12bit,      /* 101100 kk kkkk (101kkk kk kkkk) = GOTO <1 00kk kkkk> */
   go_to_12bit,      /* 101101 kk kkkk (101kkk kk kkkk) = GOTO <1 01kk kkkk> */
   go_to_12bit,      /* 101110 kk kkkk (101kkk kk kkkk) = GOTO <1 10kk kkkk> */
   go_to_12bit,      /* 101111 kk kkkk (101kkk kk kkkk) = GOTO <1 11kk kkkk> */
   movlw,            /* 110000 kk kkkk (1100kk kk kkkk) = MOVLW <00kk kkkk> */
   movlw,            /* 110001 kk kkkk (1100kk kk kkkk) = MOVLW <01kk kkkk> */
   movlw,            /* 110010 kk kkkk (1100kk kk kkkk) = MOVLW <10kk kkkk> */
   movlw,            /* 110011 kk kkkk (1100kk kk kkkk) = MOVLW <11kk kkkk> */
   iorlw,            /* 110100 kk kkkk (1101kk kk kkkk) = IORLW <00kk kkkk> */
   iorlw,            /* 110101 kk kkkk (1101kk kk kkkk) = IORLW <01kk kkkk> */
   iorlw,            /* 110110 kk kkkk (1101kk kk kkkk) = IORLW <10kk kkkk> */
   iorlw,            /* 110111 kk kkkk (1101kk kk kkkk) = IORLW <11kk kkkk> */
   andlw,            /* 111000 kk kkkk (1110kk kk kkkk) = ANDLW <00kk kkkk> */
   andlw,            /* 111001 kk kkkk (1110kk kk kkkk) = ANDLW <01kk kkkk> */
   andlw,            /* 111010 kk kkkk (1110kk kk kkkk) = ANDLW <10kk kkkk> */
   andlw,            /* 111011 kk kkkk (1110kk kk kkkk) = ANDLW <11kk kkkk> */
   xorlw,            /* 111100 kk kkkk (1111kk kk kkkk) = XORLW <00kk kkkk> */
   xorlw,            /* 111101 kk kkkk (1111kk kk kkkk) = XORLW <01kk kkkk> */
   xorlw,            /* 111110 kk kkkk (1111kk kk kkkk) = XORLW <10kk kkkk> */
   xorlw             /* 111111 kk kkkk (1111kk kk kkkk) = XORLW <11kk kkkk> */
   };

void (*dispic12[1 << PIC_DECODE_BITS])() =
   {
   disasm_controls_12bit,   /* 000000 xx xxxx = NOP/OPTION/SLEEP/CLRWDT/TRIS/MOVWF */
   disasm_clr_12bit,        /* 000001 xx xxxx = CLRW / CLRF */
   disasm_subwf,            /* 000010 df ffff = SUBWF */
   disasm_decf,             /* 000011 df ffff = DECF */
   disasm_iorwf,            /* 000100 df ffff = IORWF */
   disasm_andwf,            /* 000101 df ffff = ANDWF */
   disasm_xorwf,            /* 000110 df ffff = XORWF */
   disasm_addwf,            /* 000111 df ffff = ADDWF */
   disasm_movf,             /* 001000 df ffff = MOVF */
   disasm_comf,             /* 001001 df ffff = COMF */
   disasm_incf,             /* 001010 df ffff = INCF */
   disasm_decfsz,           /* 001011 df ffff = DECFSZ */
   disasm_rrf,              /* 001100 df ffff = RRF */
   disasm_rlf,              /* 001101 df ffff = RLF */
   disasm_swapf,            /* 001110 df ffff = SWAPF */
   disasm_incfsz,           /* 001111 df ffff = INCFSZ */
   disasm_bcf,              /* 010000 bf ffff (0100bb bf ffff) = BCF <00b> */
   disasm_bcf,              /* 010001 bf ffff (0100bb bf ffff) = BCF <01b> */
   disasm_bcf,              /* 010010 bf ffff (0100bb bf ffff) = BCF <10b> */
   disasm_bcf,              /* 010011 bf ffff (0100bb bf ffff) = BCF <11b> */
   disasm_bsf,              /* 010100 bf ffff (0101bb bf ffff) = BSF <00b> */
   disasm_bsf,              /* 010101 bf ffff (0101bb bf ffff) = BSF <01b> */
   disasm_bsf,              /* 010110 bf ffff (0101bb bf ffff) = BSF <10b> */
   disasm_bsf,              /* 010111 bf ffff (0101bb bf ffff) = BSF <11b> */
   disasm_btfsc,            /* 011000 bf ffff (0110bb bf ffff) = BTFSC <00b> */
   disasm_btfsc,            /* 011001 bf ffff (0110bb bf ffff) = BTFSC <01b> */
   disasm_btfsc,            /* 011010 bf ffff (0110bb bf ffff) = BTFSC <10b> */
   disasm_btfsc,            /* 011011 bf ffff (0110bb bf ffff) = BTFSC <11b> */
   disasm_btfss,            /* 011100 bf ffff (0111bb bf ffff) = BTFSS <00b> */
   disasm_btfss,            /* 011101 bf ffff (0111bb bf ffff) = BTFSS <01b> */
   disasm_btfss,            /* 011110 bf ffff (0111bb bf ffff) = BTFSS <10b> */
   disasm_btfss,            /* 011111 bf ffff (0111bb bf ffff) = BTFSS <11b> */
   disasm_retlw,            /* 100000 kk kkkk (1000kk kk kkkk) = RETLW <00kk kkkk> */
   disasm_retlw,            /* 100001 kk kkkk (1000kk kk kkkk) = RETLW <01kk kkkk> */
   disasm_retlw,            /* 100010 kk kkkk (1000kk kk kkkk) = RETLW <10kk kkkk> */
   disasm_retlw,            /* 100011 kk kkkk (1000kk kk kkkk) = RETLW <11kk kkkk> */
   disasm_call_12bit,       /* 100100 kk kkkk (1001kk kk kkkk) = CALL <00kk kkkk> */
   disasm_call_12bit,       /* 100101 kk kkkk (1001kk kk kkkk) = CALL <01kk kkkk> */
   disasm_call_12bit,       /* 100110 kk kkkk (1001kk kk kkkk) = CALL <10kk kkkk> */
   disasm_call_12bit        /* 100111 kk kkkk (1001kk kk kkkk) = CALL <11kk kkkk> */
   disasm_go_to_12bit,      /* 101000 kk kkkk (101kkk kk kkkk) = GOTO <0 00kk kkkk> */
   disasm_go_to_12bit,      /* 101001 kk kkkk (101kkk kk kkkk) = GOTO <0 01kk kkkk> */
   disasm_go_to_12bit,      /* 101010 kk kkkk (101kkk kk kkkk) = GOTO <0 10kk kkkk> */
   disasm_go_to_12bit,      /* 101011 kk kkkk (101kkk kk kkkk) = GOTO <0 11kk kkkk> */
   disasm_go_to_12bit,      /* 101100 kk kkkk (101kkk kk kkkk) = GOTO <1 00kk kkkk> */
   disasm_go_to_12bit,      /* 101101 kk kkkk (101kkk kk kkkk) = GOTO <1 01kk kkkk> */
   disasm_go_to_12bit,      /* 101110 kk kkkk (101kkk kk kkkk) = GOTO <1 10kk kkkk> */
   disasm_go_to_12bit,      /* 101111 kk kkkk (101kkk kk kkkk) = GOTO <1 11kk kkkk> */
   disasm_movlw,            /* 110000 kk kkkk (1100kk kk kkkk) = MOVLW <00kk kkkk> */
   disasm_movlw,            /* 110001 kk kkkk (1100kk kk kkkk) = MOVLW <01kk kkkk> */
   disasm_movlw,            /* 110010 kk kkkk (1100kk kk kkkk) = MOVLW <10kk kkkk> */
   disasm_movlw,            /* 110011 kk kkkk (1100kk kk kkkk) = MOVLW <11kk kkkk> */
   disasm_iorlw,            /* 110100 kk kkkk (1101kk kk kkkk) = IORLW <00kk kkkk> */
   disasm_iorlw,            /* 110101 kk kkkk (1101kk kk kkkk) = IORLW <01kk kkkk> */
   disasm_iorlw,            /* 110110 kk kkkk (1101kk kk kkkk) = IORLW <10kk kkkk> */
   disasm_iorlw,            /* 110111 kk kkkk (1101kk kk kkkk) = IORLW <11kk kkkk> */
   disasm_andlw,            /* 111000 kk kkkk (1110kk kk kkkk) = ANDLW <00kk kkkk> */
   disasm_andlw,            /* 111001 kk kkkk (1110kk kk kkkk) = ANDLW <01kk kkkk> */
   disasm_andlw,            /* 111010 kk kkkk (1110kk kk kkkk) = ANDLW <10kk kkkk> */
   disasm_andlw,            /* 111011 kk kkkk (1110kk kk kkkk) = ANDLW <11kk kkkk> */
   disasm_xorlw,            /* 111100 kk kkkk (1111kk kk kkkk) = XORLW <00kk kkkk> */
   disasm_xorlw,            /* 111101 kk kkkk (1111kk kk kkkk) = XORLW <01kk kkkk> */
   disasm_xorlw,            /* 111110 kk kkkk (1111kk kk kkkk) = XORLW <10kk kkkk> */
   disasm_xorlw             /* 111111 kk kkkk (1111kk kk kkkk) = XORLW <11kk kkkk> */
   };

void initr509a()
   {
   regs[PCL] = ip;
   regs[FSR] = 0xc0;
   regs[STATUS] = 0x18;
   regsknown[PCL] = ALLBITS_KNOWN;
   regsknown[FSR] = 0xe0;
   regsknown[STATUS] = ALLBITS_KNOWN;
   }
